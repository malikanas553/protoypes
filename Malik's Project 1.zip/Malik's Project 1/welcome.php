<?php
session_start();
if(empty($_SESSION["firstname"]) || !isset($_SESSION["firstname"])){
    header("Location: index.php");
    die();
}if(empty($_SESSION["lastname"]) || !isset($_SESSION["lastname"])){
    header("Location: index.php");
    die();
}?>
<!DOCTYPE html>
<html>
    <head>
        <title>TRIAL</title>
        <link rel="stylesheet" href="style2.css"/>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
<h1 id="title"> Welcome to our brotherhood</h1><h1 id="name"><?=ucfirst($_SESSION["firstname"]);?>  <?=ucfirst($_SESSION["lastname"]);?></h1>
<section id="box1">
<p>But before you can officially join our ranks you must pass the trial</p><br>
<p>You must perform the <p><span style="color:rgb(121, 8, 8)"> Leap of Faith</span></p><br><br>
<script>
function playVideo(){
    var video = document.getElementById('myVideo');
    video.play();
    video.addEventListener('ended',function(){window.location = 'https://assassinscreed.fandom.com/wiki/Assassin%27s_Creed_Wiki';});
}
</script>
<video id="myVideo" width="90%" height="80%">
  <source src="Leapoffaith.mp4" type="video/mp4">
</video><br><br><br>
<button onclick="playVideo()" type="button">Leap of Faith</button>
</section>
</body>
</html>
<?php session_unset();?>