<?php
session_start();
if(isset($_POST["firstname"])){
    $_SESSION["firstname"]=$_POST["firstname"];}
if(isset($_POST["lastname"])){
$_SESSION["lastname"]=$_POST["lastname"];}

?>
<?php
$firstname = $lastname = $email = $telnumber = $work = $gender = $dofbirth = '';
$firstnameErr = $lastnameErr = $emailErr = $telnumberErr =$workErr =$genderErr=$dofbirthErr= $oathErr = '';
if($_SERVER['REQUEST_METHOD'] == "POST"){
    if(isset($_POST["firstname"])){
        $firstname=$_POST["firstname"];
        if(empty($_POST["firstname"])){
        $firstnameErr = "First Name is required";
        unset($_POST["firstname"]);
    }elseif(preg_match("/[!@#-$%^'+=~|&?\/_*()1234567890]/",$_POST["firstname"])){
    $firstnameErr = "Only letters allowed";
    unset($_POST["firstname"]);}
}if(isset($_POST["lastname"])){
    $lastname = $_POST["lastname"];
    if(empty($_POST["lastname"])){
    $lastnameErr = "Last Name is required";
    unset($_POST["lastname"]);
}elseif(preg_match("/[!@#-$%^'+=~|&?\/_*()1234567890]/",$_POST["lastname"])){
$lastnameErr = "Only letters allowed";}
    unset($_POST["lastname"]);
}if(isset($_POST["email"])){
    $email = $_POST["email"];
    if(empty($_POST["email"])){
        $emailErr = "Email is required";
        unset($_POST["email"]);
    }elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $emailErr = "Invalid email";
        unset($_POST["email"]);
    }
}
if(isset($_POST["telnumber"])){
    $telnumber = $_POST['telnumber'];
    if(empty($_POST["telnumber"])){
        $telnumberErr = "Phone Number is required";
        unset($_POST["telnumber"]);
    }elseif(preg_match("/[!@#-$%^'+=~|&?\/_*()qwertyuioplkjhgfdsazxcvbnm\s]/",$_POST["telnumber"])){
        $telnumberErr = "Numbers only";
        unset($_POST["telnumber"]);
    }elseif(strlen($_POST["telnumber"])!=10){
        $telnumberErr = "Invalid Phone Number";
        unset($_POST["telnumber"]);
    }
    }
if(!isset($_POST["gender"])){
    $genderErr ="Please choose a gender";

}else{
    $gender= $_POST["gender"];
}
if(isset($_POST["day"]) and isset($_POST["month"]) and isset($_POST["year"])){
    $dofbirthErr= '';
}else{
    $dofbirthErr= "Please choose Date of Birth";
}if(isset($_POST["formerjob"])){
    $work= $_POST["formerjob"];
    if(empty($_POST["formerjob"])){
        $workErr = "Previous Line of work is required";
        unset($_POST["formerjob"]);}
}if(!isset($_POST["oath"])){
    $oathErr ='Please check this box';
}

if($firstnameErr == '' and $lastnameErr == '' and  $emailErr == '' and  $telnumberErr == '' and $workErr == '' and $genderErr == '' and $dofbirthErr == '' and $oathErr == ''){
    header("Location: welcome.php");
    die();
}  ?><!DOCTYPE html>
<html>
    <head>
        <title> Assassin's Creed Registration </title>
        <link rel="stylesheet" href="style.css"/>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <h1>Assassin'S</h1><h1 id="creed">Creed<h1>
    <section id="box1">
    <section id='box2'>
    <img src="ascicon.png" id="icon"/>
    <h2>Join the Brotherhood</h2>
    <form action="" method="post">
    <label for="firstname">First Name </label><spam class="error"><?php echo $firstnameErr;?></spam><br><br>
        <input type="text" name="firstname" placeholder="Enter First Name" class="field" value="<?= $firstname?>"><br><br>
        <label for="lastname">Last Name </label><spam class="error"><?php echo $lastnameErr;?></spam><br><br>
        <input type="text" name="lastname" placeholder="Enter Last Name" class="field" value="<?= $lastname ?>"><br><br>
        <label>Gender </label><spam class="error"><?php echo $genderErr;?></spam><br><br>
        <form action="" method="POST">
        <section id="radio">
        <input type="radio" id="male" name="gender" value="male" <?php if (isset($gender) && $gender=="male") echo "checked";?>>
        <label for="male">male </label>
        <input type="radio" id="female" name="gender" value="female" <?php if (isset($gender) && $gender=="female") echo "checked";?>>
        <label for="female">female</label><br><br>
         </section>
         </section>
         <section id="box3">
         <label for="dofbirth">Date of Birth</label><br><spam class="error"><?php echo $dofbirthErr;?></spam><br>
        <section id="box4">
        <p>Day</p><br>
        <select name= "day" id="day" class="dofbirth">
        <option disabled selected value></option>
            <?php for($i = 1; $i <= 31;$i++){?>
                <option value="<?php echo $i;?>"<?php if (isset($_POST['day']) and $_POST['day'] == $i ){ echo ' selected="selected"';} ?>><?php echo $i;?></option>
            <?php } ?>
            </select></section>
            <section id="box5">
            <p>Month</p><br>
            <select name="month" id="month" class="dofbirth" >
        <option disabled selected value></option>
            <?php for($i = 1; $i <= 12;$i++){?>
                <option value="<?php echo $i;?>"<?php if (isset($_POST['month']) and $_POST['month'] == $i ){ echo ' selected="selected"';} ?>><?php echo $i;?></option>
            <?php } ?>
            </select></section>
            <section id="box6">
            <p>Year</p><br>
            <select name="year" id="year" class="dofbirth">
        <option disabled selected value></option>
            <?php for($i = 1990; $i <= 2022;$i++){?>
                <option value="<?php echo $i;?>"<?php if (isset($_POST['year']) and $_POST['year'] == $i ){ echo ' selected="selected"';} ?>><?php echo $i;?></option>
            <?php } ?>
            </select><br><br></section>
           </section>
           <section id="box7">
        <label for="email">Email </label><spam class="error" ><?php echo $emailErr;?></spam><br><br>
        <input type="email" name="email" placeholder="Enter Email Address" class="field" value="<?= $email?>"  ><br><br>
        <label for="telnumber">Phone Number </label><spam class="error"><?php echo $telnumberErr;?></spam><br><br>
        <input type="tel" name="telnumber" placeholder="Enter Phone Number" class="field" value="<?= $telnumber?>" ><br><br>
        <label for="formerjob">Previous Line of Work </label><spam class="error"><?php echo $workErr;?></spam><br><br>
        <input type="text" name="formerjob" placeholder="Enter Former Job" class="field" value="<?=$work?>"><br><br>
        </section>
        </section>
        <section id="box8">
            <h2>Our creed's three crucial rules:</h2>
            <ul>
                <li>Stay your blade from the flesh of an innocent</li><br>
                <li>Hide in plain sight, be one with the crowd</li><br>
                <li>Never compromise the Brotherhood</li>
            </ul>
            <br><br><br><br><br><br><br><br><br><br>
            <section id="box9">
            <spam class="error" ><?php echo $oathErr;?></spam><br>
            <input type="checkbox" id="checkbox" name="oath" <?php if(isset($_POST['oath'])){echo "checked";}?>>
            <label for="checkbox" id="oath">I swear to follow the rules with my life</label><br><br><br><br>
            <input type="submit" id="submit">
            </section>
            </section> 
            </form>
            <?php } else{ ?>
<!DOCTYPE html>
<html>
    <head>
        <title> Assassin's Creed Registration </title>
        <link rel="stylesheet" href="style.css"/>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <h1>Assassin'S</h1><h1 id="creed">Creed<h1>
    <section id="box1">
    <section id='box2'>
    <img src="ascicon.png" id="icon"/>
    <h2>Join the Brotherhood</h2>
    <form action="" method="post">
        <label for="firstname">First Name</label><?php echo $firstnameErr;?><br><br>
        <input type="text" name="firstname" placeholder="Enter First Name" class="field"><br><br>
        <label for="lastname">Last Name</label><?php echo $lastnameErr;?><br><br>
        <input type="text" name="lastname" placeholder="Enter Last Name" class="field"><br><br>
        <label>Gender</label><?php echo $genderErr;?><br><br>
        <form action="" method="POST">
        <section id="radio">
        <input type="radio" id="male" name="gender" value="Male">
        <label for="male">male </label>
        <input type="radio" id="female" name="gender" value="Female">
        <label for="female">female</label><br><br>
         </section>
         </section>
        <section id="box3">
        <label for="dofbirth">Date of Birth</label><br><?php echo $dofbirthErr;?>
        <section id="box4">
        <p>Day</p><br>
        <select name= "day" id="day" class="dofbirth">
        <option disabled selected value></option>
            <?php for($i = 1; $i <= 31;$i++){?>
                <option value="<?php echo $i;?>"><?php echo $i;?></option>
            <?php } ?>
            </select></section>
            <section id="box5">
            <p>Month</p><br>
            <select name="month" id="month" class="dofbirth" >
        <option disabled selected value></option>
            <?php for($i = 1; $i <= 12;$i++){?>
                <option value="<?php echo $i;?>"><?php echo $i;?></option>
            <?php } ?>
            </select></section>
            <section id="box6">
            <p>Year</p><br>
            <select name="year" id="year" class="dofbirth">
        <option disabled selected value></option>
            <?php for($i = 1990; $i <= 2022;$i++){?>
                <option value="<?php echo $i;?>"><?php echo $i;?></option>
            <?php } ?>
            </select><br><br></section>
           </section>
        <section id="box7">
        <label for="email">Email</label><?php echo $emailErr;?><br><br>
        <input type="email" name="email" placeholder="Enter Email Address" class="field" ><br><br>
        <label for="telnumber">Phone Number</label><?php echo $telnumberErr;?><br><br>
        <input type="tel" name="telnumber" placeholder="Enter Phone Number" class="field" ><br><br>
        <label for="formerjob">Previous Line of Work</label><?php echo $workErr;?><br><br>
        <input type="text" name="formerjob" placeholder="Enter Former Job" class="field" ><br><br>
        </section>
        </section>
        <section id="box8">
            <h2>Our creed's three crucial rules:</h2>
            <ul>
                <li>Stay your blade from the flesh of an innocent</li><br>
                <li>Hide in plain sight, be one with the crowd</li><br>
                <li>Never compromise the Brotherhood</li>
            </ul>
            <br><br><br><br><br><br><br><br><br><br>
            <section id="box9">
            <input type="checkbox" id="checkbox" name="oath">
            <label for="checkbox" id="oath" name="oath">I swear to follow the rules with my life</label><br><br><br><br>
            </section>
            <input type="submit" id="submit">    
            </section>
        </form>
            </body>
            </html>
            <?php } ?>


