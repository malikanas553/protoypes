<?php
session_start();
require 'connect.php';
error_reporting(0);
if(!((isset($_SESSION['ID']) && ($_SESSION['ROLE'] == 'admin' || $_SESSION['ROLE'] == 'superadmin')) )){
    header('Location: login.php');
    die;
}
$sql= "SELECT STATUS FROM users WHERE USER_ID = '$_SESSION[ID]'";
$result= mysqli_query($conn,$sql);
$row = mysqli_fetch_assoc($result);
if($row['STATUS'] == "Banned"){
    header("Location:logout.php");
    die;
}
if($_SERVER['REQUEST_METHOD'] == "POST"){
    $_SESSION['ROLE'] = 'Teacher';
    header("Location: courses.php");
    die;
}
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Admin WS Home</title>
        <script
src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js">
</script>
        <?php include 'template/header.php'?>
        <h1 class="sectionhead">Website Statistics</h1>
<section class="websitestats">
    
    
    <div class="stats" id="stats1">
        <?php
        $sql = "SELECT * from users";
        $result = mysqli_query($conn,$sql);
        $users = mysqli_num_rows($result);
        $sql = "SELECT * from users WHERE ROLE='Student'";
        $result = mysqli_query($conn,$sql);
        $students = mysqli_num_rows($result);
        $sql = "SELECT * from users WHERE ROLE='Teacher'";
        $result = mysqli_query($conn,$sql);
        $teachers = mysqli_num_rows($result);
        
        
        ?>
        <h2 class="statshead">Number of Total Users</h2>
        <spam class="number"><?= $users?></spam>
        <h3 class="statssubhead">Number of Students</h3>
        <spam class="number"><?= $students?></spam>
        <h3 class="statssubhead">Number of Teachers</h3>
        <spam class="number"><?= $teachers?></spam>
        
</div>
    <div class="stats" id="stats2">
    <?php
        $sql = "SELECT * from courses";
        $result = mysqli_query($conn,$sql);
        $courses = mysqli_num_rows($result);
        $sql = "SELECT * from courses WHERE COURSE_TYPE='frontend'";
        $result = mysqli_query($conn,$sql);
        $frontend = mysqli_num_rows($result);
        $sql = "SELECT * from courses WHERE COURSE_TYPE='backend'";
        $result = mysqli_query($conn,$sql);
        $backend = mysqli_num_rows($result);
        $sql = "SELECT * from lectures";
        $result = mysqli_query($conn,$sql);
        $lectures = mysqli_num_rows($result);
        
        ?>
        <h2 class="statshead">Number of Total Courses</h2>
        <spam class="number"><?= $courses?></spam>
        <h3 class="statssubhead">Number of Front-End Courses</h3>
        <spam class="number"><?= $frontend?></spam>
        <h3 class="statssubhead">Number of Back-End Courses</h3>
        <spam class="number"><?= $backend?></spam>
        <h3 class="statssubhead">Number of Lectures</h3>
        <spam class="number"><?= $lectures?></spam>
</div>
    <div class="stats" id="stats3">
        <?php 
        $sql = "SELECT * from users WHERE ROLE='admin' OR ROLE='superadmin'";
        $result = mysqli_query($conn,$sql);
        $admins = mysqli_num_rows($result);
        $sql = "SELECT * from users WHERE ROLE='admin'";
        $result = mysqli_query($conn,$sql);
        $normal = mysqli_num_rows($result);
        $sql = "SELECT * from users WHERE ROLE='superadmin'";
        $result = mysqli_query($conn,$sql);
        $super = mysqli_num_rows($result);
        ?>
        <h2 class="statshead">Number of Total Admins</h2>
        <spam class="number"><?= $admins?></spam>
        <h3 class="statssubhead">Number of Normal Admins</h3>
        <spam class="number"><?= $normal?></spam>
        <h3 class="statssubhead">Number of Super Admins</h3>
        <spam class="number"><?= $super?></spam>
</div>
</section>
<h1 class="sectionhead">Rating Statistics</h1>
<section class="ratingsstats">

<?php
$sql = "SELECT AVG(STAR_REVIEW) as AVERAGE FROM reviews";
$result = mysqli_query($conn,$sql);
$row = mysqli_fetch_assoc($result);
$avg = round($row['AVERAGE']);
$sql ="SELECT * FROM  reviews WHERE STAR_REVIEW = '1'";
$result = mysqli_query($conn,$sql);
$onestar = mysqli_num_rows($result);
$sql ="SELECT * FROM  reviews WHERE STAR_REVIEW = '2'";
$result = mysqli_query($conn,$sql);
$twostar = mysqli_num_rows($result);
$sql ="SELECT * FROM  reviews WHERE STAR_REVIEW = '3'";
$result = mysqli_query($conn,$sql);
$threestar = mysqli_num_rows($result);
$sql ="SELECT * FROM  reviews WHERE STAR_REVIEW = '4'";
$result = mysqli_query($conn,$sql);
$fourstar = mysqli_num_rows($result);
$sql ="SELECT * FROM  reviews WHERE STAR_REVIEW = '5'";
$result = mysqli_query($conn,$sql);
$fivestar = mysqli_num_rows($result);
?>
<h2 class="sectionsubhead">Overall User rating</h2>
<p>The average star rating is <?=$avg?></p> 
<spam class="star-rating">
            <input type="radio" name="rating" value="1" <?php if($avg == 1){echo "checked";}else{echo "disabled";}?>><i class="star"></i>
            <input type="radio" name="rating" value="2" <?php if($avg == 2){echo "checked";}else{echo "disabled";}?>><i class="star"></i>
            <input type="radio" name="rating" value="3" <?php if($avg == 3){echo "checked";}else{echo "disabled";}?>><i class="star"></i>
            <input type="radio" name="rating" value="4" <?php if($avg == 4){echo "checked";}else{echo "disabled";}?>><i class="star"></i>
            <input type="radio" name="rating" value="5" <?php if($avg == 5){echo "checked";}else{echo "disabled";}?>><i class="star"></i>
          </spam>

<canvas id="myChart" ></canvas>
<script>
var xValues = ["5 star", "4 star", "3 star", "2 star", "1 star","0 star"];
var yValues = [<?= $fivestar?>, <?= $fourstar?>, <?= $threestar?>, <?= $twostar?>, <?= $onestar?>,0];
var barColors = ["red", "green","blue","orange","brown"];

new Chart("myChart", {
  type: "horizontalBar",
  data: {
    labels: xValues,
    datasets: [{
      backgroundColor: barColors,
      data: yValues
    }]
  },

  options: {
    
    indexAxis: 'y',
    legend: {display: false},
    title: {
      display: true,
      text: "User Ratings"
    }
  }
});
</script>
</section>
<?php 
include 'template/footer.html';
?>


