<?php
session_start();
require 'connect.php';
error_reporting(0);
if(!(isset($_SESSION['ID']) && ($_SESSION['ROLE'] == 'admin' || $_SESSION['ROLE'] == 'superadmin'))){
    header("Location:login.php");
    die;
}

$sql= "SELECT STATUS FROM users WHERE USER_ID = '$_SESSION[ID]'";
$result= mysqli_query($conn,$sql);
$row = mysqli_fetch_assoc($result);
if($row['STATUS'] == "Banned"){
    header("Location:logout.php");
    die;
}
?>
<!DOCTYPE html>
<html>
    <head>
        <?php if(isset($_GET['students'])){?>
        <title>Edit Students</title>
        <?php include 'template/header.php'; ?>
<?php 
$role = "Student";
$sql = "SELECT * FROM users WHERE ROLE = 'Student' AND STATUS = 'Active'";
$result = mysqli_query($conn,$sql);
        }
elseif(isset($_GET['teachers'])){?>
    <title>Edit Teachers</title>
    <?php include 'template/header.php'; ?>
<?php 
$role = "Teacher";
$sql = "SELECT * FROM users WHERE ROLE = 'Teacher' AND STATUS = 'Active'";
$result = mysqli_query($conn,$sql);}
elseif(isset($_GET['admins'])){
    if($_SESSION['ROLE'] !== 'superadmin'){
        header("Location:login.php");
        die;
    }?>
    <title>Edit Admins</title>
    <?php include 'template/header.php'; ?>
<?php 
$role = "Admin";
$sql = "SELECT * FROM users WHERE (ROLE = 'admin' OR ROLE = 'superadmin') AND STATUS = 'Active' ORDER BY ROLE DESC";
$result = mysqli_query($conn,$sql);}elseif(isset($_GET['banned'])){?>
    <title>Edit Students</title>
    <?php include 'template/header.php'; ?>
<?php 
$role = "Banned";
$sql = "SELECT * FROM users WHERE STATUS = 'Banned'";
$result = mysqli_query($conn,$sql);}?>
<h1 class="sectionhead"><?= $role?> Users</h1><?php if($role !== "Banned"){?><a href="users.php?banned" class="banned">Banned Users</a><?php }?>
<input type="text" id="myInput" onkeyup="filter()" placeholder="Search for names.." class="field">
<table class="usertable" id="myTable">
    <tr>
        <th>FULL NAME</th>
        <th>EMAIL ADDRESS</th>
        <?php if($role == "Admin"){?>
        <th>Role</th>
      <?php } if($role !== "Banned"){?>
        <th>BAN USER</th>
        
        <?php 
        if($_SESSION['ROLE'] == "superadmin"){
        if($role !== "Admin"){?>
        <th>MAKE ADMIN</th>
        <?php }}}else{?>
        <th>UNBAN USER</th>
        <?php }?>

</tr>
<?php
while($row = mysqli_fetch_assoc($result)){?>
    <tr>
        <td><?=$row['FIRST_NAME']?> <?=$row['LAST_NAME']?></td>
        <td><?=$row['EMAIL']?></td>
        <?php if($role == "Admin"){?>
        <td><?=$row['ROLE']?></td>
      <?php }?>
        <?php if($role !== "Banned"){
          if($row['ROLE'] !== "superadmin"){
        if($row['USER_ID'] == $_SESSION['ID']){?>
        <td>Are you thinking of banning yourself?<td>
        <?php }else{?>
        <td><a href="delete.php?ban<?=$role?>id=<?=$row['USER_ID']?>">Ban Now</a></td>
        <?php }}else{?>
          <td>This user cannot be banned</td>
        
        <?php }if($_SESSION['ROLE'] == "superadmin"){?>
          <?php 
        if($role !== "Admin"){?>
        <td><a href="delete.php?make<?=$role?>id=<?=$row['USER_ID']?>">Make Admin</a></td>
        <?php }}}else{?>
            <td><a href="delete.php?unbanid=<?=$row['USER_ID']?>">Unban Now</a></td>
        <?php }?>
        
</tr>
<?php }?>
<script>
function filter() {

  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
}
</script>
