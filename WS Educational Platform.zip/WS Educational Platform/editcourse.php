<?php
session_start();
require 'connect.php';
error_reporting(0);
if(!isset($_SESSION['ID']) || $_SESSION['ROLE']!= 'Teacher'){
    header('Location: login.php');
    die;
}
$sql= "SELECT STATUS FROM users WHERE USER_ID = '$_SESSION[ID]'";
$result= mysqli_query($conn,$sql);
$row = mysqli_fetch_assoc($result);
if($row['STATUS'] == "Banned"){
    header("Location:logout.php");
    die;
}
if(isset($_GET['courseid'])){
    $courseid = $_GET['courseid'];
    $sql = "SELECT * FROM courses WHERE COURSE_ID = '$courseid'";
    $result = mysqli_query($conn,$sql);
    $row2 = mysqli_fetch_assoc($result);
   
}elseif(isset($_GET['lectureid'])){
    $lectureid = $_GET['lectureid'];
    $sql2 = "SELECT * FROM lectures WHERE LECTURE_ID = '$lectureid'";
    $result2 = mysqli_query($conn,$sql2);


}else
{
    header("Location:adminindex.php");
    die;
}
$userid = $_SESSION['ID'];
$coursename = $coursetype = $coursedescript = $coursepic =  $lecturename1 = $lecturedescript1 = $lectureurl1 = $lecturenumber = '';
$coursenameErr = $coursetypeErr = $coursedescriptErr = $coursepicErr =  $lecturename1Err = $lecturenumberErr = $lecturedescript1Err = $lectureurl1Err = '';
if($_SERVER['REQUEST_METHOD'] == "POST"){
    if(isset($_GET['courseid'])){
    if(isset($_POST["coursename"])){
        $coursename=$conn -> real_escape_string($_POST["coursename"]);
        if(empty($_POST["coursename"])){
        $coursenameErr = "Course Name is required";
        unset($_POST["coursename"]);
    }}else{ 
$coursenameErr = "Course Name is required";
}
if(!isset($_POST["coursetype"])){
    $coursetypeErr ="Please choose a course type";

}else{
    $coursetype= $_POST["coursetype"];
}if(isset($_POST['coursedescript'])){
    $coursedescript =$conn -> real_escape_string( $_POST['coursedescript']);
    if(empty($_POST['coursedescript'])){
        $coursedescriptErr = "Course description is Required";
        unset($_POST['coursedescript']);
    }
}else{
    $coursedescriptErr = "Course description is Required";
}
if(isset($_FILES["uploadfile"]) && !empty($_FILES["uploadfile"]["name"])){
    $filename = $_FILES["uploadfile"]["name"];
   $tempname = $_FILES["uploadfile"]["tmp_name"];    
    $folder = $filename;
    move_uploaded_file($tempname, $folder);}else{
        $filename = $row2['COURSE_PIC'];
    }
if($coursenameErr == ''  and  $coursetypeErr == '' and  $coursedescriptErr == '' and $coursepicErr == ''){
    $insert = "UPDATE courses SET COURSE_PIC = '$filename',COURSE_NAME = '$coursename',COURSE_DESCRIPT = '$coursedescript' ,COURSE_TYPE = '$coursetype' WHERE COURSE_ID = '$courseid'";
    $result1 = mysqli_query($conn, $insert);
    if($result1){
        header("Location:courses.php");
    die(); }else{
        echo "failed to update";
    }
}}else{
if(isset($_POST['lecturename1'])){
    $lecturename1= $conn -> real_escape_string($_POST['lecturename1']);
    if(empty($_POST['lecturename1'])){
    $lecturename1Err = "Lecture Name is required";
    unset($_POST['lecturename1']);
}}else{ 
$lecturename1Err = "Lecture Name is required";
}
$lecturenumber = $_POST['lecturenumber'];
if(isset($_POST['lecturedescript1'])){
    $lecturedescript1 = $conn -> real_escape_string($_POST['lecturedescript1']);
    if(empty($_POST['lecturedescript1'])){
        $lecturedescript1Err = "Lecture Description is Required";
        unset($_POST['lecturedescript1']);
    }
}else{
    $lecturedescript1Err = "Lecture description is Required";
} 
if(isset($_POST['lectureurl1'])){
    $lectureurl1 = $conn -> real_escape_string($_POST["lectureurl1"]);
    if(empty($_POST["lectureurl1"])){
        $lectureurl1Err = "Lecture URL is required";
        unset($_POST["lectureurl1"]);
    }elseif (!filter_var($lectureurl1, FILTER_VALIDATE_URL)) {
        $lectureurl1Err = "Lecture URL is invalid";
        unset($_POST["lectureurl1"]);
    }elseif(!strpos($_POST["lectureurl1"],'youtube.com')){
        $lectureurl1Err = "Lecture URL is not a youtube url";
        unset($_POST["lectureurl1"]);
    }elseif(strpos($_POST["lectureurl1"],'embed')){
            $str = strstr($_POST["lectureurl1"], 'embed/');
            $url = substr($str, 6);
            $sql = "SELECT * FROM lectures WHERE NOT COURSE_ID = '$courseid' AND LECTURE_URL = '$url' ";
        $result = mysqli_query($conn, $sql);
            if (mysqli_num_rows($result) > 0) {
                $lectureurl1Err = 'Lecture URL already exists';
        
        }}else{
            $url = $_POST["lectureurl1"];
            parse_str( parse_url( $url, PHP_URL_QUERY ), $my_array_of_vars );
            $url = $my_array_of_vars['v'];
            $sql = "SELECT * FROM lectures WHERE LECTURE_URL = '$url' AND NOT LECTURE_ID = '$lectureid'";
            $result = mysqli_query($conn, $sql);
                if (mysqli_num_rows($result) > 0) {
                    $lectureurl1Err = 'Lecture URL already exists';
            
            }
            
        }
}else{
    $lectureurl1Err = "Lecture URL is required";
}}

if($lecturename1Err == '' and $lecturenumberErr == '' and $lecturedescript1Err == '' and $lectureurl1Err == ''){
    $insert2 = "UPDATE lectures SET LECTURE_NO = '$lecturenumber' , LECTURE_NAME = '$lecturename1' ,LECTURE_DESCRIPT = '$lecturedescript1' ,LECTURE_URL ='$url' WHERE LECTURE_ID = '$lectureid'";
    $result3 = mysqli_query($conn,$insert2);
    if($result3){
        header("Location: courses.php");
    }else{
        echo "failed to update";
    }}}
?>
<!DOCTYPE html>
<html>
    <head>
    <title>Edit Course</title>
<?php include 'template/header.php';
?>

    <form method="POST" action="" class="addcourseform" enctype="multipart/form-data">
        <?php if(isset($_GET['courseid'])){?>
        <section class="addcoursesect">
            <h2 class="loginhead">Edit Course</h2>
            <label for="coursename">Course name </label><spam class="error"><?= $coursenameErr?></spam>
            <input type="text" name="coursename" placeholder="The name of your course(without course at the end)" class="field" value="<?= $row2['COURSE_NAME']?>">
            <label for="coursetype">Course Type </label> <spam class="error"><?= $coursetypeErr?></spam><br>
            <select class="field" name="coursetype">
                <option disabled selected>Choose course type</option>
                <option value="frontend" name="coursetype" <?php if($row2['COURSE_TYPE'] == 'frontend'){echo "selected";}?>>Front-End</option>
                <option value="backend" name="coursetype" <?php if($row2['COURSE_TYPE'] == 'backend'){echo "selected";}?>>Back-End</option>
            </select>
            <label for="coursedescript">Course Description </label> <spam class="error"><?= $coursedescriptErr?></spam><br><br>
            <textarea maxlength="300" placeholder="A short description about your course" class="formControl" max="" name="coursedescript"><?= $row2['COURSE_DESCRIPT']?></textarea><br>
            <label for="coursepic">Course Front Cover<spam class="optional">(optional)</spam> <spam class="error"></label>
            <input type="file" name="uploadfile" class="primarybtn upload" />
            <input type="submit" name="submitform" class="loginbtn">
        </form>
</section><br><br>
<?php }else{?>
        <section class="addlecturessect">
        <form method="POST" action="" class="addcourseform">
           <h2 class="loginhead">Edit Lecture</h2>
           <?php
           
           while($row3 = mysqli_fetch_assoc($result2)){?>
          <h3>Lecture <?= $row3['LECTURE_NO']?></h3>
          <label for="lecturename1">Lecture Name </label><spam class="error"><?= $lecturename1Err?></spam>
          <input type="text" placeholder="Name of Lecture 1" name="lecturename1" class="field" value="<?= $row3['LECTURE_NAME']?>">
          <label for="lecturenumber">Lecture Number </label><spam class="error"><?= $lecturenumberErr?></spam>
          <select name="lecturenumber" class="field">
             <?php
             $i = 1;
             while($i <= 10){?>
             <option <?php if($i == $row3['LECTURE_NO']){ echo "selected";}?> value=<?= $i?> name="lecturenumber"><?= $i?></option>
             <?php 
             $i = $i +1;} ?>
          </select>
          <label for="lecturedescript1">Lecture Description </label><spam class="error"><?= $lecturedescript1Err?></spam><br><br>
          <textarea maxlength="2000" placeholder="About the lecture" class="formControl" max="" name="lecturedescript1"><?= $row3['LECTURE_DESCRIPT']?></textarea><br>
          <label for="lectureurl1">Lecture Video URL </label><spam class="error"><?= $lectureurl1Err?></spam>
          <input type="text" placeholder="Paste Youtube Url Here" name="lectureurl1" class="field"  value="https://www.youtube.com/watch?v=<?= $row3['LECTURE_URL']?>">
          
          <?php }?>
        </section>
        <input type="submit" name="submitform" class="loginbtn">
        </form>
        <?php }
         

        include 'template/footer.html' ?>