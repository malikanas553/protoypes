<?php
session_start();
require 'connect.php';
error_reporting(0);
if(isset($_SESSION['ID'])){
    header("Location: index.php");
    die();
}
$firstname = $email = $lastname = $role =  $password = $reppassword = $notification =  '';
$firstnameErr = $emailErr = $lastnameErr = $roleErr = $passwordErr = $reppasswordErr = '';
if($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['signup'])){
    if(isset($_POST["firstname"])){
        $firstname=$_POST["firstname"];
        if(empty($_POST["firstname"])){
        $firstnameErr = "First Name is required";
        unset($_POST["firstname"]);
    }elseif(preg_match("/[!@#-$%^'+=~|&?\/_*()1234567890]/",$_POST["firstname"])){
    $firstnameErr = "Only letters allowed";
    unset($_POST["firstname"]);}
}else{ 
$firstnameErr = "First Name is required";
}
if(isset($_POST["lastname"])){
    $lastname=$_POST["lastname"];
    if(empty($_POST["lastname"])){
    $lastnameErr = "Last Name is required";
    unset($_POST["lastname"]);
}elseif(preg_match("/[!@#-$%^'+=~|&?\/_*()1234567890]/",$_POST["lastname"])){
$lastnameErr = "Only letters allowed";
unset($_POST["lastname"]);}
}else{ 
$lastnameErr = "Last Name is required";
}
if(isset($_POST["email"])){
    $email = $_POST["email"];
    if(empty($_POST["email"])){
        $emailErr = "Email is required";
        unset($_POST["email"]);
    }elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $emailErr = "Invalid email";
        unset($_POST["email"]);
    }else{
        $sql = "SELECT * FROM users WHERE EMAIL = '$_POST[email]'";
        $result = mysqli_query($conn, $sql);
            if (mysqli_num_rows($result) > 0) {
                $emailErr = 'Email already exists';
    }
}}else{
    $emailErr = "Email is required";
}if(!isset($_POST["role"])){
    $roleErr ="Please choose a role";

}else{
    $role= $_POST["role"];
}if(isset($_POST['password'])){
    $password = $_POST['password'];
    if(empty($_POST['password'])){
        $passwordErr = "Password is Required";
        unset($_POST['password']);
    }elseif(strstr($_POST['password'],"\s")){
        $passwordErr = "Your password should not include whitespace";
        unset($_POST['password']);
    }
    elseif(strlen($_POST['password']) < 8){
        $passwordErr = "Your password should have at least 8 characters";
        unset($_POST['password']);
    }elseif(strlen($_POST['password']) > 16){
        $passwordErr = "Your password should not exceed 16 characters";
        unset($_POST['password']);
    }
}else{
    $passwordErr = "Password is Required";
}if(isset($_POST['reppassword'])){
    $reppassword = $_POST['reppassword'];
    if(empty($_POST['reppassword'])){
        $reppasswordErr = "Repeat your Password";
        unset($_POST['reppassword']);
    }elseif($_POST['reppassword'] !== $password){
        $reppasswordErr = "The passwords dont match";
        unset($_POST['reppassword']);
    }
}else{
    $reppasswordErr = "Repeat your Password";
}
if($firstnameErr == ''  and  $emailErr == '' and  $lastnameErr == '' and $roleErr == '' and $passwordErr == '' and $reppasswordErr == ''){
    $sql = "SELECT * FROM users";
    $result= mysqli_query($conn,$sql);
    if(mysqli_num_rows($result) == 0){
        $role = "superadmin";
    }
    $insert = "INSERT INTO users (FIRST_NAME ,LAST_NAME ,EMAIL ,PASSWORD ,ROLE ) VALUES ('$firstname','$lastname','$email','$password','$role')";
    $result1 = mysqli_query($conn, $insert);
    if($result1){header("Location:login.php");
    die(); }else{
        $notification = "systemerror";
    }}else{
        $notification = "error";
    }}?>

<!DOCTYPE html>
<html>
    <head>
    <title>REGISTRATION</title>
<meta content="width=device-width, initial-scale=1" name="viewport" />
<?php include 'template/header.php'; ?>
</head>

<?php
 if($notification == "error"){?>
    <script>
        function closenotification(){
            var y = document.getElementById("error")
        y.style.display = "none"
        }
    </script>
    
    <div class="notification" id="error">
          <p>Error: Check the registration fields</p><a href="javascript:void(0)" class="close" onclick="closenotification()">x</a>
    </div>
   
    <?php }elseif($notification == "systemerror"){?>
    <script>
        function closenotification(){
            var y = document.getElementById("systemerror")
        y.style.display = "none"
        }
    </script>
    <div class="notification" id="systemerror">
          <p>Error: Your registration form has failed to submit due to a system error</p><a href="javascript:void(0)" class="close" onclick="closenotification()">x</a>
    </div>
    <?php }?>
    <section class="login" id="register">
    <div class="loginbox">
        <h1 class="loginhead">Register</h1>
        <form method="post" action="">
            <label for="firstname">First Name </label><spam class="error"><?= $firstnameErr?></spam>
            <input type="text" name="firstname" class="field" placeholder="First Name" value="<?=$firstname?>">
            <label for="lastname">Last Name </label><spam class="error"><?= $lastnameErr?></spam>
            <input type="text" name="lastname" class="field" placeholder="Last Name" value="<?=$lastname?>">
            <label for="email">Email </label><spam class="error"><?= $emailErr?></spam>
            <input type="email" name="email" class="field" placeholder="Email address" value="<?=$email?>">
            <label for="role">Role </label><spam class="error"><?= $roleErr?></spam><br>
            <input type="radio" id="Student" name="role" value="Student" <?php if (isset($role) && $role=="Student") echo "checked";?>>
            <label for="Student"  class="option">Student </label><br>
            <input type="radio" id="Teacher" name="role" value="Teacher" <?php if (isset($role) && $role=="Teacher") echo "checked";?> >
            <label for="Teacher" class="option">Teacher </label><br>
            <label for="password">Password </label><spam class="error"><?= $passwordErr?></spam>
            <input type="password" name="password" class="field" placeholder="Password">
            <label for="reppassword"> Repeat Password </label><spam class="error"><?= $reppasswordErr?></spam>
            <input type="password" name="reppassword" class="field" placeholder="Repeat your password">
            <button type="submit" class="loginbtn" name="signup">Register</button>
            <spam class="noaccount">Already have an account?<br><a href="login.php" class="primarybtn.login">Log In</a></spam>
        </form>
    </div>
</section> 
<?php 
include 'template/footer.html';
?>