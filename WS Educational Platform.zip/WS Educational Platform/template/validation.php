<?php
$firstname = $email = $lastname = $role =  $password = $reppassword = '';
$firstnameErr = $emailErr = $lastnameErr = $roleErr = $passwordErr = $reppasswordErr = '';
if($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['signup'])){
    if(isset($_POST["firstname"])){
        $firstname=$_POST["firstname"];
        if(empty($_POST["firstname"])){
        $firstnameErr = "First Name is required";
        unset($_POST["firstname"]);
    }elseif(preg_match("/[!@#-$%^'+=~|&?\/_*()1234567890]/",$_POST["firstname"])){
    $firstnameErr = "Only letters allowed";
    unset($_POST["firstname"]);}
}else{ 
$firstnameErr = "First Name is required";
}
if(isset($_POST["lastname"])){
    $lastname=$_POST["lastname"];
    if(empty($_POST["lastname"])){
    $lastnameErr = "Last Name is required";
    unset($_POST["lastname"]);
}elseif(preg_match("/[!@#-$%^'+=~|&?\/_*()1234567890]/",$_POST["lastname"])){
$lastnameErr = "Only letters allowed";
unset($_POST["lastname"]);}
}else{ 
$lastnameErr = "Last Name is required";
}
if(isset($_POST["email"])){
    $email = $_POST["email"];
    if(empty($_POST["email"])){
        $emailErr = "Email is required";
        unset($_POST["email"]);
    }elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $emailErr = "Invalid email";
        unset($_POST["email"]);
    }else{
        $sql = "SELECT * FROM users WHERE EMAIL = '$_POST[email]'";
        $result = mysqli_query($conn, $sql);
            if (mysqli_num_rows($result) > 0) {
                $emailErr = 'Email already exists';
    }
}}else{
    $emailErr = "Email is required";
}if(!isset($_POST["role"])){
    $roleErr ="Please choose a role";

}else{
    $role= $_POST["role"];
}if(isset($_POST['password'])){
    $password = $_POST['password'];
    if(empty($_POST['password'])){
        $passwordErr = "Password is Required";
        unset($_POST['password']);
    }elseif(strstr($_POST['password'],"\s")){
        $passwordErr = "Your password should not include whitespace";
        unset($_POST['password']);
    }
    elseif(strlen($_POST['password']) < 8){
        $passwordErr = "Your password should have at least 8 characters";
        unset($_POST['password']);
    }elseif(strlen($_POST['password']) > 16){
        $passwordErr = "Your password should not exceed 16 characters";
        unset($_POST['password']);
    }
}else{
    $passwordErr = "Password is Required";
}if(isset($_POST['reppassword'])){
    $reppassword = $_POST['reppassword'];
    if(empty($_POST['reppassword'])){
        $reppasswordErr = "Repeat your Password";
        unset($_POST['reppassword']);
    }elseif($_POST['reppassword'] !== $password){
        $reppasswordErr = "The passwords dont match";
        unset($_POST['reppassword']);
    }
}else{
    $reppasswordErr = "Repeat your Password";
}
if($firstnameErr == ''  and  $emailErr == '' and  $lastnameErr == '' and $roleErr == '' and $passwordErr == '' and $reppasswordErr == ''){
    $insert = "INSERT INTO users (FIRST_NAME ,LAST_NAME ,EMAIL ,PASSWORD ,ROLE ) VALUES ('$firstname','$lastname','$email','$password','$role')";
    $result1 = mysqli_query($conn, $insert);
    if($result1){header('Location: '.$_SERVER['PHP_SELF'].'?success');
    die(); }else{
        echo "failed to insert";
    }}else{
       header('Location: '.$_SERVER['PHP_SELF'].'?regerror');
     }}?>