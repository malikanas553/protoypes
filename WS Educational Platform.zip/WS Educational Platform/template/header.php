
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <link rel="stylesheet" href="style.css">
</head>
<body>    
    <header class="mainheader">
        <div class="maintopnav">
            <div class="visibletopnav">
            <a href="javascript:void(0);" class="icon" onclick="myFunction()">
        <i class="fa fa-bars"></i>
    </a>
    <script>
        
        function myFunction() {
      var x = document.getElementById("mainnavitems");
      if (x.style.display == "block") {
        x.style.display = "none"
      
      } else {
        x.style.display = "block"
      }
    }
    </script>

        <img src="mainlogo.png" width="118px" height="18px" class="logo">
        <img src="mainlogo.png" width="280px" height="40px" class="logo2">
        <img src="mainlogo.png" width="330px" height="45px" class="logo3">
        <a href="javascript:void(0);" class="searchicon" onclick="myFunctions()" id="searchicon">
        <i class="fa fa-search"></i>
        </a>
    </div>
    <form class="search" id="search" method="GET" action="courses.php">
        <input type="search" name="search" placeholder="Search.." class="searchbar">
    </form>
        <nav class="navitems" id="mainnavitems">
        <?php if(!(isset($_SESSION['ID']) && ($_SESSION['ROLE'] == 'admin' || $_SESSION['ROLE'] == 'superadmin'))){?>
        <a href="index.php" class="navitem">Home</a>
        <a href="index.php#aboutsection" class="navitem">About</a>
        <?php if (isset($_SESSION['ID']) && $_SESSION['ROLE'] == 'Teacher'){?>
        <a href="addcourse.php" class="navitem" onclick="closelectureform()">Add New Course</a>
        <a href="courses.php" class="navitem">View/Edit Your Courses</a>
        <?php }else{?>
        <a href="courses.php" class="navitem">All Courses</a>
        <a href="courses.php?frontend" class="navitem">Front End</a>
        <a href="courses.php?backend" class="navitem">Back End</a>
        <?php }}else{?>
        <a href="adminindex.php" class="navitem">Statistics</a>
        <a href="users.php?students" class="navitem"> View Students</a>
        <a href="users.php?teachers" class="navitem">View Teachers</a>
        <?php if($_SESSION['ROLE'] == "superadmin"){?> <a href="users.php?admins" class="navitem">View Admins</a> <?php }?>
        <form method="POST" action="adminindex.php" class="editcourses">
        <a href="javascript:void(0)" onclick="this.closest('form').submit();return false;" class="navitem">Edit Courses</a>
        </form>
        <?php }if (!isset($_SESSION['ID'])){?>
        <a href="login.php" class="navitem">Log In</a>
        <?php }else{?>
          <a href="logout.php" class="navitem">Log Out</a>
        <?php }?>
        
        </nav>
            <form class="search" id="search2" method="GET" action="courses.php">
                <input type="search" name="search" placeholder="Search.." class="searchbar" id="searchbar2">
                
            </form>
        <a href="javascript:void(0);" class="searchicon2" onclick="myFunctionsa()" id="searchicon2">
        <i class="fa fa-search"></i></a>
        <script>
             function myFunctions(){
      var x = document.getElementById("search")
      var y = document.getElementById("searchicon")
      if (x.style.display == "block") {
        x.style.display = "none";
        y.classList.remove("active");
      }else{
        x.style.display = "block";
        y.classList.add("active");
       
      }
    }
    function myFunctionsa(){
      var x = document.getElementById("search2")
      var y = document.getElementById("searchicon2")
      var z = document.getElementById("mainnavitems")
      if (x.style.display == "block") {
        x.style.display = "none";
        y.classList.remove("active");
        z.style.display = "flex";
      }else{
        x.style.display = "block";
        y.classList.add("active");
        z.style.display = "none";
      }
    }
        </script>
        
    </div>  
    <form class="search" id="search2" method="GET" action="courses.php">
        <input type="search" name="search" placeholder="Search.." class="searchbar">
        
    </form>
    </header>
    <?php 
    if(isset($_SESSION['ID'])){
    $sqlsw = "SELECT *  FROM users WHERE USER_ID = '$_SESSION[ID]'";
    $resultsw = mysqli_query($conn,$sqlsw);
    $rowsw = mysqli_fetch_assoc($resultsw);?>
    <form method="POST" action="process.php">
    
    
    <?php
    if($rowsw['ROLE'] !== "Student"){?>
    <input type="submit" class="fixedbtn" <?php if($_SESSION['ROLE'] == "Student"){?> name="teacher" value="Teacher View"
      <?php }else{ ?>name="student" value="Student View" <?php }?>>
    <?php }
    if(!($_SESSION['ROLE'] == "admin" || $_SESSION['ROLE'] == "superadmin") && ($rowsw['ROLE'] == "admin" || $rowsw['ROLE'] == "superadmin")){?>
    <input type="submit" class="fixedbtn admin" name="admin" value="Admin View">
    <?php }}?>
    </form>
