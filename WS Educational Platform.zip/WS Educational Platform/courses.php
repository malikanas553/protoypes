<?php
session_start();
require 'connect.php';
error_reporting(0);
if(isset($_SESSION['ID'])){
    $sql= "SELECT STATUS FROM users WHERE USER_ID = '$_SESSION[ID]'";
$result= mysqli_query($conn,$sql);
$row = mysqli_fetch_assoc($result);
if($row['STATUS'] == "Banned"){
    header("Location:logout.php");
    die;
}
}
?>
<!DOCTYPE html>
<html>
    <head>
    <title>Courses Page</title>
<?php include 'template/header.php';
?>

    <?php
    $x = 0;
    if(isset($_GET['search'])){
    $search=$conn -> real_escape_string($_GET['search']);?>
    <h1 class="pagehead">SEARCH RESULTS</h1>
    <section class="courses">
<?php $sql="SELECT * FROM courses WHERE COURSE_NAME LIKE '%$search%'";
$result= mysqli_query($conn,$sql);  
if(mysqli_num_rows($result) > 0){  
while($row = mysqli_fetch_assoc($result)){?>
    <div class="course">
    <img src=<?= $row['COURSE_PIC']?> width="100%" height="100%" class="coursepic">
    <div class="paddingcontainer">
    <h5 class="coursename"><?= $row['COURSE_NAME']?></h5>
    <p class="coursedecript"><?= $row['COURSE_DESCRIPT']?></p>
    
</div>
    <div class="purchase">
     <a <?php if(isset($_SESSION['ID'])){?>href="coursepage.php?courseid=<?= $row['COURSE_ID']?>"<?php }else{?> href="login.php" onclick=" return confirm('To view our courses you are required to sign in first.Do you want to sign in now?')"<?php }?> class="purchasebtn">View Course</a>
</div>
</div> 
<?php }?>
</section>
<?php }else{?>
   <spam class="Noresult">No Results Found</spam>
<?php }}
     elseif(isset($_GET['frontend'])){?>
<h1 class="pagehead">FRONT-END COURSES</h1>
<section class="courses">
<?php $sql="SELECT * FROM courses WHERE COURSE_TYPE = 'frontend'";
$result= mysqli_query($conn,$sql);  
   
while($row = mysqli_fetch_assoc($result)){?>
    <div class="course">
    <img src=<?= $row['COURSE_PIC']?> width="100%" height="100%" class="coursepic">
    <div class="paddingcontainer">
    <h5 class="coursename"><?= $row['COURSE_NAME']?></h5>
    <p class="coursedecript"><?= $row['COURSE_DESCRIPT']?></p>
    
</div>
    <div class="purchase">
     <a <?php if(isset($_SESSION['ID'])){?>href="coursepage.php?courseid=<?= $row['COURSE_ID']?>"<?php }else{?> href="login.php" onclick=" return confirm('To view our courses you are required to sign in first.Do you want to sign in now?')"<?php }?> class="purchasebtn">View Course</a>
</div>
</div> 
<?php }?>
</section>
    <?php ;}elseif(isset($_GET['backend'])){?>
        <h1 class="pagehead">BACK-END COURSES</h1>
<section class="courses">
<?php 
$sql="SELECT * FROM courses WHERE COURSE_TYPE = 'backend'";
$result= mysqli_query($conn,$sql);  
   
while($row = mysqli_fetch_assoc($result)){?>
    <div class="course">
    <img src=<?= $row['COURSE_PIC']?> width="100%" height="100%" class="coursepic">
    <div class="paddingcontainer">
    <h5 class="coursename"><?= $row['COURSE_NAME']?></h5>
    <p class="coursedecript"><?= $row['COURSE_DESCRIPT']?></p>
    
</div>
    <div class="purchase">
     <a <?php if(isset($_SESSION['ID'])){?>href="coursepage.php?courseid=<?= $row['COURSE_ID']?>"<?php }else{?> href="login.php" onclick=" return confirm('To view our courses you are required to sign in first.Do you want to sign in now?')"<?php }?> class="purchasebtn">View Course</a>
</div>
</div> 
<?php }?>
</section>
    <?php ;}elseif(isset($_SESSION['ID']) && $_SESSION['ROLE'] == 'Teacher'){
        
        $sql = "SELECT ROLE FROM users WHERE USER_ID = '$_SESSION[ID]'";
        $result= mysqli_query($conn,$sql); 
        $row =  mysqli_fetch_assoc($result);
        ?>
        <h1 class="pagehead"><?php if($row['ROLE'] == 'Teacher'){echo "YOUR COURSES";}else{echo "ALL COURSES";}?></h1>
<section class="courses">
<?php 
if($row['ROLE'] == 'Teacher'){
$sql="SELECT * FROM courses WHERE USER_ID = '$_SESSION[ID]'";}
else{
    $sql="SELECT * FROM courses";
}
$result= mysqli_query($conn,$sql);  
   
while($row = mysqli_fetch_assoc($result)){?>
    <div class="course">
    <img src=<?= $row['COURSE_PIC']?> width="100%" height="100%" class="coursepic">
    <div class="paddingcontainer">
    <h5 class="coursename"><?= $row['COURSE_NAME']?></h5>
    <p class="coursedecript"><?= $row['COURSE_DESCRIPT']?></p>
    
</div>
    <div class="purchase">
     <a href="coursepage.php?courseid=<?= $row['COURSE_ID']?>&edit" class="purchasebtn">Edit Course</a>
</div>
</div> 
<?php }?>
</section>
<?php }else{?>
        <h1 class="pagehead">ALL COURSES</h1>
<section class="courses">
<?php $sql="SELECT * FROM courses";
$result= mysqli_query($conn,$sql);  
   
while($row = mysqli_fetch_assoc($result)){?>
    <div class="course">
    <img src=<?= $row['COURSE_PIC']?> width="100%" height="100%" class="coursepic">
    <div class="paddingcontainer">
    <h5 class="coursename"><?= $row['COURSE_NAME']?></h5>
    <p class="coursedecript"><?= $row['COURSE_DESCRIPT']?></p>
    
</div>
    <div class="purchase">
     <a <?php if(isset($_SESSION['ID'])){?>href="coursepage.php?courseid=<?= $row['COURSE_ID']?>"<?php }else{?> href="login.php" onclick=" return confirm('To view our courses you are required to sign in first.Do you want to sign in now?')"<?php }?> class="purchasebtn">View Course</a>
</div>
</div> 
<?php }?>
</section>
    <?php ;}



include 'template/footer.html';
?>