<?php
session_start();
require 'connect.php';
error_reporting(0);
if(!isset($_SESSION['ID'])){
    header("Location:login.php");
    die;
}
$sql= "SELECT STATUS FROM users WHERE USER_ID = '$_SESSION[ID]'";
$result= mysqli_query($conn,$sql);
$row = mysqli_fetch_assoc($result);
if($row['STATUS'] == "Banned"){
    header("Location:logout.php");
    die;
}
if($_SERVER['REQUEST_METHOD'] == "POST"){
    if(isset($_POST['teacher'])){
        $_SESSION['ROLE'] = 'Teacher';
        header('Location:index.php');
        die;
    }elseif(isset($_POST['student'])){
        $_SESSION['ROLE'] = 'Student';
        header('Location:index.php');
        die;
    }elseif(isset($_POST['admin'])){
        $sql = "SELECT ROLE FROM users WHERE USER_ID = '$_SESSION[ID]'";
        $result = mysqli_query($conn,$sql);
        $role = mysqli_fetch_assoc($result);
        $_SESSION['ROLE'] = $role['ROLE'];
        header('Location:adminindex.php');
        die;
    }else{
        header("Location:login.php");
        die;
    }}else{
        header("Location:login.php");
        die;
    }