<?php
session_start();
require 'connect.php';
error_reporting(0);
if(!(isset($_SESSION['ID']) && ($_SESSION['ROLE'] !== 'Student'))){
    header("Location:login.php");
    die;
}
$sql= "SELECT STATUS FROM users WHERE USER_ID = '$_SESSION[ID]'";
$result= mysqli_query($conn,$sql);
$row = mysqli_fetch_assoc($result);
if($row['STATUS'] == "Banned"){
    header("Location:logout.php");
    die;
}
if($_SERVER['REQUEST_METHOD'] == "GET"){
  if(isset($_GET['banStudentid'])){
    $sql = "UPDATE users SET STATUS = 'Banned' WHERE USER_ID='$_GET[banStudentid]'";
    $result = mysqli_query($conn,$sql);
    if($result){
        header("Location:users.php?students");
        die;
    }else{
        echo "failed to ban";
    }
  }
  elseif(isset($_GET['banTeacherid'])){
    $sql = "UPDATE users SET STATUS = 'Banned' WHERE USER_ID='$_GET[banTeacherid]'";
    $result = mysqli_query($conn,$sql);
    if($result){
        header("Location:users.php?teachers");
        die;
    }else{
        echo "failed to ban";
    }
  }
  elseif(isset($_GET['banAdminid'])){
    $sql = "UPDATE users SET STATUS = 'Banned' WHERE USER_ID='$_GET[banAdminid]'";
    $result = mysqli_query($conn,$sql);
    if($result){
        header("Location:users.php?admins");
        die;
    }else{
        echo "failed to ban";
    }
  }elseif(isset($_GET['unbanid'])){
    $sql = "UPDATE users SET STATUS = 'Active' WHERE USER_ID='$_GET[unbanid]'";
    $result = mysqli_query($conn,$sql);
    if($result){
        header("Location:users.php?students");
        die;
    }else{
        echo "failed to ban";
    }}
  elseif(isset($_GET['makeStudentid'])){
    $sql = "UPDATE users SET ROLE = 'admin' WHERE USER_ID='$_GET[makeStudentid]'";
    $result = mysqli_query($conn,$sql);
    if($result){
        header("Location:users.php?admins");
        die;
    }else{
        echo "failed to add admin";
    }
  }
  elseif(isset($_GET['makeTeacherid'])){
    $sql = "UPDATE users SET ROLE = 'admin' WHERE USER_ID='$_GET[makeTeacherid]'";
    $result = mysqli_query($conn,$sql);
    if($result){
        header("Location:users.php?admins");
        die;
    }else{
        echo "failed to add admin";
    }
  }elseif(isset($_GET['makeadminid'])){
    $sql = "UPDATE users SET ROLE = 'Student' WHERE USER_ID='$_GET[makeadminid]'";
    $result = mysqli_query($conn,$sql);
    if($result){
        header("Location:users.php?admins");
        die;
    }else{
        echo "failed to demote admin";
    }
  }elseif(isset($_GET['deletecourse'])){
    $sql = "DELETE FROM courses WHERE COURSE_ID = '$_GET[deletecourse]'";
    $result = mysqli_query($conn,$sql);
   
    if($result){
      $sql = "DELETE FROM lectures WHERE COURSE_ID = '$_GET[deletecourse]'";
      $result = mysqli_query($conn,$sql);
      if($result){
          header("Location:courses.php?yourcourses");
          die;}else{
            echo "Failed to Delete";
          }
    }else{
        echo "Failed to Delete";
    }
  }elseif(isset($_GET['deletelecture'])){
    $sql = "DELETE FROM lectures WHERE LECTURE_ID = '$_GET[deletelecture]'";
    $result = mysqli_query($conn,$sql);
    if($result){
          header("Location:courses.php?yourcourses");
          die;
    }else{
        echo "Failed to Delete";
        header("Location:courses.php?yourcourses");
        die;
    }
  }


}
else{
    header("Location:courses?yourcourses.php");
    die;
}