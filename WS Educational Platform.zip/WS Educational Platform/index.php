<?php
session_start();
require 'connect.php';
error_reporting(0);
$reviewErr = $notification = '';
if(isset($_SESSION['ID'])){
    $sql= "SELECT * FROM users WHERE USER_ID = '$_SESSION[ID]'";
$result= mysqli_query($conn,$sql);
$row = mysqli_fetch_assoc($result);
if($row['STATUS'] == "Banned"){
    header("Location:logout.php");
    die;
}
}
if($_SERVER['REQUEST_METHOD'] == "POST"){
  $sql = "SELECT * FROM reviews WHERE USER_ID= '$_SESSION[ID]'";
  $result = mysqli_query($conn,$sql);
  if(isset($_POST['rating'])){
  if(mysqli_num_rows($result) > 0 ){
      $sql2 = "UPDATE reviews SET REVIEW = '$_POST[review]', STAR_REVIEW = '$_POST[rating]' WHERE USER_ID = '$_SESSION[ID]'";
      $result2 = mysqli_query($conn,$sql2);
      if($result2){
          $notification = "success";
      }else{ 
        $notification = "fail";
      }
  }else{
    $sql2 = "INSERT INTO reviews  (USER_ID,REVIEW,STAR_REVIEW) VALUES('$_SESSION[ID]','$_POST[review]','$_POST[rating]')";
    $result2 = mysqli_query($conn,$sql2);
    if($result2){
        $notification = "success";
    }else{
        $notification = "fail";
    }
  }}else{
    $reviewErr = "Star rating is required";
  }
}
?>
<!DOCTYPE html>
<html>
    <head>
    <title>WS HOME</title>
<?php include 'template/header.php';
?>
<main>
<?php 
    if(isset($_SESSION['ID'])){
    if($notification == "success"){?>
    <script>
        function closenotification(){
            var y = document.getElementById("success")
        y.style.display = "none"
        }
    </script>
    
    <div class="notification" id="success">
          <p>Your review has been submitted successfully</p><a href="javascript:void(0)" class="close" onclick="closenotification()">x</a>
    </div>
   
    <?php }elseif($notification == "fail"){?>
    <script>
        function closenotification(){
            var y = document.getElementById("fail")
        y.style.display = "none"
        }
    </script>
    <div class="notification" id="fail">
          <p>Your review has failed to submit</p><a href="javascript:void(0)" class="close" onclick="closenotification()">x</a>
    </div>
    <?php }else{?>
        <script>
        function closenotification(){
            var y = document.getElementById("login")
        y.style.display = "none"
        }
    </script>
    <div class="notification" id="login">
          <p>You are logged in as <?=ucfirst($row['FIRST_NAME'])?> <?= ucfirst($row['LAST_NAME'])?>: <?=$_SESSION['ROLE']?> </p><a href="javascript:void(0)" class="close" onclick="closenotification()">x</a>
    </div>
    <?php }}?>
<section class="jumbtron">

    <div class="jumbtroncontent">
        <p>Become a full stack web developer right here and <b class="now">NOW!</b></p><br>
        <?php if(isset($_SESSION['ID'])){?>
        <a href="courses.php" class="joinusbtn">Start Exploring</a>
        <?php }else{?>
        <a href="register.php" class="joinusbtn">Join us now</a>
        <?php }?>
</div>
</section>
<section class="aboutsect" id="aboutsection">
    <article>
    <div class="aboutcontent">
    
    <h1 class="sectionhead">About Us</h1>
    <p><b>Lorem ipsum dolor sit amet consectetur, adipisicing elit.
        Commodi amet, vel ipsa corrupti eligendi ea impedit ad tempora atque
        placeat sint repellat porro quam harum incidunt 
        accusamus dolor possimus consectetur.</b></p>
        <p><b>Lorem ipsum dolor sit amet consectetur, adipisicing elit.
            Commodi amet, vel ipsa corrupti eligendi ea impedit ad tempora atque
            placeat sint repellat porro quam harum incidunt 
            accusamus dolor possimus consectetur.</b></p>
    <h1 class="sectionhead">Why Choose Web Starters?</h1>
    <p><b>Lorem ipsum dolor sit amet consectetur, adipisicing elit.
        Commodi amet, vel ipsa corrupti eligendi ea impedit ad tempora atque
        placeat sint repellat porro quam harum incidunt 
        accusamus dolor possimus consectetur.</b></p>
        <p><b>Lorem ipsum dolor sit amet consectetur, adipisicing elit.
            Commodi amet, vel ipsa corrupti eligendi ea impedit ad tempora atque
            placeat sint repellat porro quam harum incidunt 
            accusamus dolor possimus consectetur.</b></p>
    </div>
    </article>
</section>
<section class="coursessect">
    <h1 class="sectionhead">Our Most Popular courses</h1>
    <section class="popular">
    <?php $sql="SELECT * FROM courses ORDER BY HIT_NO DESC";
$result= mysqli_query($conn,$sql);  
while($row = mysqli_fetch_assoc($result)){?>
    <div class="course">
    <img src=<?= $row['COURSE_PIC']?> width="100%" height="100%" class="coursepic">
    <div class="paddingcontainer">
    <h5 class="coursename"><?= $row['COURSE_NAME']?></h5>
    <p class="coursedecript"><?= $row['COURSE_DESCRIPT']?></p>
    
</div>
    <div class="purchase">
    <a <?php if(isset($_SESSION['ID'])){?>href="coursepage.php?courseid=<?= $row['COURSE_ID']?>"<?php }else{?> href="login.php" onclick=" return confirm('To view our courses you are required to sign in first.Do you want to sign in now?')"<?php }?> class="purchasebtn">View Course</a>
</div>
</div> 
<?php }?>
    </section>
    <h2 class="sectionsubhead">Front end courses</h2>
    <section class="popularfront">
    <?php $sql="SELECT * FROM courses WHERE COURSE_TYPE = 'frontend' ORDER BY HIT_NO DESC";
$result= mysqli_query($conn,$sql);  
   
while($row = mysqli_fetch_assoc($result)){?>
    <div class="course">
    <img src=<?= $row['COURSE_PIC']?> width="100%" height="100%" class="coursepic">
    <div class="paddingcontainer">
    <h5 class="coursename"><?= $row['COURSE_NAME']?></h5>
    <p class="coursedecript"><?= $row['COURSE_DESCRIPT']?></p>
    
</div>
    <div class="purchase">
     <a <?php if(isset($_SESSION['ID'])){?>href="coursepage.php?courseid=<?= $row['COURSE_ID']?>"<?php }else{?> href="login.php" onclick=" return confirm('To view our courses you are required to sign in first.Do you want to sign in now?')"<?php }?> class="purchasebtn">View Course</a>
</div>
</div> 
<?php }?>
    </section>
    <h2 class="sectionsubhead">Back End courses</h2>
    <section class="popularback">
    <?php $sql="SELECT * FROM courses WHERE COURSE_TYPE = 'backend' ORDER BY HIT_NO DESC";
$result= mysqli_query($conn,$sql);  
   
while($row = mysqli_fetch_assoc($result)){?>
    <div class="course">
    <img src=<?= $row['COURSE_PIC']?> width="100%" height="100%" class="coursepic" class="coursepic">
    <div class="paddingcontainer">
    <h5 class="coursename"><?= $row['COURSE_NAME']?></h5>
    <p class="coursedecript"><?= $row['COURSE_DESCRIPT']?></p>
    
</div>
    <div class="purchase">
     <a <?php if(isset($_SESSION['ID'])){?>href="coursepage.php?courseid=<?= $row['COURSE_ID']?>"<?php }else{?> href="login.php" onclick=" return confirm('To view our courses you are required to sign in first.Do you want to sign in now?')"<?php }?> class="purchasebtn">View Course</a>
</div>
</div> 
<?php }?>
    </section>
</section>
<h1 class="sectionhead">What Experts Say About Us</h1>
<section class="reviewsection">
    
    <section class="reviews"> 
        <article class="quote">
            <h2 class="expertname">Ahmad Tibin</h2>
            <q><i>Lorem ipsum dolor sit amet consectetur adipisicing elit. Praesentium assumenda quod dolores voluptates minima voluptatum odio!</i></q>
        </article>
        <article class="quote2">
            <h2 class="expertname">Ahmad Tibin</h2>
            <q><i>Lorem ipsum dolor sit amet consectetur adipisicing elit. Praesentium assumenda quod dolores voluptates minima voluptatum odio!</i></q>
        </article>
        <article class="quote3">
            <h2 class="expertname">Ahmad Tibin</h2>
            <q><i>Lorem ipsum dolor sit amet consectetur adipisicing elit. Praesentium assumenda quod dolores voluptates minima voluptatum odio!</i></q>
        </article>
    </section>
    <section class="leavereview" id="leavereview">
        <div class="leavereviewcontent">
        <?php if(!isset($_SESSION['ID'])){?>
            <p class="noreview"><a href="login.php">SIGN IN</a> to leave a review</p>
            <?php }else{?>
        <section class="starsection">
        <form class="reviewform" action="" method="POST">
        <h2 class="leavereviewhead">Leave your own review Here! </h2><spam class="error"><?= $reviewErr?></spam>
        <h3 class="leavereviewsubhead">Rate out of five stars</h3>
        <spam class="star-rating">
            <input type="radio" name="rating" value="1"><i class="star"></i>
            <input type="radio" name="rating" value="2"><i class="star"></i>
            <input type="radio" name="rating" value="3"><i class="star"></i>
            <input type="radio" name="rating" value="4"><i class="star"></i>
            <input type="radio" name="rating" value="5"><i class="star"></i>
          </spam>
        </section>
        
        <section class="writereview">
        <h2 class="leavereviewhead write">Write your review</h2>
        
        <textarea maxlength="300" placeholder="Your Review Here" class="formControl" max="" name="review"></textarea><br>
        <input type="submit" value="Submit" class="primarybtn">
</form>
</section>
<?php }?>
</div>
    </section>
</section>
</main>

<?php 
include 'template/footer.html';
?>
