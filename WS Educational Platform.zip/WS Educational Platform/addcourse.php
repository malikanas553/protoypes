<?php
session_start();
require 'connect.php';
error_reporting(0)
if(!isset($_SESSION['ID']) || $_SESSION['ROLE']!= 'Teacher'){
    header('Location: login.php');
    die;
}

$userid = $_SESSION['ID'];
$sql= "SELECT STATUS FROM users WHERE USER_ID = '$_SESSION[ID]'";
$result= mysqli_query($conn,$sql);
$row = mysqli_fetch_assoc($result);
if($row['STATUS'] == "Banned"){
    header("Location:logout.php");
    die;
}
$coursename = $coursetype = $coursedescript = $coursepic =  $lecturename1 = $lecturedescript1 = $lectureurl1 = '';
$coursenameErr = $coursetypeErr = $coursedescriptErr = $coursepicErr =  $lecturename1Err = $lecturedescript1Err = $lectureurl1Err = '';
if($_SERVER['REQUEST_METHOD'] == "POST"){
    if(isset($_POST["coursename"])){
        $coursename=$conn -> real_escape_string($_POST["coursename"]);
        if(empty($_POST["coursename"])){
        $coursenameErr = "Course Name is required";
        unset($_POST["coursename"]);
    }}else{ 
$coursenameErr = "Course Name is required";
}
if(isset($_FILES["uploadfile"]) && !empty($_FILES["uploadfile"]["name"])){
    $filename = $_FILES["uploadfile"]["name"];
   $tempname = $_FILES["uploadfile"]["tmp_name"];    
    $folder = $filename;
    move_uploaded_file($tempname, $folder);}else{
        $filename = "Nocover.jpg";
    }
if(!isset($_POST["coursetype"])){
    $coursetypeErr ="Please choose a course type";

}else{
    $coursetype= $_POST["coursetype"];
}if(isset($_POST['coursedescript'])){
    $coursedescript = $_POST['coursedescript'];
    if(empty($_POST['coursedescript'])){
        $coursedescriptErr = "Course description is Required";
        unset($_POST['coursedescript']);
    }
}else{
    $coursedescriptErr = "Course description is Required";
} 
if(isset($_POST["lecturename1"])){
    $lecturename1=$_POST["lecturename1"];
    if(empty($_POST["lecturename1"])){
    $lecturename1Err = "Lecture Name is required";
    unset($_POST["lecturename1"]);
}}else{ 
$lecturename1Err = "Lecture Name is required";
}
if(isset($_POST['lecturedescript1'])){
    $lecturedescript1 = $_POST['lecturedescript1'];
    if(empty($_POST['lecturedescript1'])){
        $lecturedescript1Err = "Lecture Description is Required";
        unset($_POST['lecturedescript1']);
    }
}else{
    $lecturedescript1Err = "Lecture description is Required";
} 
if(isset($_POST["lectureurl1"])){
    $lectureurl1 = $_POST["lectureurl1"];
    if(empty($_POST["lectureurl1"])){
        $lectureurl1Err = "Lecture URL is required";
        unset($_POST["lectureurl1"]);
    }elseif (!filter_var($lectureurl1, FILTER_VALIDATE_URL)) {
        $lectureurl1Err = "Lecture URL is invalid";
        unset($_POST["lectureurl1"]);
    }elseif(!strpos($_POST["lectureurl1"],'youtube.com')){
        $lectureurl1Err = "Lecture URL is not a youtube url";
        unset($_POST["lectureurl1"]);
    }elseif(strpos($_POST["lectureurl1"],'embed')){
            $str = strstr($_POST["lectureurl1"], 'embed/');
            $url = substr($str, 6);
            $sql = "SELECT * FROM lectures WHERE LECTURE_URL = '$url'";
        $result = mysqli_query($conn, $sql);
            if (mysqli_num_rows($result) > 0) {
                $lectureurl1Err = 'Lecture URL already exists';
        
        }}else{
            $url = $_POST["lectureurl1"];
            parse_str( parse_url( $url, PHP_URL_QUERY ), $my_array_of_vars );
            $url = $my_array_of_vars['v'];
            $sql = "SELECT * FROM lectures WHERE LECTURE_URL = '$url'";
            $result = mysqli_query($conn, $sql);
                if (mysqli_num_rows($result) > 0) {
                    $lectureurl1Err = 'Lecture URL already exists';
            
            }
            
        }
}else{
    $lectureurl1Err = "Lecture URL is required";
}
if($coursenameErr == ''  and  $coursetypeErr == '' and  $coursedescriptErr == '' and $coursepicErr == '' and  $lecturename1Err == '' and $lecturedescript1Err == '' and $lectureurl1Err == ''){
    $insert = "INSERT INTO courses (USER_ID,COURSE_NAME,COURSE_PIC,COURSE_DESCRIPT,COURSE_TYPE,HIT_NO ) VALUES ('$userid','$coursename','$filename','$coursedescript','$coursetype',0)";
    $result1 = mysqli_query($conn, $insert);
    $sql = "SELECT COURSE_ID FROM courses WHERE COURSE_NAME = '$coursename' AND COURSE_DESCRIPT = '$coursedescript'";
    $result = mysqli_query($conn,$sql);
    $redirect = mysqli_fetch_assoc($result);
    if($result1){
    $sqlselect = "SELECT * FROM courses WHERE COURSE_NAME = '$coursename' AND COURSE_DESCRIPT = '$coursedescript'";
    $result2 = mysqli_query($conn,$sqlselect);
    $row = mysqli_fetch_assoc($result2);
    $insert2 = "INSERT INTO lectures (COURSE_ID,LECTURE_NO,LECTURE_NAME,LECTURE_DESCRIPT,LECTURE_URL) VALUES ('$row[COURSE_ID]','1','$lecturename1','$lecturedescript1','$url')";
    $result3 = mysqli_query($conn,$insert2);
    if($result3){
    header("Location: coursepage.php?courseid=".$redirect['COURSE_ID']);
    die(); }else{
        echo "failed to insert";
    }}else{
        echo "failed to insert";
    }}}
?>
<!DOCTYPE html>
<html>
    <head>
    <title>ADD COURSE</title>
<?php include 'template/header.php';
?>

    <form method="POST" action="" class="addcourseform" enctype="multipart/form-data">
        <section class="addcoursesect">
            <h2 class="loginhead">Course Details</h2>
            <label for="coursename">Course name </label><spam class="error"><?= $coursenameErr?></spam>
            <input type="text" name="coursename" placeholder="The name of your course" class="field" value=<?= $coursename?>>
            <label for="coursetype">Course Type </label> <spam class="error"><?= $coursetypeErr?></spam><br>
            <select class="field" name="coursetype">
                <option disabled selected>Choose course type</option>
                <option value="frontend" name="coursetype" <?php if($coursetype == 'frontend'){echo "selected";}?>>Front-End</option>
                <option value="backend" name="coursetype" <?php if($coursetype == 'backend'){echo "selected";}?>>Back-End</option>
            </select>
            <label for="coursedescript">Course Description </label> <spam class="error"><?= $coursedescriptErr?></spam><br><br>
            <textarea maxlength="300" placeholder="A short description about your course" class="formControl" max="" name="coursedescript"><?= $coursedescript?></textarea><br>
            <label for="coursepic">Course Front Cover<spam class="optional">(optional)</spam> <spam class="error"></label>
            <input type="file" name="uploadfile"  class="primarybtn upload" />
</section><br><br>
        <section class="addlecturessect">
           <h2 class="loginhead">Lecture details</h2>
          <h3>Lecture 1</h3>
          <label for="lecturename1">Lecture Name </label><spam class="error"><?= $lecturename1Err?></spam>
          <input type="text" placeholder="Name of Lecture 1" name="lecturename1" class="field" value=<?= $lecturename1?>>
          <label for="lecturedescript1">Lecture Description </label><spam class="error"><?= $lecturedescript1Err?></spam><br>
          <textarea maxlength="2000" placeholder="About the lecture" class="formControl" max="" name="lecturedescript1"><?= $lecturedescript1?></textarea><br>
          <label for="lectureurl1">Lecture Video URL </label><spam class="error"><?= $lectureurl1Err?></spam>
          <input type="text" placeholder="Paste Youtube Url Here" name="lectureurl1" class="field"  value=<?= $lectureurl1?>>
        </section>
        <input type="submit" name="uploadfile" class="loginbtn">
        </form>
        <?php 
         

        include 'template/footer.html' ?>
