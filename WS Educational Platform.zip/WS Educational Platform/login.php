<?php
session_start();
require 'connect.php';
error_reporting(0);
$x ="SELECT * FROM users";
$result=mysqli_query($conn,$x);
if (mysqli_num_rows($result) == 0){
    header("Location:register.php");
    die();}
elseif(isset($_SESSION['ID'])){
    if($_SESSION['ROLE'] == 'admin' || $_SESSION['ROLE'] == 'superadmin'){
        header("Location: adminindex.php");
        die;
    
    }else{
        header("Location: index.php");
        die;
       
    }
 
}

$email = $password = '';
$emailErr = $passwordErr = $Err ='';
if($_SERVER['REQUEST_METHOD'] == "POST"){
if(isset($_POST["email"])){
    $email = $_POST["email"];
    if(empty($_POST["email"])){
        $emailErr = "Email is required";
        unset($_POST["email"]);
        unset($_POST['password']);
    }elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $emailErr = "Invalid email";
        unset($_POST["email"]);
        unset($_POST['password']);
    }
}else{
    $emailErr = "Email is required";
}if(isset($_POST['password'])){
    if(empty($_POST['password'])){
        $passwordErr = 'Password is required';
        unset($_POST['email']);
        unset($_POST['password']);
    }elseif($emailErr == ''){$sql = "SELECT * FROM users WHERE Email = '$_POST[email]' AND Password = '$_POST[password]'";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    if(mysqli_num_rows($result) == 0){
        $Err = "Incorrect Email or Password";
        unset($_POST['email']);
        unset($_POST['password']);
    }else{
    $sql = "SELECT STATUS FROM users WHERE USER_ID = '$row[USER_ID]'";
    $result = mysqli_query($conn,$sql);
    $status = mysqli_fetch_assoc($result);
    if($status['STATUS'] == "Banned"){
        $Err = "You are banned from this website";
    }else{
    $_SESSION['ID']=$row['USER_ID'];
    $_SESSION['ROLE']=$row['ROLE'];
    if($_SESSION['ROLE'] == 'admin' || $_SESSION['ROLE'] == 'superadmin'){
        header("Location: adminindex.php");
        die;
    
    }else{
        header("Location: index.php");
        die;
       
    }}
}}}else{
    $passwordErr = "Password is required";
    unset($_POST['email']);
    unset($_POST['password']);}}?>

<!DOCTYPE html>
<html>
    <head>
    <title>WS LOGIN</title>
<meta content="width=device-width, initial-scale=1" name="viewport" />
    <?php include 'template/header.php'; ?>
</head>

<?php
if(isset($_GET['success'])){?>


<script>
    history.pushState(null, "", location.href.split("?")[0]);
 
</script>
<?php }
if(isset($_GET['regerror'])){?>
<script>
    history.pushState(null, "", location.href.split("?")[0]);
</script>
<?php }?>   
<section class="login" id="login">
    <div class="loginbox">
        <h1 class="loginhead">Log In</h1>
        <form method="POST" action=""><spam class="error"><?= $Err?></spam><br>
            <label for="email">Email </label><spam class="error"><?= $emailErr?></spam>
            <input type="email" name="email" class="field" placeholder="Email address" value="<?= $email?>">
            <label for="password">Password </label><spam class="error"><?= $passwordErr?>
            <input type="password" name="password" class="field" placeholder="Enter your password" value="<?= $password?>">
            <button type="submit" value="Log In" class="loginbtn" name="login">Log In</button><br>
            <spam class="noaccount">Dont have an account?<br><a href="register.php" class="primarybtn.login">Register Now</a></spam>

        </form>
    </div>
</section>
<?php 
include 'template/footer.html';
?>