-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 01, 2022 at 11:27 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `webplatform`
--

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `USER_ID` int(10) UNSIGNED NOT NULL,
  `COURSE_ID` int(10) UNSIGNED NOT NULL,
  `COURSE_PIC` varchar(100) NOT NULL DEFAULT 'Nocover.jpg',
  `COURSE_NAME` varchar(200) NOT NULL,
  `COURSE_DESCRIPT` varchar(200) NOT NULL,
  `COURSE_TYPE` varchar(50) NOT NULL,
  `HIT_NO` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`USER_ID`, `COURSE_ID`, `COURSE_PIC`, `COURSE_NAME`, `COURSE_DESCRIPT`, `COURSE_TYPE`, `HIT_NO`) VALUES
(1, 1, 'Natuto-Logo.jpg', 'Naruto Shippuuden', 'Course Where you can learn how to perform all kinds of ninja skills', 'backend', 209),
(1, 4, '63d9b0acd7e81cde54f291bdcf8a24df.webp', 'HTML', 'Dive into the world of html', 'frontend', 37),
(5, 15, 'Nocove.jpg', 'Javascript', 'b', 'backend', 92),
(5, 19, 'download.jpg', 'CSS', 'sdfsdfs', 'frontend', 6);

-- --------------------------------------------------------

--
-- Table structure for table `lectures`
--

CREATE TABLE `lectures` (
  `COURSE_ID` int(10) UNSIGNED NOT NULL,
  `LECTURE_ID` int(10) UNSIGNED NOT NULL,
  `LECTURE_NO` int(30) UNSIGNED NOT NULL,
  `LECTURE_NAME` varchar(200) NOT NULL,
  `LECTURE_DESCRIPT` varchar(3000) NOT NULL,
  `LECTURE_URL` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `lectures`
--

INSERT INTO `lectures` (`COURSE_ID`, `LECTURE_ID`, `LECTURE_NO`, `LECTURE_NAME`, `LECTURE_DESCRIPT`, `LECTURE_URL`) VALUES
(1, 1, 1, 'Chakra Control', 'Learn how to control your chakra and use it to perform daily activities ', 'u_1onhckHuw'),
(16, 13, 1, 's', 'dfs', 'zVgKnfN9i34'),
(15, 15, 2, 'Javascript', 'dsfdsf', '8VxJtaxVoKg'),
(1, 16, 2, 'Taijutsu', 'Physical training', 'vNmkCJ4Tcew'),
(19, 19, 1, 'Introduction', 'mf skf s', 'GHBLNXXdZ3c'),
(15, 20, 1, 'Javascript Syntax', 'javascript abc', '0xMFEE4uMgM');

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `USER_ID` int(11) NOT NULL,
  `REVIEW_ID` int(10) UNSIGNED NOT NULL,
  `REVIEW` varchar(255) NOT NULL DEFAULT 'No review',
  `STAR_REVIEW` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`USER_ID`, `REVIEW_ID`, `REVIEW`, `STAR_REVIEW`) VALUES
(5, 2, '', 5),
(1, 3, '', 3),
(2, 4, '', 3),
(10, 5, '', 3);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `USER_ID` int(10) UNSIGNED NOT NULL,
  `FIRST_NAME` varchar(50) NOT NULL,
  `LAST_NAME` varchar(30) NOT NULL,
  `EMAIL` varchar(30) NOT NULL,
  `PASSWORD` varchar(20) NOT NULL,
  `ROLE` varchar(20) NOT NULL DEFAULT 'student',
  `STATUS` varchar(15) NOT NULL DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`COURSE_ID`);

--
-- Indexes for table `lectures`
--
ALTER TABLE `lectures`
  ADD PRIMARY KEY (`LECTURE_ID`),
  ADD KEY `COURSE_ID` (`COURSE_ID`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`REVIEW_ID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`USER_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `COURSE_ID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `lectures`
--
ALTER TABLE `lectures`
  MODIFY `LECTURE_ID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `REVIEW_ID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `USER_ID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
