<?php
session_start();
require 'connect.php';
error_reporting(0);
if(!isset($_SESSION['ID'])){
    header('Location: login.php');
    die;
}
$sql= "SELECT * FROM users WHERE USER_ID = '$_SESSION[ID]'";
$result= mysqli_query($conn,$sql);
$row = mysqli_fetch_assoc($result);
if($row['STATUS'] == "Banned"){
    header("Location:logout.php");
    die;
}
if(!isset($_GET['courseid'])){
    header('location: index.php');
    die;
}else{

$courseid = $_GET['courseid'];
}
?>
<!DOCTYPE html>
<html>
    <head>
    <title>Course</title>
<?php include 'template/header.php';
?>


<?php  
if(isset($_GET['edit']) && $_SESSION['ROLE'] == 'Teacher'){
    $lecturename1 = $lecturedescript1 = $lectureurl1 = $lecturenumber = '';
    $lecturename1Err = $lecturenumberErr = $lecturedescript1Err = $lectureurl1Err = '';
    if($_SERVER['REQUEST_METHOD'] == "POST"){
    if(isset($_POST["lecturename1"])){
        $lecturename1=$_POST["lecturename1"];
        if(empty($_POST["lecturename1"])){
        $lecturename1Err = "Lecture Name is required";
        unset($_POST["lecturename1"]);
    }}else{ 
    $lecturename1Err = "Lecture Name is required";
    }
    $lecturenumber = $_POST['lecturenumber'];
    if(isset($_POST['lecturedescript1'])){
        $lecturedescript1 = $_POST['lecturedescript1'];
        if(empty($_POST['lecturedescript1'])){
            $lecturedescript1Err = "Lecture Description is Required";
            unset($_POST['lecturedescript1']);
        }
    }else{
        $lecturedescript1Err = "Lecture description is Required";
    } 
    if(isset($_POST["lectureurl1"])){
        $lectureurl1 = $_POST["lectureurl1"];
        if(empty($_POST["lectureurl1"])){
            $lectureurl1Err = "Lecture URL is required";
            unset($_POST["lectureurl1"]);
        }elseif (!filter_var($lectureurl1, FILTER_VALIDATE_URL)) {
            $lectureurl1Err = "Lecture URL is invalid";
            unset($_POST["lectureurl1"]);
        }elseif(!strpos($_POST["lectureurl1"],'youtube.com')){
            $lectureurl1Err = "Lecture URL is not a youtube url";
            unset($_POST["lectureurl1"]);
        }elseif(strpos($_POST["lectureurl1"],'embed')){
                $str = strstr($_POST["lectureurl1"], 'embed/');
                $url = substr($str, 6);
                $sql = "SELECT * FROM lectures WHERE NOT COURSE_ID = '$courseid' AND LECTURE_URL = '$url' ";
            $result = mysqli_query($conn, $sql);
                if (mysqli_num_rows($result) > 0) {
                    $lectureurl1Err = 'Lecture URL already exists';
            
            }}else{
                $url = $_POST["lectureurl1"];
                parse_str( parse_url( $url, PHP_URL_QUERY ), $my_array_of_vars );
                $url = $my_array_of_vars['v'];
                $sql = "SELECT * FROM lectures WHERE LECTURE_URL = '$url' AND NOT COURSE_ID = '$courseid'";
                $result = mysqli_query($conn, $sql);
                    if (mysqli_num_rows($result) > 0) {
                        $lectureurl1Err = 'Lecture URL already exists';
                
                }
                
            }
    }else{
        $lectureurl1Err = "Lecture URL is required";
    }
    if($lecturenumberErr == '' and $lecturename1Err == '' and $lecturedescript1Err == '' and $lectureurl1Err == ''){
        $insert2 = "INSERT INTO lectures (COURSE_ID,LECTURE_NO,LECTURE_NAME,LECTURE_DESCRIPT,LECTURE_URL) VALUES ('$courseid','$lecturenumber','$lecturename1','$lecturedescript1','$url')";
    $result3 = mysqli_query($conn,$insert2);
    if($result3){
    echo "success"; }else{
        echo "failed to insert";
    }}}
    ?>
<nav class="editnav">
    <a href="editcourse.php?courseid=<?=$courseid?>" class="editnavitem">Edit Course</a>
    <a href="javascript:void(0)" onclick="openlectureform()" class="editnavitem">Add New Lecture</a>
    <a href="delete.php?deletecourse=<?=$courseid?>" onclick="return confirm('Are you sure you want to delete this course?')" class="editnavitem">Delete this course</a>
</nav>
<script>
    function openlectureform(){
        var y = document.getElementById("addlecturebox")
        y.style.display = "block"
    }
    function closelectureform(){
        var y = document.getElementById("addlecturebox")
        y.style.display = "none"
    }
</script>
<div class="addlecturebox" id="addlecturebox" <?php  if(!($lecturename1Err == '' and $lecturedescript1Err == '' and $lectureurl1Err == '')){?> style="display:block"<?php }?> >
    <form method="POST" action="" class="addlectureform">
    <h3 class="subheading">Add New Lecture</h3><a href="javascript:void(0)" onclick="closelectureform()" class="closebtn">X</a>
          <label for="lecturename1">Lecture Name </label><spam class="error"><?= $lecturename1Err?></spam>
          <input type="text" placeholder="Name of Lecture 1" name="lecturename1" class="field" value=<?= $lecturename1?>>
          <label for="lecturenumber">Lecture Number </label><spam class="error"><?= $lecturenumberErr?></spam>
          <select name="lecturenumber" class="field">
             <?php
             $i = 1;
             while($i <= 10){?>
             <option value=<?= $i?> name="lecturenumber"><?= $i?></option>
             <?php 
             $i = $i +1;} ?>
        </select>
          <label for="lecturedescript1">Lecture Description </label><spam class="error"><?= $lecturedescript1Err?></spam><br>
          <textarea maxlength="2000" placeholder="About the lecture" class="formControl lecturedescript" max="" name="lecturedescript1" value=<?= $lecturedescript1?>></textarea><br>
          <label for="lectureurl1">Lecture Video URL </label><spam class="error"><?= $lectureurl1Err?></spam>
          <input type="text" placeholder="Paste Youtube Url Here" name="lectureurl1" class="field"  value=<?= $lectureurl1?>>
          <input type="submit" name="submitform" class="loginbtn">
        </form>
        
             </div>
<?php }
$sql= "SELECT * FROM users WHERE USER_ID = '$_SESSION[ID]'";
$result = mysqli_query($conn,$sql);
$user = mysqli_fetch_assoc($result);
$sql = "SELECT * FROM courses WHERE COURSE_ID = '$courseid'";
$result = mysqli_query($conn,$sql);
$row = mysqli_fetch_assoc($result);
$sql = "SELECT * FROM lectures WHERE COURSE_ID = '$courseid'";
$result = mysqli_query($conn,$sql);
$newhit = intval($row['HIT_NO']) + 1;
$sqlhit = "UPDATE courses SET HIT_NO = '$newhit' WHERE COURSE_ID = '$courseid'";
$resulthit = mysqli_query($conn,$sqlhit);?>
<h1 class="pagehead"><?= $row['COURSE_NAME']?> Course</h1>
    <p class="coursedescript"><?= $row['COURSE_DESCRIPT']?></p>
    <h2 class="subheading">Lectures</h2>
<?php if(mysqli_num_rows($result) > 0){?>

    
    <?php
    $sql2 = "SELECT * from lectures WHERE COURSE_ID = '$courseid' ORDER BY LECTURE_NO ASC";
    $result2 = mysqli_query($conn,$sql2);
    while($row2 = mysqli_fetch_assoc($result2)){?>
    <script>

function myFunction<?=$row2['LECTURE_ID']?>(y) {
 var x = document.getElementById("lecture<?=$row2['LECTURE_ID']?>");
 y.classList.toggle("fa-chevron-right");
 y.classList.toggle("fa-chevron-down");
if(x.style.display == "block"){
 x.style.display = "none";
}else{
 x.style.display = "block";
}
}
</script>
<section class="lecturessect">
    <h3 class="lecturehead">Lecture <?= $row2['LECTURE_NO']?>: <?= $row2['LECTURE_NAME']?>
     <i class="fa fa-chevron-down" aria-hidden="true" onclick="myFunction<?=$row2['LECTURE_ID']?>(this)"></i>
     <?php if($_SESSION['ROLE'] == "Teacher" && ($row['USER_ID'] == $_SESSION['ID'] ||( $user['ROLE'] == "admin" || $user['ROLE'] == "superadmin") )){?>
    <a href="delete.php?deletelecture=<?=$row2['LECTURE_ID']?>" onclick="return confirm('Are you sure you want to delete this lecture?')"><i class="fa fa-trash" aria-hidden="true"></i></a>
   <a href="editcourse.php?lectureid=<?=$row2['LECTURE_ID']?>"><i class="fa fa-pencil" aria-hidden="true"></i></a>
   <?php }?>
</h3>
    <div id="lecture<?=$row2['LECTURE_ID']?>" class="lecturecontext">
    <p class="lecturedescript"> <?= $row2['LECTURE_DESCRIPT']?></p>
    <iframe src="https://www.youtube.com/embed/<?=$row2['LECTURE_URL']?>" class="lecturevid" frameborder="0" allowfullscreen></iframe>
    </div>
    </section>
    <?php } ?>

<?php }else{?>
<spam class="nolectures">No Lectures Available</spam>
<?php }
include 'template/footer.html'; ?> 

   





