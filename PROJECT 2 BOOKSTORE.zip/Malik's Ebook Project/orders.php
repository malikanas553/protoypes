<?php
session_start();
require 'connect.php';
if(!isset($_SESSION['adminemail'])){
    header("Location: adminlogin.php");
    die();
}else{
    $sql = "SELECT ADMIN_NAME FROM admins WHERE ADMIN_EMAIL = '$_SESSION[adminemail]'";
    $result= mysqli_query($conn,$sql);
    $row = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Book</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style4.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<header>
<img src="logo.png" width="70" height="70">
<label id="adminname"><?= $row['ADMIN_NAME']?></label>
<nav>
    <ul>
    <li><a href="users.php">Users</a></li>
    <li><a href="adminpage.php">Books</a></li>
    <li><a href="categories.php">Sub/Categories</a></li>
    <li><a href="orders.php">Orders</a></li>
    <?php if($_SESSION['ADMIN_ID'] == '1'){
        echo "<li><a href='admins.php'>Admins</a></li>";}?>
    <li><a href='logout.php'>Log Out</a></li>
</ul>
</nav>
</header>
</header>
<body>
<h1>Orders<h1>
<?php 
$results2 = mysqli_query($conn,"SHOW TABLES LIKE '"."%_Order%"."'");
if($results2->num_rows == 0){
    echo "No orders are placed at the current time";
}else{
$sql2 = "SELECT Name FROM users";
$result2= mysqli_query($conn,$sql2);
$x = 1;

while($row2 = mysqli_fetch_assoc($result2)){?>
<script>

       function myFunction<?=$x?>(y) {
        var x = document.getElementById("<?=$row2['Name']?>");
        y.classList.toggle("fa-chevron-up");
        y.classList.toggle("fa-chevron-down");
    if(x.style.display == "block"){
        x.style.display = "none";
    }else{
        x.style.display = "block";
    }
}
</script>
<?php

$results = mysqli_query($conn,"SHOW TABLES LIKE '"."$row2[Name]_Order"."'");
    if($results->num_rows == 1) {?>
    <h2><?= ucfirst($row2['Name'])?><i class="fa fa-chevron-down" aria-hidden="true" onclick="myFunction<?=$x?>(this)"></i></h2>
    <?php
        $sql3 = "SELECT BOOK_ID from $row2[Name]_Order";
        $result3 = mysqli_query($conn,$sql3);
        $sql4= "SELECT $row2[Name]_Order.BOOK_ID,books.BOOK_NAME,books.PRICE,authors.FIRST_NAME,authors.LAST_NAME FROM $row2[Name]_Order JOIN books ON $row2[Name]_Order.BOOK_ID = books.BOOK_ID JOIN authors ON books.AUTHOR_ID = authors.AUTHOR_ID";
        $result4 = mysqli_query($conn,$sql4);
        if(mysqli_num_rows($result4) > 0){?>

            <table id="<?=$row2['Name']?>">
                        <tr>
                        <th>Price</th>
                        <th>Book Name</th>
                        <th>Author</th>
                        
                </tr>
             
    
            <?php while($row4 = mysqli_fetch_assoc($result4)){?>
                <tr>
                    <td>$<?= $row4['PRICE']?> </td>
                    <td><?= $row4['BOOK_NAME']?> </td>
                    <td><?= $row4['FIRST_NAME'] ?> <?= $row4['LAST_NAME'] ?> </td>
            </tr>
        

         
  <?php }    
$sql5 = "SELECT SUM(books.PRICE) AS total_price FROM books INNER JOIN $row2[Name]_Order ON books.BOOK_ID = $row2[Name]_Order.BOOK_ID";
      $result5 = mysqli_query($conn,$sql5);
      $row3 = mysqli_fetch_assoc($result5);
      $number = $row3['total_price'];
      $sum = number_format((float)$number, 2, '.', '');?>
      <tr>
    <td>SUM: $<?=$sum?></td>
            </tr>
        <tr>
            <form method="get" action="delete.php">
            <td><a href="delete.php?ORDER=<?=$row2['Name']?>" onclick="return confirm('Are you sure you want to delete this order?')" class="complete">Completed</a>
            </form>
        </table><?php ;}}$x = $x + 1;}}}?>
            </body>
            </html>
 
 