<?php
session_start();
error_reporting(0);
require 'connect.php';
if(!isset($_SESSION['email'])){
    header("Location: login.php");
    die();
}elseif(isset($_GET['BOOK_ID'])){
    $_SESSION['BOOK_ID']=$_GET['BOOK_ID'];

$sql = "SELECT Name FROM users WHERE Email = '$_SESSION[email]'";
$result= mysqli_query($conn,$sql);
$row = mysqli_fetch_assoc($result);
$sql2 = "DELETE FROM $row[Name] WHERE BOOK_ID = '$_SESSION[BOOK_ID]' LIMIT 1";
$result2 = mysqli_query($conn,$sql2);
if($result2){
    header("Location: Payment.php");
}else{
    echo "Failed to delete";
}}elseif($_GET['CANCELORDER']){
    $_SESSION['ORDER'] = $_GET['CANCELORDER'];
    $sql = "DROP TABLE $_SESSION[ORDER]_order";
    $result = mysqli_query($conn,$sql);
    if($result){
        header("Location:index.php?canceled");
    }else{
        echo "failed to cancel order";
    }}