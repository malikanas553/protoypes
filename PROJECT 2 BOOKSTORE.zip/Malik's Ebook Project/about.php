<?php
session_start();
require 'connect.php';
error_reporting(0);
if(!isset($_SESSION['email'])){
    header("Location: login.php");
    die();
}else{
    $sql = "SELECT Name FROM users WHERE Email = '$_SESSION[email]'";
    $result= mysqli_query($conn,$sql);
    $row = mysqli_fetch_assoc($result);

}
?>
<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="style3.css">
</head>
<header id="header">
<a href="about.php"><img src="logo.png" width="70" height="70"></a>
<label id="adminname"><?= ucfirst($row['Name'])?></label>
    <nav>
        <ul>
        <li><a href="about.php">About</a></li>
        <li><a href="index.php">Home</a></li>
        <li><a href="payment.php">Cart</a></li>
        <li><a href='logout.php'>Log Out</a></li>
</ul>
</nav>
</header>
<body>
    <section id="addadminbox">
   <h1> About Us </h1>
   <img src="logo.png" width="120" height="120">
<p class="info">Lorem ipsum dolor sit amet consectetur adipisicing elit. Quisquam illo optio facere, 
    consectetur amet excepturi obcaecati non praesentium porro ab dolorum. 
    At maxime perspiciatis tempora aliquam ratione dolore labore sed?</p>
    <h1>Contact Us:</h1>
    <h2 class="aboutsubh">Admins</h2><br>
    <?php
    $sql1 = "SELECT ADMIN_NAME,ADMIN_EMAIL FROM admins LIMIT 3";
    $result1 = mysqli_query($conn,$sql1);
    $x = 1;
    while($row1 = mysqli_fetch_assoc($result1)){?>
        <p class="info"><?=$x.". ".$row1['ADMIN_NAME'].": ". $row1['ADMIN_EMAIL']?></p><br>
       <?php $x++; ?>
    <?php }?>
    <h2 class="aboutsubh">Social Media</h2><br>
    <nav>
    <a href="https://www.instagram.com/malikanas_4323/"><img src="instagram.png"></a><a href="https://www.instagram.com/malikanas_4323/" class="info">@malikanas_4323</a><br><br><br>
    <a href="https://www.facebook.com/Malik.anas.2002"><img src="facebook.png"></a><a href="https://www.facebook.com/Malik.anas.2002" class="info">Malik Anas</a><br><br><br>
    <a href="https://wa.me/249113420655"><img src="whatsapp.png"></a><a href="https://wa.me/249113420655" class="info">+249113420655</a><br><br><br>
    <a href="https://t.me/Shisui553"><img src="telegram.png" href="https://t.me/Shisui553"></a><a href="https://t.me/Shisui553" class="info">@Shisui553</a><br><br>
    </nav>
    </section>