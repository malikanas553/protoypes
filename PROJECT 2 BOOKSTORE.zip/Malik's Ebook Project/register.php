<?php
session_start();
if(isset($_SESSION['email'])){
    header("Location: index.php");
    die();
}
require 'connect.php';
$x ="SELECT * FROM admins";
$result=mysqli_query($conn,$x);
if (mysqli_num_rows($result) == 0){
$name = $email = $telnumber = $address = $gender = $password = $reppass = '';
$nameErr = $emailErr = $telnumberErr = $addressErr = $genderErr = $passwordErr = $reppassErr = $oathErr = '';
if($_SERVER['REQUEST_METHOD'] == "POST"){
    if(isset($_POST["name"])){
        $name=$_POST["name"];
        if(empty($_POST["name"])){
        $nameErr = "Full Name is required";
        unset($_POST["name"]);
    }elseif(preg_match("/[!@#-$%^'+=~|&?\/_*()1234567890]/",$_POST["name"])){
    $nameErr = "Only letters allowed";
    unset($_POST["name"]);}
}else{ 
$nameErr = "Full Name is required";
}if(!isset($_POST["gender"])){
    $genderErr ="Please choose a gender";

}else{
    $gender= $_POST["gender"];
}if(isset($_POST["email"])){
    $email = $_POST["email"];
    if(empty($_POST["email"])){
        $emailErr = "Email is required";
        unset($_POST["email"]);
    }elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $emailErr = "Invalid email";
        unset($_POST["email"]);
    }else{
        $sql = "SELECT * FROM admins WHERE ADMIN_EMAIL = '$_POST[email]'";
        $result = mysqli_query($conn, $sql);
            if (mysqli_num_rows($result) > 0) {
                $emailErr = 'Email already exists';
    }
}}else{
    $emailErr = "Email is required";
}if(isset($_POST["telnumber"])){
    $telnumber = $_POST['telnumber'];
    if(empty($_POST["telnumber"])){
        $telnumberErr = "Phone Number is required";
        unset($_POST["telnumber"]);
    }elseif(preg_match("/[!@#-$%^'+=~|&?\/_*()qwertyuioplkjhgfdsazxcvbnm\s]/",$_POST["telnumber"])){
        $telnumberErr = "Numbers only";
        unset($_POST["telnumber"]);
    }elseif(strlen($_POST["telnumber"])!=10){
        $telnumberErr = "Invalid Phone Number";
        unset($_POST["telnumber"]);
    }
    }else{
        $telnumberErr = "Phone Number is required";
    }if(isset($_POST['address'])){
    $address = $_POST['address'];
    if(empty($_POST['address'])){
        $addressErr= "Address is Required";
        unset($_POST['address']);
    }
}else{
    $addressErr= "Address is Required";
}if(isset($_POST['password'])){
    $password = $_POST['password'];
    if(empty($_POST['password'])){
        $passwordErr = "Password is Required";
        unset($_POST['password']);
    }elseif(strstr($_POST['password'],"\s")){
        $passwordErr = "Your password should not include whitespace";
        unset($_POST['password']);
    }
    elseif(strlen($_POST['password']) < 8){
        $passwordErr = "Your password should have at least 8 characters";
        unset($_POST['password']);
    }elseif(strlen($_POST['password']) > 16){
        $passwordErr = "Your password should not exceed 16 characters";
        unset($_POST['password']);
    }
}else{
    $passwordErr = "Password is Required";
}if(isset($_POST['reppass'])){
    $reppass = $_POST['reppass'];
    if(empty($_POST['reppass'])){
        $reppassErr = "Repeat your Password";
        unset($_POST['reppass']);
    }elseif($_POST['reppass'] !== $password){
        $reppassErr = "The passwords dont match";
        unset($_POST['reppass']);
    }
}else{
    $reppassErr = "Repeat your Password";
}
if(!isset($_POST["oath"])){
    $oathErr ='Please check this box';
}
if($nameErr == ''  and  $emailErr == '' and  $telnumberErr == '' and $addressErr == '' and $genderErr == '' and $passwordErr == '' and $reppassErr == '' and $oathErr == ''){
    $insert = "INSERT INTO admins (ADMIN_NAME,ADMIN_EMAIL,ADMIN_ADDRESS,ADMIN_PASS) VALUES ('$name','$email','$address','$password')";
    $result1 = mysqli_query($conn, $insert);
    if($result1){header("Location: adminpage.php");
    die(); }else{
        echo "failed to insert";
    }}}?>
<!DOCTYPE html>
<html>
    <head>
        <title>Admin Registration</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="style.css">
</head>
<header>
    <h1>MALIK'S STORE</h1>
</header>
<body>
    <section id="box1">
    <h1>Admin Registration</h1>
    <form method="POST" action="">
    <label for="name">Full Name </label><spam class="error"><?= $nameErr?></spam><br><br>
    <input type="text" name="name" placeholder="Enter your full name" value="<?= $name?>" class="field"><br><br>
    <label>Gender </label><spam class="error"><?php echo $genderErr;?></spam><br><br>
    <input type="radio" id="male" name="gender" value="male" <?php if (isset($gender) && $gender=="male") echo "checked";?>>
    <label for="male">Male </label>
    <input type="radio" id="female" name="gender" value="female" <?php if (isset($gender) && $gender=="female") echo "checked";?>>
    <label for="female">Female </label><br><br>
    <label for="email">Email Address </label><spam class="error"><?= $emailErr?></spam><br><br>
    <input type="email" name="email" placeholder="Enter your email" value="<?= $email?>" class="field"><br><br>
    <label for="telnumber">Mobile Number </label><spam class="error"><?= $telnumberErr?></spam><br><br>
    <input type="text" name="telnumber" placeholder="Enter your mobile number" value="<?= $telnumber?>" class="field"><br><br>
    <label for="address">Home Address </label><spam class="error"><?= $addressErr?></spam><br><br>
    <input type="text" name="address" placeholder="Enter address of current residency" value="<?= $address?>" class="field"><br><br>
    <label for="password">Password </label><spam class="error"><?= $passwordErr?></spam><br><br>
    <input type="password" name="password" placeholder="Enter password of at least 8 characters" value="<?= $password?>" class="field"><br><br>
    <label for="reppass">Confirm Password </label><spam class="error"><?= $reppassErr?></spam><br><br>
    <input type="password" name="reppass" placeholder="Enter your password again" value="<?= $reppass?>" class="field"><br><br>
    <input type="checkbox" id="checkbox" name="oath" <?php if(isset($_POST['oath'])){echo "checked";}?>>
    <label for="checkbox" id="oath">I agree to the terms and conditions</label><br>
    <input type="submit" value="Sign Up" id="signup">
</section>
</body>
</html>


<?php } else { $firstname = $lastname = $useremail = $usertelnumber = $useraddress = $usergender = $userpassword = $userreppass = '';
$firstnameErr = $lastnameErr = $useremailErr = $usertelnumberErr = $useraddressErr = $usergenderErr = $userpasswordErr = $userreppassErr = $oathErr ='';
if($_SERVER['REQUEST_METHOD'] == "POST"){
    if(isset($_POST["firstname"])){
        $firstname=$_POST["firstname"];
        if(empty($_POST["firstname"])){
        $firstnameErr = "First Name is required";
        unset($_POST["firstname"]);
    }elseif(preg_match("/[!@#-$%^'+=~|&?\/_*()1234567890]/",$_POST["firstname"])){
    $firstnameErr = "Only letters allowed";
    unset($_POST["firstname"]);}
}else{ 
$firstnameErr = "First Name is required";
}if(isset($_POST["lastname"])){
    $lastname = $_POST["lastname"];
    if(empty($_POST["lastname"])){
    $lastnameErr = "Last Name is required";
    unset($_POST["lastname"]);
}elseif(preg_match("/[!@#-$%^'+=~|&?\/_*()1234567890]/",$_POST["lastname"])){
$lastnameErr = "Only letters allowed";}
    unset($_POST["lastname"]);
}else{
    $lastnameErr = "Last Name is required";
}if(!isset($_POST["usergender"])){
    $usergenderErr ="Please choose a gender";

}else{
    $usergender= $_POST["usergender"];
}if(isset($_POST["useremail"])){
    $useremail = $_POST["useremail"];
    if(empty($_POST["useremail"])){
        $useremailErr = "Email is required";
        unset($_POST["useremail"]);
    }elseif (!filter_var($useremail, FILTER_VALIDATE_EMAIL)) {
        $useremailErr = "Invalid email";
        unset($_POST["useremail"]);
    }else{
        $sql = "SELECT * FROM users WHERE email = '$_POST[useremail]'";
        $result = mysqli_query($conn, $sql);
            if (mysqli_num_rows($result) > 0) {
                $useremailErr = 'Email already exists';
    }}
}else{
    $useremailErr = "Email is required";
}if(isset($_POST["usertelnumber"])){
    $usertelnumber = $_POST['usertelnumber'];
    if(empty($_POST["usertelnumber"])){
        $usertelnumberErr = "Phone Number is required";
        unset($_POST["usertelnumber"]);
    }elseif(preg_match("/[!@#-$%^'+=~|&?\/_*()qwertyuioplkjhgfdsazxcvbnm\s]/",$_POST["usertelnumber"])){
        $usertelnumberErr = "Numbers only";
        unset($_POST["usertelnumber"]);
    }elseif(strlen($_POST["usertelnumber"])!=10){
        $usertelnumberErr = "Invalid Phone Number";
        unset($_POST["usertelnumber"]);
    }
    }else{
        $usertelnumberErr = "Phone Number is required";
    }if(isset($_POST['useraddress'])){
    $useraddress = $_POST['useraddress'];
    if(empty($_POST['useraddress'])){
        $useraddressErr= "Address is Required";
        unset($_POST['useraddress']);
    }
}else{
    $useraddressErr= "Address is Required";
}if(isset($_POST['userpassword'])){
    $userpassword = $_POST['userpassword'];
    if(empty($_POST['userpassword'])){
        $userpasswordErr = "Password is Required";
        unset($_POST['userpassword']);
    }elseif(strstr($_POST['userpassword'],"\s")){
        $userpasswordErr = "Your password should not include whitespace";
        unset($_POST['userpassword']);
    }
    elseif(strlen($_POST['userpassword']) < 8){
        $userpasswordErr = "Your password should have at least 8 characters";
        unset($_POST['userpassword']);
    }elseif(strlen($_POST['userpassword']) > 16){
        $userpasswordErr = "Your password should not exceed 16 characters";
        unset($_POST['userpassword']);
    }
}else{
    $userpasswordErr = "Password is Required";
}if(isset($_POST['userreppass'])){
    $userreppass = $_POST['userreppass'];
    if(empty($_POST['userreppass'])){
        $userreppassErr = "Repeat your Password";
        unset($_POST['userreppass']);
    }elseif($_POST['userreppass'] !== $userpassword){
        $userreppassErr = "The passwords dont match";
        unset($_POST['userreppass']);
    }
}else{
    $userreppassErr = "Repeat your Password";
}
if(!isset($_POST["oath"])){
    $oathErr ='Please check this box';
}
if($usernameErr == ''  and  $useremailErr == '' and  $usertelnumberErr == '' and $useraddressErr == '' and $usergenderErr == '' and $userpasswordErr == '' and $userreppassErr == '' and $oathErr == ''){
    $insert = "INSERT INTO users (Name,Email,Address,Password) VALUES ('$firstname','$useremail','$useraddress','$userpassword')";
    $result1 = mysqli_query($conn, $insert);
    if($result1){
        header("Location: login.php");
    die(); }else{
        echo "failed to insert";
    }}}?>
<!DOCTYPE html>
<html>
    <head>
        <title>Registration</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="style.css">
</head>
<header>
    <h1>MALIK'S STORE</h1>
</header>
<body>
    
    <section id="box1">
    <h2>Registration</h2>
    <form method="POST" action="">
    <label for="firstname">First Name </label><spam class="error"><?php echo $firstnameErr;?></spam><br><br>
    <input type="text" name="firstname" placeholder="Enter First Name" class="field" value="<?= $firstname?>"><br><br>
    <label for="lastname">Last Name </label><spam class="error"><?php echo $lastnameErr;?></spam><br><br>
    <input type="text" name="lastname" placeholder="Enter Last Name" class="field" value="<?= $lastname ?>"><br><br>
    <label>Gender </label><spam class="error"><?php echo $usergenderErr;?></spam><br><br>
    <input type="radio" id="male" name="usergender" value="male" <?php if (isset($usergender) && $usergender=="male") echo "checked";?>>
    <label for="male">Male </label>
    <input type="radio" id="female" name="usergender" value="female" <?php if (isset($usergender) && $usergender=="female") echo "checked";?>>
    <label for="female">Female </label><br><br>
    <label for="useremail">Email Address </label><spam class="error"><?= $useremailErr?></spam><br><br>
    <input type="email" name="useremail" placeholder="Enter your email" value="<?= $useremail?>" class="field"><br><br>
    <label for="usertelnumber">Mobile Number </label><spam class="error"><?= $usertelnumberErr?></spam><br><br>
    <input type="text" name="usertelnumber" placeholder="Enter your mobile number" value="<?= $usertelnumber?>" class="field"><br><br>
    <label for="useraddress">Home Address </label><spam class="error"><?= $useraddressErr?></spam><br><br>
    <input type="text" name="useraddress" placeholder="Street, City, Country" value="<?= $useraddress?>" class="field"><br><br>
    <label for="userpassword">Password </label><spam class="error"><?= $userpasswordErr?></spam><br><br>
    <input type="password" name="userpassword" placeholder="Enter password of at least 8 characters" value="<?= $userpassword?>" class="field"><br><br>
    <label for="userreppass">Confirm Password </label><spam class="error"><?= $userreppassErr?></spam><br><br>
    <input type="password" name="userreppass" placeholder="Enter your password again" value="<?= $userreppass?>" class="field"><br><br>
    <spam class="error" ><?php echo $oathErr;?></spam><br>
    <input type="checkbox" id="checkbox" name="oath" <?php if(isset($_POST['oath'])){echo "checked";}?>>
    <label for="checkbox" id="oath">I agree to the terms and conditions</label><br>
    <p>Already have an account?</p>
    <a href="login.php">Log In</a>
    <input type="submit" value="Sign Up" id="signup2">
</form>
</section>



</body>
</html>
<?php } ?>