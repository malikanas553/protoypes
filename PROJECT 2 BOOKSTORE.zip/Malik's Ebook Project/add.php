<?php
session_start();
require 'connect.php';
error_reporting(0);
$sql = "SELECT ADMIN_NAME FROM admins WHERE ADMIN_EMAIL = '$_SESSION[adminemail]'";
$result= mysqli_query($conn,$sql);
$row = mysqli_fetch_assoc($result);
if(!isset($_SESSION['adminemail'])){
    header("Location: adminlogin.php");
    die();
}elseif(isset($_GET['newadmin'])){{
    


$x ="SELECT * FROM admins";
$result=mysqli_query($conn,$x);
$name = $email = $telnumber = $address = $gender = $password = $reppass = '';
$nameErr = $emailErr = $telnumberErr = $addressErr = $genderErr = $passwordErr = $reppassErr = '';
if($_SERVER['REQUEST_METHOD'] == "POST"){
    if(isset($_POST["name"])){
        $name=$_POST["name"];
        if(empty($_POST["name"])){
        $nameErr = "Full Name is required";
        unset($_POST["name"]);
    }elseif(preg_match("/[!@#-$%^'+=~|&?\/_*()1234567890]/",$_POST["name"])){
    $nameErr = "Only letters allowed";
    unset($_POST["name"]);}
}else{ 
$nameErr = "Full Name is required";
}if(!isset($_POST["gender"])){
    $genderErr ="Please choose a gender";

}else{
    $gender= $_POST["gender"];
}if(isset($_POST["email"])){
    $email = $_POST["email"];
    if(empty($_POST["email"])){
        $emailErr = "Email is required";
        unset($_POST["email"]);
    }elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $emailErr = "Invalid email";
        unset($_POST["email"]);
    }else{
        $sql = "SELECT * FROM admins WHERE ADMIN_EMAIL = '$_POST[email]'";
        $result = mysqli_query($conn, $sql);
            if (mysqli_num_rows($result) > 0) {
                $emailErr = 'Email already exists';
    }
}}else{
    $emailErr = "Email is required";
}if(isset($_POST["telnumber"])){
    $telnumber = $_POST['telnumber'];
    if(empty($_POST["telnumber"])){
        $telnumberErr = "Phone Number is required";
        unset($_POST["telnumber"]);
    }elseif(preg_match("/[!@#-$%^'+=~|&?\/_*()qwertyuioplkjhgfdsazxcvbnm\s]/",$_POST["telnumber"])){
        $telnumberErr = "Numbers only";
        unset($_POST["telnumber"]);
    }elseif(strlen($_POST["telnumber"])!=10){
        $telnumberErr = "Invalid Phone Number";
        unset($_POST["telnumber"]);
    }
    }else{
        $telnumberErr = "Phone Number is required";
    }if(isset($_POST['address'])){
    $address = $_POST['address'];
    if(empty($_POST['address'])){
        $addressErr= "Address is Required";
        unset($_POST['address']);
    }
}else{
    $addressErr= "Address is Required";
}if(isset($_POST['password'])){
    $password = $_POST['password'];
    if(empty($_POST['password'])){
        $passwordErr = "Password is Required";
        unset($_POST['password']);
    }elseif(strstr($_POST['password'],"\s")){
        $passwordErr = "Your password should not include whitespace";
        unset($_POST['password']);
    }
    elseif(strlen($_POST['password']) < 8){
        $passwordErr = "Your password should have at least 8 characters";
        unset($_POST['password']);
    }elseif(strlen($_POST['password']) > 16){
        $passwordErr = "Your password should not exceed 16 characters";
        unset($_POST['password']);
    }
}else{
    $passwordErr = "Password is Required";
}if(isset($_POST['reppass'])){
    $reppass = $_POST['reppass'];
    if(empty($_POST['reppass'])){
        $reppassErr = "Repeat your Password";
        unset($_POST['reppass']);
    }elseif($_POST['reppass'] !== $password){
        $reppassErr = "The passwords dont match";
        unset($_POST['reppass']);
    }
}else{
    $reppassErr = "Repeat your Password";
}
if($nameErr == ''  and  $emailErr == '' and  $telnumberErr == '' and $addressErr == '' and $genderErr == '' and $passwordErr == '' and $reppassErr == ''){
    $insert = "INSERT INTO admins (ADMIN_NAME,ADMIN_EMAIL,ADMIN_ADDRESS,ADMIN_PASS) VALUES ('$name','$email','$address','$password')";
    $result1 = mysqli_query($conn, $insert);
    header("Location: admins.php");
    die(); }}?>
<!DOCTYPE html>
<html>
    <head>
        <title>Admin Registration</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="style3.css">
</head>
<header>
<img src="logo.png" width="70" height="70">
<label id="adminname"><?= $row['ADMIN_NAME']?></label>
    <nav>
        <ul>
        <li><a href="users.php">Users</a></li>
        <li><a href="adminpage.php">Books</a></li>
        <li><a href="categories.php">Sub/Categories</a></li>
        <li><a href="orders.php">Orders</a></li>
        <?php if($_SESSION['ADMIN_ID'] == '1'){
        echo "<li><a href='admins.php'>Admins</a></li>";}?>
        <li><a href='logout.php'>Log Out</a></li>
</ul>
</nav>
</header>
</header>
<body>
    <section id="addadminbox">
    <h1>Add New Admin</h1>
    <form method="POST" action="">
    <label for="name" class="label">Full Name </label><spam class="error"><?= $nameErr?></spam><br><br>
    <input type="text" name="name" placeholder="Enter your full name" value="<?= $name?>" class="field"><br><br>
    <label class="label">Gender </label><spam class="error"><?php echo $genderErr;?></spam><br><br>
    <input type="radio" id="male" name="gender" value="male" <?php if (isset($gender) && $gender=="male") echo "checked";?>>
    <label for="male" class="label">Male </label>
    <input type="radio" id="female" name="gender" value="female" <?php if (isset($gender) && $gender=="female") echo "checked";?>>
    <label for="female" class="label">Female </label><br><br>
    <label for="email" class="label">Email Address </label><spam class="error"><?= $emailErr?></spam><br><br>
    <input type="email" name="email" placeholder="Enter your email" value="<?= $email?>" class="field"><br><br>
    <label for="telnumber" class="label">Mobile Number </label><spam class="error"><?= $telnumberErr?></spam><br><br>
    <input type="text" name="telnumber" placeholder="Enter your mobile number" value="<?= $telnumber?>" class="field"><br><br>
    <label for="address" class="label">Home Address </label><spam class="error"><?= $addressErr?></spam><br><br>
    <input type="text" name="address" placeholder="Enter address of current residency" value="<?= $address?>" class="field"><br><br>
    <label for="password" class="label">Password </label><spam class="error"><?= $passwordErr?></spam><br><br>
    <input type="password" name="password" placeholder="Enter password of at least 8 characters" value="<?= $password?>" class="field"><br><br>
    <label for="reppass" class="label">Confirm Password </label><spam class="error"><?= $reppassErr?></spam><br><br>
    <input type="password" name="reppass" placeholder="Enter your password again" value="<?= $reppass?>" class="field"><br><br>
    <input type="submit" value="Sign Up" id="signup">
</section>
</body>
</html>
<?php ;}} elseif(isset($_GET['newbook'])){
$sql = "SELECT ADMIN_NAME FROM admins WHERE ADMIN_EMAIL = '$_SESSION[adminemail]'";
$result= mysqli_query($conn,$sql);
$row = mysqli_fetch_assoc($result);
$bookname = $aufirstname = $aulastname = $price = $upload = '';
$booknameErr = $aufirstnameErr = $aulastnameErr = $priceErr = $uploaderr = '';
if($_SERVER['REQUEST_METHOD'] == "POST"){
    if(isset($_POST["bookname"])){
        $bookname=$conn -> real_escape_string($_POST["bookname"]);
        if(empty($_POST["bookname"])){
        $booknameErr = "Book Name is required";
        unset($_POST["bookname"]);
    }
}else{ 
$booknameErr = "Book Name is required";
}  if(isset($_POST["aufirstname"])){
    $aufirstname=$_POST["aufirstname"];
    if(empty($_POST["aufirstname"])){
    $aufirstnameErr = "First Name is required";
    unset($_POST["aufirstname"]);
}elseif(preg_match("/[!@#-$%^'+=~|&?\/_*()1234567890]/",$_POST["aufirstname"])){
$aufirstnameErr = "Only letters allowed";
unset($_POST["aufirstname"]);}
}else{ 
    $aufirstnameErr = "First Name is required";

}if(isset($_POST["aulastname"])){
$aulastname = $_POST["aulastname"];
if(empty($_POST["aulastname"])){
$aulastnameErr = "Last Name is required";
unset($_POST["aulastname"]);
}elseif(preg_match("/[!@#-$%^'+=~|&?\/_*()1234567890]/",$_POST["aulastname"])){
$aulastnameErr = "Only letters allowed";}
unset($_POST["aulastname"]);
}else{
    $aulastnameErr = "Last Name is required";
}
if(isset($_POST["price"])){
    $price = $_POST['price'];
    if(empty($_POST["price"])){
        $priceErr = "Price is required";
        unset($_POST["price"]);
    }elseif(preg_match("/[!@#-$%^'+=~|&?\/_*()qwertyuioplkjhgfdsazxcvbnm\s]/",$_POST["price"])){
        $priceErr = "Numbers only";
        unset($_POST["price"]);
    }
    }else{
        $priceErr = "Price is required";
    }
    if(!isset($_FILES["uploadfile"]) || empty($_FILES["uploadfile"]["name"])){
        $upload = $_FILES["uploadfile"]["name"];
        $uploaderr = "Book cover is required";}
if($booknameErr == ''  and  $aufirstnameErr == '' and  $priceErr == '' and $aulastnameErr == '' and $uploaderr == '' ){



$sql4 = "SELECT AUTHOR_ID FROM authors WHERE FIRST_NAME = '$_POST[aufirstname]' and LAST_NAME = '$aulastname'";
$result4 = mysqli_query($conn,$sql4);
$row = mysqli_fetch_assoc($result4);
if($result4){
    $sql5 = "SELECT CATEGORY_ID FROM categories WHERE Category = '$_POST[category]'";
    $result5 = mysqli_query($conn,$sql5);
    $row2 = mysqli_fetch_assoc($result5);
    if($result5){
    $sql6 = "SELECT SUBCATEGORY_ID FROM subcategories WHERE Subcategory = '$_POST[subcategory]'";
    $result6 = mysqli_query($conn,$sql6);
    $row6 = mysqli_fetch_assoc($result6);
    if($result6){
        if(isset($_FILES["uploadfile"]) && !empty($_FILES["uploadfile"]["name"])){
            $filename = $_FILES["uploadfile"]["name"];
           $tempname = $_FILES["uploadfile"]["tmp_name"];    
            $folder = $filename;
            $sql12 = "SELECT IMAGE_ID FROM images WHERE IMAGE = '$filename'";
            $result12 = mysqli_query($conn,$sql12);
            if(mysqli_num_rows($result12) == 0){
           $sql8 = "INSERT INTO images (IMAGE) VALUES ('$filename')";
           mysqli_query($conn, $sql8);
          move_uploaded_file($tempname, $folder);}
          $sql9 = "SELECT IMAGE_ID FROM images WHERE IMAGE = '$filename'"; 
          $result9 = mysqli_query($conn,$sql9);
          $row9 = mysqli_fetch_assoc($result9);
           $sql7 = "INSERT INTO books (IMAGE_ID,BOOK_NAME,PRICE,AUTHOR_ID,CATEGORY_ID,SUBCATEGORY_ID) VALUES('$row9[IMAGE_ID]','$bookname','$_POST[price]','$row[AUTHOR_ID]','$row2[CATEGORY_ID]','$row6[SUBCATEGORY_ID]')";
           $result7 = mysqli_query($conn,$sql7);
           if($result7){
               header("Location: adminpage.php");
           }else{
               echo "failed to edit";
           }
       
       }else{
        $insert = "INSERT INTO authors (FIRST_NAME,LAST_NAME) VALUES('$_POST[aufirstname]','$aulastname')";
        mysqli_query($conn,$insert);
        $sql5 = "SELECT CATEGORY_ID FROM categories WHERE Category = '$_POST[category]'";
        $result5 = mysqli_query($conn,$sql5);
        $row2 = mysqli_fetch_assoc($result5);
        if($result5){
        $sql6 = "SELECT SUBCATEGORY_ID FROM subcategories WHERE Subcategory = '$_POST[subcategory]'";
        $result6 = mysqli_query($conn,$sql6);
        $row6 = mysqli_fetch_assoc($result6);
        if($result6){
            if(isset($_FILES["uploadfile"]) && !empty($_FILES["uploadfile"]["name"])){
                $filename = $_FILES["uploadfile"]["name"];
               $tempname = $_FILES["uploadfile"]["tmp_name"];    
                $folder = $filename;
                $sql12 = "SELECT IMAGE_ID FROM images WHERE IMAGE = '$filename'";
                $result12 = mysqli_query($conn,$sql12);
                if(mysqli_num_rows($result12) == 0){
               $sql8 = "INSERT INTO images (IMAGE) VALUES ('$filename')";
               mysqli_query($conn, $sql8);
              move_uploaded_file($tempname, $folder);}
              $sql9 = "SELECT IMAGE_ID FROM images WHERE IMAGE = '$filename'"; 
              $result9 = mysqli_query($conn,$sql9);
              $row9 = mysqli_fetch_assoc($result9);
               $sql7 = "INSERT INTO books (IMAGE_ID,BOOK_NAME,PRICE,AUTHOR_ID,CATEGORY_ID,SUBCATEGORY_ID) VALUES('$row9[IMAGE_ID]','$bookname','$_POST[price]','$row[AUTHOR_ID]','$row2[CATEGORY_ID]','$row6[SUBCATEGORY_ID]')";
               $result7 = mysqli_query($conn,$sql7);
               if($result7){
                   header("Location: adminpage.php");
               }else{
                   echo "failed to edit";
               }
     }}}}}}}}}?>
    <!DOCTYPE html>
    <html>
    <head>
        <title>Admin Registration</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="style3.css">
</head>
<header>
<img src="logo.png" width="70" height="70">
<label id="adminname"><?= $row['ADMIN_NAME']?></label>
    <nav>
        <ul>
        <li><a href="users.php">Users</a></li>
        <li><a href="adminpage.php">Books</a></li>
        <li><a href="categories.php">Sub/Categories</a></li>
        <li><a href="orders.php">Orders</a></li>
        <?php if($_SESSION['ADMIN_ID'] == '1'){
        echo "<li><a href='admins.php'>Admins</a></li>";}?>
        <li><a href='logout.php'>Log Out</a></li>
</ul>
</nav>
</header>
</header>
<body>
    <section id="addadminbox">
    <h1>Add New Book</h1>
    <form method="POST" 
              action="" 
              enctype="multipart/form-data">
              <label for="bookname" class="label">Book Image</label><spam class="error"><?= $uploaderr?></spam><br><br><br><br>

            <input type="file" 
                   name="uploadfile" 
                   value="$upload" /><br><br>
    <label for="bookname" class="label">Book Name </label><spam class="error"><?= $booknameErr?></spam><br><br>
    <input type="text" name="bookname" placeholder="Enter your book name" value="<?= $bookname?>" class="field"><br><br>
    <label for="aufirstname" class="label">Author's First Name </label><spam class="error"><?= $aufirstnameErr?></spam><br><br>
    <input type="text" name="aufirstname" placeholder="Enter author's first name" value="<?= $aufirstname?>" class="field"><br><br>
    <label for="aulastname" class="label">Author's Last Name </label><spam class="error"><?= $aulastnameErr?></spam><br><br>
    <input type="text" name="aulastname" placeholder="Enter author's last name" value="<?= $aulastname?>" class="field"><br><br>
    <label for="price" class="label">Price </label><spam class="error"><?= $priceErr?></spam><br><br>
    <input type="number" step="0.01" name="price" placeholder="Enter your book's price" value="<?= $price?>" class="field"><br><br>
    <label for='category' class="label">Category:</label>
<select name="category" class="field">
<option value=""></option>
<?php 
$cata= "SELECT CATEGORY FROM categories";
$resultcata = mysqli_query($conn,$cata);
while($catarow = mysqli_fetch_assoc($resultcata)){?>
<option <?php if(isset($_POST['category']) && $_POST['category'] == $catarow['CATEGORY']){echo "selected";}?>><?= $catarow['CATEGORY']?></option>
<?php } ?>
</select><br><br>
<label for='subcategory' class="label">SubCategory:</label>
<select name="subcategory" class="field">
<option value=""></option>
<?php 
$subcata= "SELECT SUBCATEGORY FROM subcategories";
$resultsubcata = mysqli_query($conn,$subcata);
while($subcatarow = mysqli_fetch_assoc($resultsubcata)){?>
<option <?php if(isset($_POST['subcategory']) && $_POST['subcategory'] == $subcatarow['SUBCATEGORY']){echo "selected";}?>><?= $subcatarow['SUBCATEGORY']?></option>
<?php } ?>
</select>
<input type="submit" value="ADD BOOK" id="signup">
</form>
</section>
</body>
</html>


  <?php  }elseif(isset($_POST['newcategory'])){
      $sql="INSERT INTO categories (CATEGORY) VALUES ('$_POST[newcategory]')";
      $result = mysqli_query($conn,$sql);
      if($result){
          header("Location: Categories.php");
          die();
      }else{
          echo "failed to add";
      }}elseif(isset($_POST['newsubcategory'])){
        $sql="INSERT INTO subcategories (SUBCATEGORY) VALUES ('$_POST[newsubcategory]')";
        $result = mysqli_query($conn,$sql);
        if($result){
            header("Location: Categories.php");
            die();
        }else{
            echo "failed to add";
        }}