<?php
session_start();
require 'connect.php';
error_reporting(0);
$sql = "SELECT ADMIN_NAME FROM admins WHERE ADMIN_EMAIL = '$_SESSION[adminemail]'";
$result= mysqli_query($conn,$sql);
$row = mysqli_fetch_assoc($result);
if(!isset($_SESSION['adminemail'])){
    header("Location: adminlogin.php");
    die();
}elseif(isset($_GET['BOOK_ID'])){
    $_SESSION['BOOK_ID']=$_GET['BOOK_ID'];
$sql2 = "SELECT images.IMAGE,books.BOOK_NAME,authors.FIRST_NAME,authors.LAST_NAME,books.PRICE,categories.CATEGORY,subcategories.SUBCATEGORY FROM books JOIN images on books.IMAGE_ID = images.IMAGE_ID JOIN authors ON books.AUTHOR_ID = authors.AUTHOR_ID  JOIN categories ON books.CATEGORY_ID = categories.CATEGORY_ID  JOIN subcategories on books.SUBCATEGORY_ID = subcategories.SUBCATEGORY_ID WHERE books.BOOK_ID= '$_SESSION[BOOK_ID]'";
$result2 = mysqli_query($conn,$sql2);
$bookname = $aufirstname = $aulastname = $price = '';
$booknameErr = $aufirstnameErr = $aulastnameErr = $priceErr = '';
if($_SERVER['REQUEST_METHOD'] == "POST"){
$esc =$conn -> real_escape_string($_POST['bookname']);
$sql10 ="SELECT IMAGE_ID FROM books WHERE BOOK_NAME = '$esc'";
$result10 = mysqli_query($conn,$sql10);
$row10 =mysqli_fetch_assoc($result10);
    if(isset($_POST["bookname"])){
        $bookname=$esc;
        if(empty($_POST["bookname"])){
        $booknameErr = "Book Name is required";
        unset($_POST["bookname"]);
    }
}else{ 
$booknameErr = "Book Name is required";
}  if(isset($_POST["aufirstname"])){
    $aufirstname=$_POST["aufirstname"];
    if(empty($_POST["aufirstname"])){
    $aufirstnameErr = "First Name is required";
    unset($_POST["aufirstname"]);
}elseif(preg_match("/[!@#-$%^'+=~|&?\/_*()1234567890]/",$_POST["aufirstname"])){
$aufirstnameErr = "Only letters allowed";
unset($_POST["aufirstname"]);}
}else{ 
    $aufirstnameErr = "First Name is required";

}if(isset($_POST["aulastname"])){
$aulastname = $_POST["aulastname"];
if(empty($_POST["aulastname"])){
$aulastnameErr = "Last Name is required";
unset($_POST["aulastname"]);
}elseif(preg_match("/[!@#-$%^'+=~|&?\/_*()1234567890]/",$_POST["aulastname"])){
$aulastnameErr = "Only letters allowed";}
unset($_POST["aulastname"]);
}else{
    $aulastnameErr = "Last Name is required";
}
if(isset($_POST["price"])){
    $price = $_POST['price'];
    if(empty($_POST["price"])){
        $priceErr = "Price is required";
        unset($_POST["price"]);
    }elseif(preg_match("/[!@#-$%^'+=~|&?\/_*()qwertyuioplkjhgfdsazxcvbnm\s]/",$_POST["price"])){
        $priceErr = "Numbers only";
        unset($_POST["price"]);
    }
    }else{
        $priceErr = "Price is required";
    }
if($booknameErr == ''  and  $aufirstnameErr == '' and  $priceErr == '' and $aulastnameErr == '' ){
   $sql9 = "SELECT BOOK_NAME FROM books WHERE BOOK_ID = '$_SESSION[BOOK_ID]'";
   $result9 = mysqli_query($conn,$sql9);
    if($result9){

   $sql5 = "SELECT CATEGORY_ID FROM categories WHERE CATEGORY = '$_POST[category]'";
   $result5 = mysqli_query($conn,$sql5);
   $row4 = mysqli_fetch_assoc($result5);
   if($result5){
   $sql6 = "SELECT SUBCATEGORY_ID FROM subcategories WHERE SUBCATEGORY = '$_POST[subcategory]'";
   $result6 = mysqli_query($conn,$sql6);
   $row5 = mysqli_fetch_assoc($result6);
   if($result6){
   $sql3 = "SELECT AUTHOR_ID FROM authors WHERE FIRST_NAME = '$_POST[aufirstname]' and LAST_NAME = '$aulastname'";
   $result3 = mysqli_query($conn,$sql3);
   if ($result3) {
    if (mysqli_num_rows($result3) == 0) {
        $sql4 = "INSERT INTO authors (FIRST_NAME,LAST_NAME) VALUES ('$_POST[aufirstname]','$aulastname')";
    $result4= mysqli_query($conn,$sql4);
    }
    if(isset($_FILES["uploadfile"]) && !empty($_FILES["uploadfile"]["name"])){
     $filename = $_FILES["uploadfile"]["name"];
    $tempname = $_FILES["uploadfile"]["tmp_name"];    
     $folder = $filename;
     $sql12 = "SELECT IMAGE_ID FROM images WHERE IMAGE = '$filename'";
     $result12 = mysqli_query($conn,$sql12);
     if(mysqli_num_rows($result12) == 0){
    $sql8 = "INSERT INTO images (IMAGE) VALUES ('$filename')";
    mysqli_query($conn, $sql8);}
   move_uploaded_file($tempname, $folder);
   $sql9 = "SELECT IMAGE_ID FROM images WHERE IMAGE = '$filename'"; 
   $result9 = mysqli_query($conn,$sql9);
   $row9 = mysqli_fetch_assoc($result9);
    $sql3 = "SELECT AUTHOR_ID FROM authors WHERE FIRST_NAME = '$_POST[aufirstname]' and LAST_NAME = '$aulastname'";
   $result3 = mysqli_query($conn,$sql3);
    $row3 = mysqli_fetch_assoc($result3);
    $sql7 = "UPDATE books SET IMAGE_ID = '$row9[IMAGE_ID]', BOOK_NAME= '$bookname',PRICE = '$_POST[price]', AUTHOR_ID= '$row3[AUTHOR_ID]', CATEGORY_ID = '$row4[CATEGORY_ID]', SUBCATEGORY_ID = '$row5[SUBCATEGORY_ID]' WHERE BOOK_ID= '$_SESSION[BOOK_ID]' LIMIT 1";
    $result7 = mysqli_query($conn,$sql7);
    if($result7){
        header("Location: adminpage.php");
    }else{
        echo "failed to edit";
    }

}elseif($row10['IMAGE_ID'] == 0){
$sql3 = "SELECT AUTHOR_ID FROM authors WHERE FIRST_NAME = '$_POST[aufirstname]' and LAST_NAME = '$aulastname'";
$result3 = mysqli_query($conn,$sql3);
 $row3 = mysqli_fetch_assoc($result3);
 $sql7 = "UPDATE books SET IMAGE_ID = '7', BOOK_NAME= '$bookname',PRICE = '$_POST[price]', AUTHOR_ID= '$row3[AUTHOR_ID]', CATEGORY_ID = '$row4[CATEGORY_ID]', SUBCATEGORY_ID = '$row5[SUBCATEGORY_ID]' WHERE BOOK_ID= '$_SESSION[BOOK_ID]' LIMIT 1";
 $result7 = mysqli_query($conn,$sql7);
 if($result7){
     header("Location: adminpage.php");
 }else{
     echo "failed to edit";
 }
}else{
    $sql3 = "SELECT AUTHOR_ID FROM authors WHERE FIRST_NAME = '$_POST[aufirstname]' and LAST_NAME = '$aulastname'";
$result3 = mysqli_query($conn,$sql3);
 $row3 = mysqli_fetch_assoc($result3);
 $sql7 = "UPDATE books SET BOOK_NAME= '$bookname',PRICE = '$_POST[price]', AUTHOR_ID= '$row3[AUTHOR_ID]', CATEGORY_ID = '$row4[CATEGORY_ID]', SUBCATEGORY_ID = '$row5[SUBCATEGORY_ID]' WHERE BOOK_ID= '$_SESSION[BOOK_ID]' LIMIT 1";
 $result7 = mysqli_query($conn,$sql7);
 if($result7){
     header("Location: adminpage.php");
 }else{
     echo "failed to edit";
 }


}}}}}}}?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Book</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style3.css">
</head>
<header>
<img src="logo.png" width="70" height="70">
<label id="adminname"><?= $row['ADMIN_NAME']?></label>
<nav>
    <ul>
    <li><a href="users.php">Users</a></li>
    <li><a href="adminpage.php">Books</a></li>
    <li><a href="categories.php">Sub/Categories</a></li>
    <li><a href="orders.php">Orders</a></li>
    <?php if($_SESSION['ADMIN_ID'] == '1'){
        echo "<li><a href='admins.php'>Admins</a></li>";}?>
    <li><a href='logout.php'>Log Out</a></li>
</ul>
</nav>
</header>
</header>
<body>
<section id="addadminbox">
<h1>Edit Book</h1>
 <?php while($row2 = mysqli_fetch_assoc($result2)){?>
<section id="bookimage">
<?php echo "<img src=$row2[IMAGE] width = '181' height = '271' alt='no cover'><br>";?>
<form method="POST" 
              action="" 
              enctype="multipart/form-data">
              <label for="bookname" class="label">Book Image</label><spam class="error"><?= $booknameErr?></spam><br><br>

            <input type="file" 
                   name="uploadfile" 
                   value="<?= $row2['IMAGE']?> " />
 </section><br><br><br><br>
<label for="bookname" class="label">Book Name </label><spam class="error"><?= $booknameErr?></spam><br><br>
<input type="text" name="bookname" placeholder="Enter your book name" value="<?= $row2['BOOK_NAME']?>" class="field"><br><br>
<label for="aufirstname" class="label">Author's First Name </label><spam class="error"><?= $aufirstnameErr?></spam><br><br>
<input type="text" name="aufirstname" placeholder="Enter author's first name" value="<?= $row2['FIRST_NAME']?>" class="field"><br><br>
<label for="aulastname" class="label">Author's Last Name </label><spam class="error"><?= $aulastnameErr?></spam><br><br>
<input type="text" name="aulastname" placeholder="Enter author's last name" value="<?= $row2['LAST_NAME']?>" class="field"><br><br>
<label for="price" class="label">Price </label><spam class="error"><?= $priceErr?></spam><br><br>
<input type="number" step="0.01" name="price" placeholder="Enter your book's price" value="<?= $row2['PRICE']?>" class="field"><br><br>
<label for='category' class="label">Category:</label><br><br>
<select name="category" class="field">
<option value=""> </option>
<?php 
$cata= "SELECT CATEGORY FROM categories";
$resultcata = mysqli_query($conn,$cata);
while($catarow = mysqli_fetch_assoc($resultcata)){?>
<option <?php if($row2['CATEGORY'] == $catarow['CATEGORY']){echo "selected";}?>><?= $catarow['CATEGORY']?></option>
<?php } ?>
</select><br><br>
<label for='subcategory' class="label">SubCategory:</label><br><br>
<select name="subcategory" class="field">
<option value=""> </option>
<?php 
$subcata= "SELECT SUBCATEGORY FROM subcategories";
$resultsubcata = mysqli_query($conn,$subcata);
while($subcatarow = mysqli_fetch_assoc($resultsubcata)){?>
<option <?php if($subcatarow['SUBCATEGORY'] == $row2['SUBCATEGORY']){echo "selected";}?>><?= $subcatarow['SUBCATEGORY']?></option>
<?php } ?>
</select>
<?php } ?>
<input type="submit" value="EDIT BOOK" id="signup">
</form>
</section>
</body>
</html>
<?php }elseif(isset($_GET['CATEGORY_ID'])){
    $_SESSION['CATEGORY_ID'] = $_GET['CATEGORY_ID'];?>
    <!DOCTYPE html>
<html>
<head>
    <title>Edit Categories</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style3.css">
</head>
<header>
<img src="logo.png" width="70" height="70">
<label id="adminname"><?= $row['ADMIN_NAME']?></label>
<nav>
    <ul>
    <li><a href="users.php">Users</a></li>
    <li><a href="adminpage.php">Books</a></li>
    <li><a href="categories.php">Sub/Categories</a></li>
    <li><a href="orders.php">Orders</a></li>
    <?php if($_SESSION['ADMIN_ID'] == '1'){
        echo "<li><a href='admins.php'>Admins</a></li>";}?>
    <li><a href='logout.php'>Log Out</a></li>
</ul>
</nav>
</header>
</header>
<body>
    <?php $sql1 = "SELECT CATEGORY FROM categories WHERE CATEGORY_ID = '$_SESSION[CATEGORY_ID]'";
    $result1 = mysqli_query($conn,$sql1);
    $row1 = mysqli_fetch_assoc($result1);
    ?>
<section id="addadminbox">
<h1><?= $row1['CATEGORY']?></h1>
    <table>
<tr>
<th>Book Name</th>
<th>Author</th>
<th>Remove</th>
</tr>
<?php 
$sql3 = "SELECT books.BOOK_ID,books.BOOK_NAME,authors.FIRST_NAME,authors.LAST_NAME,books.PRICE FROM books JOIN authors ON books.AUTHOR_ID =authors.AUTHOR_ID JOIN categories ON books.CATEGORY_ID = categories.CATEGORY_ID WHERE categories.CATEGORY = '$row1[CATEGORY]'";;
$result3 = mysqli_query($conn,$sql3);
while($row3 = mysqli_fetch_assoc($result3)){?>
<tr>
<td><?= $row3['BOOK_NAME']?> </td> 
<td><?= $row3['FIRST_NAME'] ?> <?= $row3['LAST_NAME'] ?> </td>
<form method="get" action="edit.php">
<td><a href="edit.php?BOOK_ID=<?=$row3['BOOK_ID']?>">Edit</a></td>
<?php } ?>
</table>

<?php }elseif(isset($_GET['SUBCATEGORY_ID'])){
    $_SESSION['SUBCATEGORY_ID'] = $_GET['SUBCATEGORY_ID'];?>
    <!DOCTYPE html>
<html>
<head>
    <title>Edit Subcategories</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style3.css">
</head>
<header>
<img src="logo.png" width="70" height="70">
<label id="adminname"><?= $row['ADMIN_NAME']?></label>
<nav>
    <ul>
    <li><a href="users.php">Users</a></li>
    <li><a href="adminpage.php">Books</a></li>
    <li><a href="categories.php">Sub/Categories</a></li>
    <li><a href="orders.php">Orders</a></li>
    <li><a href="admins.php">Admins</a></li>
    <li><a href='logout.php'>Log Out</a></li>
</ul>
</nav>
</header>
</header>
<body>
    <?php $sql1 = "SELECT SUBCATEGORY FROM subcategories WHERE SUBCATEGORY_ID = '$_SESSION[SUBCATEGORY_ID]'";
    $result1 = mysqli_query($conn,$sql1);
    $row1 = mysqli_fetch_assoc($result1);
    ?>
<section id="addadminbox">
<h1><?= $row1['SUBCATEGORY']?></h1>
    <table>
<tr>
<th>Book Name</th>
<th>Author</th>
<th>Remove</th>
</tr>
<?php 
$sql3 = "SELECT books.BOOK_ID,books.BOOK_NAME,authors.FIRST_NAME,authors.LAST_NAME,books.PRICE FROM books JOIN authors ON books.AUTHOR_ID =authors.AUTHOR_ID JOIN subcategories ON books.SUBCATEGORY_ID = subcategories.SUBCATEGORY_ID WHERE subcategories.SUBCATEGORY = '$row1[SUBCATEGORY]'";;
$result3 = mysqli_query($conn,$sql3);
while($row3 = mysqli_fetch_assoc($result3)){?>
<tr>
<td><?= $row3['BOOK_NAME']?> </td> 
<td><?= $row3['FIRST_NAME'] ?> <?= $row3['LAST_NAME'] ?> </td>
<form method="get" action="edit.php">
<td><a href="edit.php?BOOK_ID=<?=$row3['BOOK_ID']?>">Edit</a></td>
<?php } ?>
</table>

<?php } ?> 