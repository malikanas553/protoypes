<?php
session_start();
require 'connect.php';
error_reporting(0);
$x ="SELECT * FROM admins";
$result=mysqli_query($conn,$x);
if (mysqli_num_rows($result) == 0){
    header("Location:register.php");
    die();}
elseif(!isset($_SESSION['email'])){
    header("Location: login.php");
    die();
}else{
    $sql = "SELECT Name FROM users WHERE Email = '$_SESSION[email]'";
    $result= mysqli_query($conn,$sql);
    $row = mysqli_fetch_assoc($result);

}
?>
<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="style3.css">
</head>
<header id="header">
<a href="about.php"><img src="logo.png" width="70" height="70"></a>
<label id="adminname"><?= ucfirst($row['Name'])?></label>
    <nav>
        <ul>
        <li><a href="about.php">About</a></li>
        <li><a href="index.php">Home</a></li>
        <li><a href="payment.php">Cart</a></li>
        <li><a href='logout.php'>Log Out</a></li>
</ul>
</nav>
</header>
<body>
<script>
    history.pushState(null, "", location.href.split("?")[0]);
 
</script>
<?php if(isset($_GET['done'])){
     echo '
     <script type="text/javascript">
 
     alert("Order placed successfully");
 
     </script>';}?>
     <?php if(isset($_GET['canceled'])){
        echo '
        <script type="text/javascript">
    
        alert("Order canceled successfully");
    
        </script>';}?>
<?php if($_SERVER['REQUEST_METHOD'] !== "POST"){?>
<div class="slideshow">
<div class="slide">
  <img src="bookbg.jpg" style="width:100%">
  <div class="text">Welcome to the world's leading<br> Ebook store</div>
</div>

<div class="slide">
  <img src="slideimg2.jpg" style="width:100%">
  <div class="text">Millions and Millions of books<br> to explore</div>
</div>

<div class="slide">
  <img src="slideimg3.jpg" style="width:100%">
  <div class="text">What are you waiting for?<br> Start browsing</div>
</div>
</div>

<script>
    let slideIndex = 0;
showSlides();

function showSlides() {
  let i;
  let slides = document.getElementsByClassName("slide");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}
  slides[slideIndex-1].style.display = "block";
  setTimeout(showSlides, 2000);
}
</script>

<section id="box1">
<form method="post" action="" id="form1">
<select name="filter" id="filter">
<option value="Book" <?php if(isset($_POST['filter']) && $_POST['filter'] == "Book"){ echo "selected";}?>>Book</option>
<option value="Author" <?php if(isset($_POST['filter']) && $_POST['filter'] == "Author"){ echo "selected";}?>>Author</option>
</select>
<input type="text" name="searchbar" value="<?php if(isset($_POST['searchbar'])){ echo $_POST['searchbar'];}?>" id="searchbar">
<button onclick= "myFunction()" id="filtbut" inline ="true" type="button"></button>
<script>
       function myFunction() {
        var x = document.getElementById("box2");
    if(x.style.display == "block"){
        x.style.display = "none";
    }else{
        x.style.display = "block";
    }
}
</script>
<button type="submit" id="submit" inline="true"></button><br>
<section id="box2">
<label for='category'>Category:</label><br>
<select name="category" class="filter">
<option value=""></option>
<?php 
$cata= "SELECT CATEGORY FROM categories";
$resultcata = mysqli_query($conn,$cata);
while($catarow = mysqli_fetch_assoc($resultcata)){?>
<option <?php if(isset($_POST['category']) && $_POST['category'] == $catarow['CATEGORY']){echo "selected";}?>><?= $catarow['CATEGORY']?></option>
<?php } ?>
</select><br><br>
<label for='subcategory'>SubCategory:</label><br>
<select name="subcategory" class="filter">
<option value=""></option>
<?php 
$subcata= "SELECT SUBCATEGORY FROM subcategories";
$resultsubcata = mysqli_query($conn,$subcata);
while($subcatarow = mysqli_fetch_assoc($resultsubcata)){?>
<option <?php if(isset($_POST['subcategory']) && $_POST['subcategory'] == $subcatarow['SUBCATEGORY']){echo "selected";}?>><?= $subcatarow['SUBCATEGORY']?></option>
<?php } ?>
</select>
</section>
</form>
</section>
<?php if(isset($_GET['msg'])){
            echo '
            <script type="text/javascript">
        
            alert("Book added to cart");
        
            </script>';}?>
            <?php if(isset($_GET['alert'])){
            
            echo '
            <script type="text/javascript">
        
            alert("You havent added any books to your cart");
        
            </script>';}?>
            <?php }else{?>
<section id="box3">
<form method="post" action="" id="form1">
<select name="filter" id="filter">
<option value="Book" <?php if(isset($_POST['filter']) && $_POST['filter'] == "Book"){ echo "selected";}?>>Book</option>
<option value="Author" <?php if(isset($_POST['filter']) && $_POST['filter'] == "Author"){ echo "selected";}?>>Author</option>
</select>
<input type="text" name="searchbar" value="<?php if(isset($_POST['searchbar'])){ echo $_POST['searchbar'];}?>" id="searchbar">
<button onclick= "myFunction()" id="filtbut" inline ="true" type="button"></button>
<script>
      function myFunction() {
        var x = document.getElementById("box2");
    if(x.style.display == "block"){
        x.style.display = "none";
    }else{
        x.style.display = "block";
    }
}
</script>
<button type="submit" id="submit" inline="true"></button><br>
<section id="box2">
<label for='category'>Category:</label><br>
<select name="category" class="filter">
<option value=""></option>
<?php 
$cata= "SELECT CATEGORY FROM categories";
$resultcata = mysqli_query($conn,$cata);
while($catarow = mysqli_fetch_assoc($resultcata)){?>
<option <?php if(isset($_POST['category']) && $_POST['category'] == $catarow['CATEGORY']){echo "selected";}?>><?= $catarow['CATEGORY']?></option>
<?php } ?>
</select><br><br>
<label for='subcategory'>SubCategory:</label><br>
<select name="subcategory" class="filter">
<option value=""></option>
<?php 
$subcata= "SELECT SUBCATEGORY FROM subcategories";
$resultsubcata = mysqli_query($conn,$subcata);
while($subcatarow = mysqli_fetch_assoc($resultsubcata)){?>
<option <?php if(isset($_POST['subcategory']) && $_POST['subcategory'] == $subcatarow['SUBCATEGORY']){echo "selected";}?>><?= $subcatarow['SUBCATEGORY']?></option>
<?php } ?>
</select>
</section>
</form>
</section>
    <?php
    if(empty($_POST['category']) && empty($_POST['subcategory'])){
    if($_POST['filter'] == "Book"){
    $search=$_POST['searchbar'];
    $sql = "SELECT books.IMAGE_ID,books.BOOK_ID,images.IMAGE,books.BOOK_NAME,authors.FIRST_NAME,authors.LAST_NAME,books.PRICE FROM books JOIN images ON books.IMAGE_ID=images.IMAGE_ID INNER JOIN authors ON books.AUTHOR_ID =authors.AUTHOR_ID WHERE BOOK_NAME LIKE '%$search%'";
        $result = mysqli_query($conn,$sql);
        if(mysqli_num_rows($result) > 0){?>
    <table>
                <tr>
                <th>Book Name</th>
                <th>Author</th>
                <th>Price</th>
                <th>BUY</th>
        </tr>
        <?php while($row = mysqli_fetch_assoc($result)){?>
                <tr>
                    <td><img src=<?= $row['IMAGE']?> width="181" height="271"class="image" alt="no cover available"><spam class="bookname"><?= $row['BOOK_NAME']?></spam></td>
                    <td><?= $row['FIRST_NAME'] ?> <?= $row['LAST_NAME'] ?> </td>
                    <td>$<?= $row['PRICE']?> </td>
                    <form action="cart.php" method="GET">
                    <td><a href="cart.php?BOOK_ID=<?= $row['BOOK_ID']?>">ADD TO CART</a></td>
            </form>
            </tr>
         

    <?php }}else{
        echo "<p class='genre'>No results found</p>";
    }}else{ 
    $search=$_POST['searchbar'];
    $sql = "SELECT books.BOOK_ID,images.IMAGE,books.BOOK_NAME,authors.FIRST_NAME,authors.LAST_NAME,books.PRICE FROM books JOIN images ON books.IMAGE_ID=images.IMAGE_ID INNER JOIN authors ON books.AUTHOR_ID =authors.AUTHOR_ID WHERE authors.FIRST_NAME LIKE '%$search%' OR authors.LAST_NAME LIKE '%$search%'";
        $result = mysqli_query($conn,$sql);
        if(mysqli_num_rows($result) > 0){?>
    <table>
                <tr>
                <th>Book Name</th>
                <th>Author</th>
                <th>Price</th>
                <th>BUY</th>
        </tr>
        <?php while($row = mysqli_fetch_assoc($result)){?>
                <tr>
                    <td><img src=<?= $row['IMAGE']?> width="181" height="271"class="image" alt="no cover available"><spam class="bookname"><?= $row['BOOK_NAME']?></spam></td>
                    <td><?= $row['FIRST_NAME'] ?> <?= $row['LAST_NAME'] ?> </td>
                    <td>$<?= $row['PRICE']?> </td>
                    <form action="cart.php" method="GET">
                    <td><a href="cart.php?BOOK_ID=<?= $row['BOOK_ID']?>">ADD TO CART</a></td>
            </form>
            </tr>
         
    <?php }}else{
        echo "<p class='genre'>No results found</p>";
    }}}elseif(empty($_POST['subcategory'])){
        $category = $_POST['category'];?>
        <h2 class="genre"><?= $category." books<br><br>";?></h2>
        <?php
        if((empty($_POST['searchbar']) || !isset($_POST['searchbar']))){
            $sql =$sql = "SELECT books.BOOK_ID,images.IMAGE,books.BOOK_NAME,authors.FIRST_NAME,authors.LAST_NAME,books.PRICE FROM books JOIN images ON books.IMAGE_ID=images.IMAGE_ID JOIN authors ON books.AUTHOR_ID =authors.AUTHOR_ID JOIN categories ON books.CATEGORY_ID = categories.CATEGORY_ID WHERE categories.CATEGORY = '$category'";
                $result = mysqli_query($conn,$sql);
                if(mysqli_num_rows($result) > 0){?>
            <table>
                        <tr>
                        <th>Book Name</th>
                        <th>Author</th>
                        <th>Price</th>
                        <th>BUY</th>
                </tr>
            <?php while($row = mysqli_fetch_assoc($result)){?>
                <tr>
                    <td><img src=<?= $row['IMAGE']?> width="181" height="271" src=<?= $row['IMAGE']?> width="181" height="271"class="image" alt="no cover available"><spam class="bookname"><?= $row['BOOK_NAME']?></spam></td></td>
                    <td><?= $row['FIRST_NAME'] ?> <?= $row['LAST_NAME'] ?> </td>
                    <td>$<?= $row['PRICE']?> </td>
                    <form action="cart.php" method="GET">
                    <td><a href="cart.php?BOOK_ID=<?= $row['BOOK_ID']?>">ADD TO CART</a></td>
            </form>
            </tr>
         
        
            <?php }}else{
                echo "<p class='genre'>No results found</p>";
            }

        }else{
        if($_POST['filter'] == "Book"){
            $search=$_POST['searchbar'];
            $sql =$sql = "SELECT books.BOOK_ID,images.IMAGE,books.BOOK_NAME,authors.FIRST_NAME,authors.LAST_NAME,books.PRICE FROM books JOIN images ON books.IMAGE_ID=images.IMAGE_ID INNER JOIN authors ON books.AUTHOR_ID =authors.AUTHOR_ID INNER JOIN categories ON books.CATEGORY_ID = categories.CATEGORY_ID WHERE BOOK_NAME LIKE '%$search%' AND categories.CATEGORY = '$category'";
                $result = mysqli_query($conn,$sql);
                if(mysqli_num_rows($result) > 0){?>
            <table>
                        <tr>
                        <th>Book Name</th>
                        <th>Author</th>
                        <th>Price</th>
                        <th>BUY</th>
                </tr>
            <?php while($row = mysqli_fetch_assoc($result)){?>
                <tr>
                    <td><img src=<?= $row['IMAGE']?> width="181" height="271"class="image" alt="no cover available" height="90" width="139"><spam class="bookname"><?= $row['BOOK_NAME']?></spam></td>
                    <td><?= $row['FIRST_NAME'] ?> <?= $row['LAST_NAME'] ?> </td>
                    <td>$<?= $row['PRICE']?> </td>
                    <form action="cart.php" method="GET">
                    <td><a href="cart.php?BOOK_ID=<?= $row['BOOK_ID']?>">ADD TO CART</a></td>
            </form>
            </tr>
         
        
            <?php }}else{
                echo "<p class='genre'>No results found</p>";
            }}else{ 
            $search=$_POST['searchbar'];
            $sql =$sql = "SELECT books.BOOK_ID,images.IMAGE,books.BOOK_NAME,authors.FIRST_NAME,authors.LAST_NAME,books.PRICE FROM books JOIN images ON books.IMAGE_ID=images.IMAGE_ID INNER JOIN authors ON books.AUTHOR_ID =authors.AUTHOR_ID INNER JOIN categories ON books.CATEGORY_ID = categories.CATEGORY_ID WHERE (authors.FIRST_NAME LIKE '%$search%' OR authors.LAST_NAME LIKE '%$search%') AND (categories.CATEGORY = '$category') ";
                $result = mysqli_query($conn,$sql);
                if(mysqli_num_rows($result) > 0){?>
            <table>
                        <tr>
                        <th>Book Name</th>
                        <th>Author</th>
                        <th>Price</th>
                        <th>BUY</th>
                </tr>
            <?php while($row = mysqli_fetch_assoc($result)){?>
                <tr>
                    <td><img src=<?= $row['IMAGE']?> width="181" height="271"class="image" alt="no cover available" height="90" width="139"><spam class="bookname"><?= $row['BOOK_NAME']?></spam></td>
                    <td><?= $row['FIRST_NAME'] ?> <?= $row['LAST_NAME'] ?> </td>
                    <td>$<?= $row['PRICE']?></td>
                    <form action="cart.php" method="GET">
                    <td><a href="cart.php?BOOK_ID=<?= $row['BOOK_ID']?>" type="submit">ADD TO CART</a></td>
            </form>
            </tr>
      
        
            <?php }}else{
                echo "<p class='genre'>No results found</p>";
            }}

    }}elseif(empty($_POST['category'])){
        $subcategory = $_POST['subcategory'];?>
        <h2 class="genre"><?= $subcategory." books<br><br>";?></h2>
        <?php
        if((empty($_POST['searchbar']) || !isset($_POST['searchbar']))){
            $sql =$sql = "SELECT books.BOOK_ID,images.IMAGE,books.BOOK_NAME,authors.FIRST_NAME,authors.LAST_NAME,books.PRICE FROM books JOIN images ON books.IMAGE_ID=images.IMAGE_ID JOIN authors ON books.AUTHOR_ID =authors.AUTHOR_ID JOIN subcategories ON books.SUBCATEGORY_ID = subcategories.SUBCATEGORY_ID WHERE subcategories.SUBCATEGORY = '$subcategory'";
                $result = mysqli_query($conn,$sql);
                if(mysqli_num_rows($result) > 0){?>
            <table>
                        <tr>
                        <th>Book Name</th>
                        <th>Author</th>
                        <th>Price</th>
                        <th>BUY</th>
                </tr>
            <?php while($row = mysqli_fetch_assoc($result)){?>
                <tr>
                    <td><img src=<?= $row['IMAGE']?> width="181" height="271"class="image" alt="no cover available"><spam class="bookname"><?= $row['BOOK_NAME']?></spam></td></td>
                    <td><?= $row['FIRST_NAME'] ?> <?= $row['LAST_NAME'] ?> </td>
                    <td>$<?= $row['PRICE']?> </td>
                    <form action="cart.php" method="GET">
                    <td><a href="cart.php?BOOK_ID=<?= $row['BOOK_ID']?>">ADD TO CART</a></td>
            </form>
            </tr>
         
        
            <?php }}else{
                echo "<p class='genre'>No results found</p>";
            }

        }else{
        if($_POST['filter'] == "Book"){
            $search=$_POST['searchbar'];
            $sql =$sql = "SELECT books.BOOK_ID,images.IMAGE,books.BOOK_NAME,authors.FIRST_NAME,authors.LAST_NAME,books.PRICE FROM books JOIN images ON books.IMAGE_ID=images.IMAGE_ID INNER JOIN authors ON books.AUTHOR_ID =authors.AUTHOR_ID INNER JOIN subcategories ON books.SUBCATEGORY_ID = subcategories.SUBCATEGORY_ID WHERE BOOK_NAME LIKE '%$search%' AND subcategories.SUBCATEGORY = '$subcategory'";
                $result = mysqli_query($conn,$sql);
                if(mysqli_num_rows($result) > 0){?>
            <table>
                        <tr>
                        <th>Book Name</th>
                        <th>Author</th>
                        <th>Price</th>
                        <th>BUY</th>
                </tr>
            <?php while($row = mysqli_fetch_assoc($result)){?>
                <tr>
                    <td><img src=<?= $row['IMAGE']?> width="181" height="271"class="image" alt="no cover available"><spam class="bookname"><?= $row['BOOK_NAME']?></spam></td></td>
                    <td><?= $row['FIRST_NAME'] ?> <?= $row['LAST_NAME'] ?> </td>
                    <td>$<?= $row['PRICE']?> </td>
                    <form action="cart.php" method="GET">
                    <td><a href="cart.php?BOOK_ID=<?= $row['BOOK_ID']?>">ADD TO CART</a></td>
            </form>
            </tr>
         
        
            <?php }}else{
                echo "<p class='genre'>No results found</p>";
            }}else{ 
            $search=$_POST['searchbar'];
            $sql =$sql = "SELECT books.BOOK_ID,images.IMAGE,books.BOOK_NAME,authors.FIRST_NAME,authors.LAST_NAME,books.PRICE FROM books JOIN images ON books.IMAGE_ID=images.IMAGE_ID INNER JOIN authors ON books.AUTHOR_ID =authors.AUTHOR_ID WHERE (authors.FIRST_NAME LIKE '%$search%' OR authors.LAST_NAME LIKE '%$search%') AND (subcategories.SUBCATEGORY = '$subcategory') ";
                $result = mysqli_query($conn,$sql);
                if(mysqli_num_rows($result) > 0){?>
            <table>
                        <tr>
                        <th>Book Name</th>
                        <th>Author</th>
                        <th>Price</th>
                        <th>BUY</th>
                </tr>
            <?php while($row = mysqli_fetch_assoc($result)){?>
                <tr>
                    <td><img src=<?= $row['IMAGE']?> width="181" height="271"class="image" alt="no cover available"><spam class="bookname"><?= $row['BOOK_NAME']?></spam></td></td>
                    <td><?= $row['FIRST_NAME'] ?> <?= $row['LAST_NAME'] ?> </td>
                    <td>$<?= $row['PRICE']?></td>
                    <form action="cart.php" method="GET">
                    <td><a href="cart.php?BOOK_ID=<?= $row['BOOK_ID']?>" type="submit">ADD TO CART</a></td>
            </form>
            </tr>
      
        
            <?php }}else{
                echo "<p class='genre'>No results found</p>";
            }}

    }}else{
        $category = $_POST['category'];
        $subcategory = $_POST['subcategory'];?>
        <h2 class="genre"><?= $category."/".$subcategory." books<br><br>";?></h2>
        <?php
        if((empty($_POST['searchbar']) || !isset($_POST['searchbar']))){
            $sql =$sql = "SELECT books.BOOK_ID,images.IMAGE,books.BOOK_NAME,authors.FIRST_NAME,authors.LAST_NAME,books.PRICE FROM books JOIN images ON books.IMAGE_ID=images.IMAGE_ID JOIN authors ON books.AUTHOR_ID =authors.AUTHOR_ID JOIN subcategories ON books.SUBCATEGORY_ID = subcategories.SUBCATEGORY_ID JOIN categories ON books.CATEGORY_ID = categories.CATEGORY_ID WHERE categories.CATEGORY = '$category' AND subcategories.SUBCATEGORY = '$subcategory'";
                $result = mysqli_query($conn,$sql);
                if(mysqli_num_rows($result) > 0){?>
            <table>
                        <tr>
                        <th>Book Name</th>
                        <th>Author</th>
                        <th>Price</th>
                        <th>BUY</th>
                </tr>
            <?php while($row = mysqli_fetch_assoc($result)){?>
                <tr>
                    <td><img src=<?= $row['IMAGE']?> width="181" height="271"class="image" alt="no cover available"><spam class="bookname"><?= $row['BOOK_NAME']?></spam></td></td>
                    <td><?= $row['FIRST_NAME'] ?> <?= $row['LAST_NAME'] ?> </td>
                    <td>$<?= $row['PRICE']?> </td>
                    <form action="cart.php" method="GET">
                    <td><a href="cart.php?BOOK_ID=<?= $row['BOOK_ID']?>">ADD TO CART</a></td>
            </form>
            </tr>
         
        
            <?php }}else{
                echo "<p class='genre'>No results found</p>";
            }

        }else{
        if($_POST['filter'] == "Book"){
            $search=$_POST['searchbar'];
            $sql =$sql = "SELECT books.BOOK_ID,images.IMAGE,books.BOOK_NAME,authors.FIRST_NAME,authors.LAST_NAME,books.PRICE FROM books JOIN images ON books.IMAGE_ID=images.IMAGE_ID INNER JOIN authors ON books.AUTHOR_ID =authors.AUTHOR_ID JOIN subcategories ON books.SUBCATEGORY_ID = subcategories.SUBCATEGORY_ID JOIN categories ON books.CATEGORY_ID = categories.CATEGORY_ID WHERE BOOK_NAME LIKE '%$search%' AND (categories.CATEGORY = '$category' AND subcategories.SUBCATEGORY = '$subcategory')";
                $result = mysqli_query($conn,$sql);
                if(mysqli_num_rows($result) > 0){?>
            <table>
                        <tr>
                        <th>Book Name</th>
                        <th>Author</th>
                        <th>Price</th>
                        <th>BUY</th>
                </tr>
            <?php while($row = mysqli_fetch_assoc($result)){?>
                <tr>
                    <td><img src=<?= $row['IMAGE']?> width="181" height="271"class="image" alt="no cover available"><spam class="bookname"><?= $row['BOOK_NAME']?></spam></td></td>
                    <td><?= $row['FIRST_NAME'] ?> <?= $row['LAST_NAME'] ?> </td>
                    <td>$<?= $row['PRICE']?> </td>
                    <form action="cart.php" method="GET">
                    <td><a href="cart.php?BOOK_ID=<?= $row['BOOK_ID']?>">ADD TO CART</a></td>
            </form>
            </tr>
         
        
            <?php }}else{
                echo "<p class='genre'>No results found</p>";
            }}else{ 
            $search=$_POST['searchbar'];
            $sql =$sql = "SELECT books.BOOK_ID,images.IMAGE,books.BOOK_NAME,authors.FIRST_NAME,authors.LAST_NAME,books.PRICE FROM books JOIN images ON images.IMAGE=images.IMAGE_ID JOIN authors ON books.AUTHOR_ID =authors.AUTHOR_ID JOIN categories ON books.CATEGORY_ID = categories.CATEGORY_ID JOIN subcategories ON books.SUBCATEGORY_ID = subcategories.SUBCATEGORY_ID WHERE (authors.FIRST_NAME LIKE '%$search%' OR authors.LAST_NAME LIKE '%$search%') AND (categories.CATEGORY = '$category' AND subcategories.SUBCATEGORY = '$subcategory')";
                $result = mysqli_query($conn,$sql);
                if(mysqli_num_rows($result) > 0){?>
            <table>
                        <tr>
                        <th>Book Name</th>
                        <th>Author</th>
                        <th>Price</th>
                        <th>BUY</th>
                </tr>
            <?php while($row = mysqli_fetch_assoc($result)){?>
                <tr>
                    <td><img src=<?= $row['IMAGE']?> width="181" height="271"class="image" alt="no cover available"><spam class="bookname"><?= $row['BOOK_NAME']?></spam></td></td>
                    <td><?= $row['FIRST_NAME'] ?> <?= $row['LAST_NAME'] ?> </td>
                    <td>$<?= $row['PRICE']?></td>
                    <form action="cart.php" method="GET">
                    <td><a href="cart.php?BOOK_ID=<?= $row['BOOK_ID']?>" type="submit">ADD TO CART</a></td>
            </form>
            </tr>
      
        
            <?php }}else{
                echo "<p class='genre'>No results found</p>";
            }}

    }}?> <?php } ?>
            



</body>
</html>