-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 05, 2022 at 08:49 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ebook`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `ADMIN_ID` int(10) UNSIGNED NOT NULL,
  `ADMIN_NAME` varchar(30) NOT NULL,
  `ADMIN_EMAIL` varchar(30) NOT NULL,
  `ADMIN_ADDRESS` varchar(70) NOT NULL,
  `ADMIN_PASS` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `authors`
--

CREATE TABLE `authors` (
  `AUTHOR_ID` int(10) UNSIGNED NOT NULL,
  `FIRST_NAME` varchar(30) NOT NULL,
  `LAST_NAME` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `authors`
--

INSERT INTO `authors` (`AUTHOR_ID`, `FIRST_NAME`, `LAST_NAME`) VALUES
(1, 'J.K', 'Rowling'),
(47, 'Malik', 'Anas'),
(52, 'Rick', 'Riordan');

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `BOOK_ID` int(10) UNSIGNED NOT NULL,
  `IMAGE_ID` int(10) UNSIGNED NOT NULL DEFAULT 7,
  `BOOK_NAME` varchar(100) NOT NULL,
  `AUTHOR_ID` int(10) UNSIGNED NOT NULL,
  `PRICE` float NOT NULL,
  `CATEGORY_ID` int(10) UNSIGNED NOT NULL DEFAULT 1,
  `SUBCATEGORY_ID` int(10) UNSIGNED NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`BOOK_ID`, `IMAGE_ID`, `BOOK_NAME`, `AUTHOR_ID`, `PRICE`, `CATEGORY_ID`, `SUBCATEGORY_ID`) VALUES
(28, 1, 'Harry Potter and the chamber of secrets', 1, 9.99, 2, 2),
(29, 24, 'Harry Potter and the Prisoner of Azkaban', 1, 9.99, 2, 2),
(33, 26, 'Harry Potter and the half-blood prince', 47, 9.99, 2, 3),
(34, 27, 'Harry potter and the deathly hallows', 1, 9.99, 4, 2),
(41, 9, 'Percy Jackson and the lightning thief', 52, 9.99, 4, 5),
(44, 28, 'Harry Potter and the Philosopher\'s stone', 1, 9.99, 4, 5),
(46, 25, 'Harry Potter and the Order of the Phoenix', 1, 9.99, 2, 2),
(49, 29, 'Harry Potter and the Goblet of Fire', 1, 9.99, 4, 2);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `CATEGORY_ID` int(10) UNSIGNED NOT NULL,
  `CATEGORY` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`CATEGORY_ID`, `CATEGORY`) VALUES
(4, 'Action'),
(2, 'Adventure'),
(7, 'Comedy'),
(1, 'No category');

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `IMAGE_ID` int(10) UNSIGNED NOT NULL,
  `IMAGE` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`IMAGE_ID`, `IMAGE`) VALUES
(1, 'harry2.jpg'),
(2, 'facebook.png'),
(7, 'no cover'),
(9, 'Percy_Jackson_&_the_Olympians_The_Lightning_Thief_poster.jpg'),
(24, 'harry3.jpg'),
(25, 'harry5.jpg'),
(26, 'harry6.jpg'),
(27, 'harry7.jpg'),
(28, 'harry1.jpg'),
(29, 'harry4.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `malik`
--
-- Error reading structure for table ebook.malik: #1932 - Table 'ebook.malik' doesn't exist in engine
-- Error reading data for table ebook.malik: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `ebook`.`malik`' at line 1

-- --------------------------------------------------------

--
-- Table structure for table `subcategories`
--

CREATE TABLE `subcategories` (
  `SUBCATEGORY_ID` int(10) UNSIGNED NOT NULL,
  `SUBCATEGORY` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `subcategories`
--

INSERT INTO `subcategories` (`SUBCATEGORY_ID`, `SUBCATEGORY`) VALUES
(5, 'crime'),
(4, 'fantasy'),
(2, 'Magic'),
(1, 'No subcategory'),
(3, 'Swordfight');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `USER_ID` int(10) UNSIGNED NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Address` varchar(70) NOT NULL,
  `Password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`USER_ID`, `Name`, `Email`, `Address`, `Password`) VALUES
(6, 'malik', 'malikanas553@gmail.com', 'sdfsdf', '12345678'),
(14, 'anas', 'abumalik12@hotmail.com', 'Kafori, Khartoum, Sudan', '12345678'),
(15, 'Mohaned', 'mohanedalfadil3@gmail.com', 'Kafori, Khartoum, Sudan', '0912335668');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`ADMIN_ID`),
  ADD UNIQUE KEY `ADMIN_EMAIL` (`ADMIN_EMAIL`);

--
-- Indexes for table `authors`
--
ALTER TABLE `authors`
  ADD PRIMARY KEY (`AUTHOR_ID`);

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`BOOK_ID`),
  ADD KEY `AUTHOR_ID` (`AUTHOR_ID`),
  ADD KEY `CATEGORY_ID` (`CATEGORY_ID`),
  ADD KEY `SUBCATEGORY_ID` (`SUBCATEGORY_ID`),
  ADD KEY `IMAGE_ID` (`IMAGE_ID`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`CATEGORY_ID`),
  ADD UNIQUE KEY `CATEGORY` (`CATEGORY`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`IMAGE_ID`);

--
-- Indexes for table `subcategories`
--
ALTER TABLE `subcategories`
  ADD PRIMARY KEY (`SUBCATEGORY_ID`),
  ADD UNIQUE KEY `SUBCATEGORY` (`SUBCATEGORY`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`USER_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `ADMIN_ID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `authors`
--
ALTER TABLE `authors`
  MODIFY `AUTHOR_ID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=84;

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `BOOK_ID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `CATEGORY_ID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `IMAGE_ID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `subcategories`
--
ALTER TABLE `subcategories`
  MODIFY `SUBCATEGORY_ID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `USER_ID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
