<?php
session_start();
if(isset($_SESSION['adminemail'])){
    header("Location: adminpage.php");
    die();
}
require 'connect.php';
error_reporting(0);
$email = $password = '';
$emailErr = $passwordErr = $Err ='';
if($_SERVER['REQUEST_METHOD'] == "POST"){
if(isset($_POST["adminemail"])){
    $email = $_POST["adminemail"];
    if(empty($_POST["adminemail"])){
        $emailErr = "Email is required";
        unset($_POST["adminemail"]);
        unset($_POST['adminpassword']);
    }elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $emailErr = "Invalid email";
        unset($_POST["adminemail"]);
        unset($_POST['adminpassword']);
    }
}else{
    $emailErr = "Email is required";
}if(isset($_POST['adminpassword'])){
    if(empty($_POST['adminpassword'])){
        $passwordErr = 'Password is required';
        unset($_POST['adminemail']);
        unset($_POST['adminpassword']);
    }elseif($emailErr == ''){
    $sql = "SELECT * FROM admins WHERE ADMIN_EMAIL = '$_POST[adminemail]' AND ADMIN_PASS = '$_POST[adminpassword]'";
    $result = mysqli_query($conn, $sql);
    if(mysqli_num_rows($result) == 0){
        $Err = "Incorrect Email or Password";
        unset($_POST['adminemail']);
        unset($_POST['adminpassword']);
}else{
    $row = mysqli_fetch_assoc($result);
    $_SESSION['ADMIN_ID'] = $row['ADMIN_ID'];
    $_SESSION['adminemail']=$_POST['adminemail'];
    header("Location: adminpage.php");
}}}else{
    $passwordErr = "Password is required";
    unset($_POST['adminemail']);
    unset($_POST['adminpassword']);}}?>
<!DOCTYPE html>
<html>
    <head>
        <title>Login</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="style2.css">
</head>
<header>
    <h1>MALIK'S STORE</h1>
    
</header>
<body>
    <section id="box1">
    <h1> Admin Log In</h1>
    <form method="POST" action=""><spam class="error"><?= $Err?></spam><br><br>
    <label for="adminemail">Email</label><spam class="error"><?= $emailErr?></spam><br><br>
    <input type="email" name="adminemail" placeholder="Enter your email" value="<?=$email?>" class="field"><br><br>
    <label for="adminpassword">Password</label><br><spam class="error"><?= $passwordErr?></spam><br>
    <input type="password" name="adminpassword" placeholder="Enter your password" value="<?=$password?>" class="field"><br><br>
    <input type="submit" value="Log In" id="login2">
    
</form>
</section>
</body>
</html>