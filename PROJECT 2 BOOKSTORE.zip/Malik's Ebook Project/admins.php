<?php
session_start();
require 'connect.php';
error_reporting(0);
if(!isset($_SESSION['adminemail'])){
    header("Location: adminlogin.php");
    die();
}elseif($_SESSION['ADMIN_ID'] !== '1'){
    header("Location: adminpage.php");
    die();
}else{
    $sql = "SELECT ADMIN_NAME FROM admins WHERE ADMIN_EMAIL = '$_SESSION[adminemail]'";
    $result= mysqli_query($conn,$sql);
    $row = mysqli_fetch_assoc($result);;
}
?>
<!DOCTYPE html>
<html>
<head>
        <link rel="stylesheet" href="style3.css">
</head>
<header>
<img src="logo.png" width="70" height="70">
<label id="adminname"><?= $row['ADMIN_NAME']?></label>
    <nav>
        <ul>
        <li><a href="users.php">Users</a></li>
        <li><a href="adminpage.php">Books</a></li>
        <li><a href="categories.php">Sub/Categories</a></li>
        <li><a href="orders.php">Orders</a></li>
        <li><a href="admins.php">Admins</a></li>
        <li><a href='logout.php'>Log Out</a></li>
</ul>
</nav>
</header>
<body>
<h1>Current Admins</h1>
<?php 
$sql2= "SELECT * FROM admins";
$result2 = mysqli_query($conn,$sql2);
?>
<form method="get" action="add.php">
<a href="add.php?newadmin=admin" class="add">Add New Admins</a>
</form>
<?php
if(mysqli_num_rows($result2) > 0){?>
    <table>
                <tr>
                <th>ADMIN ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Address</th>
                <th>Remove</th>
        </tr>
<?php while($row2 = mysqli_fetch_assoc($result2)){?>
    <tr>
                    <td><?= $row2['ADMIN_ID']?> </td>
                    <td><?= ucfirst($row2['ADMIN_NAME'])?></td>
                    <td><?= $row2['ADMIN_EMAIL']?></td>
                    <td><?= $row2['ADMIN_ADDRESS']?></td>
                    <form action="deleteuser.php" method="GET">
                    <td><a href="delete.php?ADMIN_ID=<?= $row2['ADMIN_ID']?>" onclick="return confirm('Are you sure you want to delete <?= ucfirst($row2['ADMIN_NAME'])?> from admins?');">DELETE</a></td>
            </form>
            </tr>

<?php }}else{?>
    <p>No Admins Registered<p>
<?php } ?>
</body>
</html>