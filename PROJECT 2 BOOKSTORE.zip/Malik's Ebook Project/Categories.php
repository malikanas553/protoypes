<?php
session_start();
error_reporting(0);
require 'connect.php';
if(!isset($_SESSION['adminemail'])){
    header("Location: adminlogin.php");
    die();
}else{
    $sql = "SELECT ADMIN_NAME FROM admins WHERE ADMIN_EMAIL = '$_SESSION[adminemail]'";
    $result= mysqli_query($conn,$sql);
    $row = mysqli_fetch_assoc($result);;
}

?>
<!DOCTYPE html>
<html>
<head>
        <link rel="stylesheet" href="style3.css">
</head>
<header>
<img src="logo.png" width="70" height="70">
<label id="adminname"><?= $row['ADMIN_NAME']?></label>
    <nav>
        <ul>
        <li><a href="users.php">Users</a></li>
        <li><a href="adminpage.php">Books</a></li>
        <li><a href="categories.php">Sub/Categories</a></li>
        <li><a href="orders.php">Orders</a></li>
        <?php if($_SESSION['ADMIN_ID'] == '1'){
        echo "<li><a href='admins.php'>Admins</a></li>";}?>
        <li><a href='logout.php'>Log Out</a></li>
</ul>
</nav>
</header>
<body>
<script>
function openform(){
    var x = document.getElementById("addcata");
    if(x.style.display == "block"){
        x.style.display = "none";
    }else{
        x.style.display = "block";
    }
}
function openform2(){
    var x = document.getElementById("addsubcata");
    if(x.style.display == "block"){
        x.style.display = "none";
    }else{
        x.style.display = "block";
    }
}
</script>
<section id="categories">
<section id="categorybox">
<h1>Categories</h1>
<?php 
$sql2= "SELECT * FROM categories WHERE NOT CATEGORY_ID= 1";
$result2 = mysqli_query($conn,$sql2);
?>
<spam onclick="openform()" class="add">Add New Category</spam>
<section id="addcata">
<form action="add.php" method="post">
<input type="text" name="newcategory" placeholder="Enter New Category" class="field">
<input type="submit" class="catabutton">
</form>
</section>
</form>
<?php
if(mysqli_num_rows($result2) > 0){?>
    <table>
                <tr>
                <th>Categories</th>
                <th>Change</th>
                <th>Remove</th>

        </tr>
<?php while($row2 = mysqli_fetch_assoc($result2)){ ?>
    <tr>
                    <td><?= $row2['CATEGORY']?> </td>
                    <form action="edit.php" method="get">
                    <td><a href="edit.php?CATEGORY_ID=<?= $row2['CATEGORY_ID']?>">Edit</a></td>
</form>
                    <form action="delete.php" method="GET">
                    <td><a href="delete.php?CATEGORY_ID=<?= $row2['CATEGORY_ID']?>" onclick="return confirm('Are you sure you want to delete <?= $row2['CATEGORY']?> from categories?');">DELETE</a></td>
            </form>
            </tr>


<?php }?></table><?php }else{

   echo "<p>No Categories Registered<p>";
   } ?>
</section>
<section id="subcategorybox">
<h1>Subcategories</h1>
<?php 
$sql3= "SELECT * FROM subcategories WHERE NOT SUBCATEGORY_ID= 1";
$result3 = mysqli_query($conn,$sql3);
?>
<spam class="add" onclick="openform2()">Add New Subcategory</spam>
<section id="addsubcata">
<form action="add.php" method="post">
<input type="text" name="newsubcategory" placeholder="Enter New Subcategory" class="field">
<input type="submit" class="catabutton">
</form>
</section>
</form>
<?php
if(mysqli_num_rows($result3) !== 0){?>
    <table>
                <tr>
                <th>Subcategories</th>
                <th>Change</th>
                <th>Remove</th>

        </tr>
<?php while($row3 = mysqli_fetch_assoc($result3)){?>
    <tr>
                    <td><?= $row3['SUBCATEGORY']?> </td>
                    <form action="edit.php" method="get">
                    <td><a href="edit.php?SUBCATEGORY_ID=<?= $row3['SUBCATEGORY_ID']?>">Edit</a></td>
</form>
                    <form action="delete.php" method="GET">
                    <td><a href="delete.php?SUBCATEGORY_ID=<?= $row3['SUBCATEGORY_ID']?>" onclick="return confirm('Are you sure you want to delete <?= $row3['SUBCATEGORY']?> from subcategories?');">DELETE</a></td>
            </form>
            </tr>

<?php }?></table><?php }else{

echo "<p>No Subcategories Registered<p>";
} ?>
</section>
</section>
</body>
</html>