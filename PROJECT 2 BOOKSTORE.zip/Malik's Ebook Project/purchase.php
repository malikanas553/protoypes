<?php
session_start();
error_reporting(0);
require 'connect.php';
if(!isset($_SESSION['email'])){
    header("Location: login.php");
    die();
}else{
    $sql = "SELECT Name FROM users WHERE Email = '$_SESSION[email]'";
    $result= mysqli_query($conn,$sql);
    $row = mysqli_fetch_assoc($result);
    $results = mysqli_query($conn,"SHOW TABLES LIKE '"."$row[Name]_Order"."'");
    if($results->num_rows == 1) {
        $sql3 = "INSERT INTO $row[Name]_Order SELECT * FROM $row[Name]";
        $result3 = mysqli_query($conn,$sql3);
        if($result3){
            $sql = "DROP TABLE $row[Name]";
            $result = mysqli_query($conn,$sql);
            header("Location: index.php?done");
        }else{
            echo "Failed to purchase";
        }
    }else{
    $result2 = mysqli_query($conn,"RENAME TABLE `" . "$row[Name]" . "` TO `" . "$row[Name]_Order" . "`" );
    if($result2){
        header("Location: index.php?done");
    }else{
        echo "Failed to purchase";
    }}}