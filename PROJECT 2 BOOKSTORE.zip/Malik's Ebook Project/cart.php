<?php
session_start();
error_reporting(0);
if(!isset($_SESSION['email'])){
    header("Location: login.php");
    die();
}else{
$_SESSION['BOOK_ID']=$_GET['BOOK_ID'];
require 'connect.php';
$sql = "SELECT Name FROM users WHERE Email = '$_SESSION[email]'";
    $result= mysqli_query($conn,$sql);
    $row = mysqli_fetch_assoc($result);
}
$sql = "SELECT Name FROM users WHERE Email = '$_SESSION[email]'";
$result= mysqli_query($conn,$sql);
$row = mysqli_fetch_assoc($result);
$results = mysqli_query($conn,"SHOW TABLES LIKE '"."$row[Name]"."'");
    if($results->num_rows == 1) {
        echo "Table exists";
        $sql ="INSERT INTO `$row[Name]`
        VALUES ('$_SESSION[BOOK_ID]');";
        $result = mysqli_query($conn,$sql);
        if($result){
            header("Location: index.php?msg");
        }else{
            echo "fail";
        }
        
        
    }
else {
    echo "Table does not exist";
    $sql = "CREATE TABLE `ebook`.$row[Name] ( `BOOK_ID` INT(10) UNSIGNED NOT NULL , INDEX (`BOOK_ID`)) ENGINE = InnoDB;";
    $result = mysqli_query($conn,$sql);
    $sql2 ="INSERT INTO `$row[Name]`
        VALUES ('$_SESSION[BOOK_ID]')";
        $result2 = mysqli_query($conn,$sql2);
        if($result2){
            header("Location:index.php?msg");
        }else{
            echo "fail";
        }

}