<?php
session_start();
require 'connect.php';
$x ="SELECT * FROM admins";
$result=mysqli_query($conn,$x);
if (mysqli_num_rows($result) == 0){
    header("Location:register.php");
    die();}
elseif(isset($_SESSION['email'])){
    header("Location: index.php");
    die();
}

$email = $password = '';
$emailErr = $passwordErr = $Err ='';
if($_SERVER['REQUEST_METHOD'] == "POST"){
if(isset($_POST["email"])){
    $email = $_POST["email"];
    if(empty($_POST["email"])){
        $emailErr = "Email is required";
        unset($_POST["email"]);
        unset($_POST['password']);
    }elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $emailErr = "Invalid email";
        unset($_POST["email"]);
        unset($_POST['password']);
    }
}else{
    $emailErr = "Email is required";
}if(isset($_POST['password'])){
    if(empty($_POST['password'])){
        $passwordErr = 'Password is required';
        unset($_POST['email']);
        unset($_POST['password']);
    }elseif($emailErr == ''){$sql = "SELECT * FROM users WHERE Email = '$_POST[email]' AND Password = '$_POST[password]'";
    $result = mysqli_query($conn, $sql);
    if(mysqli_num_rows($result) == 0){
        $Err = "Incorrect Email or Password";
        unset($_POST['email']);
        unset($_POST['password']);
}else{
    $_SESSION['email']=$_POST['email'];
    header("Location: index.php");
}}}else{
    $passwordErr = "Password is required";
    unset($_POST['email']);
    unset($_POST['password']);}}?>
<!DOCTYPE html>
<html>
    <head>
        <title>Login</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="style2.css">
</head>
<header>
    <h1>MALIK'S STORE</h1>
    
</header>
<body>
    <section id="box1">
    <h2>Log In</h2>
    <p>If you are an admin click <a href="adminlogin.php">here</a></p>
    <form method="POST" action=""><spam class="error"><?= $Err?></spam><br><br>
    <label for="email">Email</label><spam class="error"><?= $emailErr?></spam><br><br>
    <input type="email" name="email" placeholder="Enter your email" value="<?=$email?>" class="field"><br><br>
    <label for="password">Password</label><br><spam class="error"><?= $passwordErr?></spam><br>
    <input type="password" name="password" placeholder="Enter your password" value="<?=$password?>" class="field"><br><br>
    <section id="box2">
    <p>Don't have an account?</p>
    <a href="register.php">Register</a>
</section>
    <input type="submit" value="Log In" id="login">
</form>
</section>
</body>
</html>
