<?php
session_start();
error_reporting(0);
require 'connect.php';
if(!isset($_SESSION['adminemail'])){
    header("Location: login.php");
    die();
}else{
    if(isset($_GET['USER_ID'])){
    $_SESSION['USER_ID']=$_GET['USER_ID'];}
    elseif(isset($_GET['ADMIN_ID'])){
    $_SESSION['ADMIN_ID']=$_GET['ADMIN_ID'];
} elseif(isset($_GET['BOOK_ID'])){
    $_SESSION['BOOK_ID']=$_GET['BOOK_ID'];}
elseif(isset($_GET['CATEGORY_ID'])){
    $_SESSION['CATEGORY_ID'] = $_GET['CATEGORY_ID'];
}elseif(isset($_GET['SUBCATEGORY_ID'])){
    $_SESSION['SUBCATEGORY_ID'] = $_GET['SUBCATEGORY_ID'];
}elseif(isset($_GET['ORDER'])){
    $_SESSION['ORDER'] = $_GET['ORDER'];
}

}
if(isset($_GET['USER_ID'])){
$sql = "DELETE FROM users WHERE USER_ID = '$_SESSION[USER_ID]'";
$result = mysqli_query($conn,$sql);
if($result){
    header("Location:users.php");
    die();
}else{
    echo "Failed to delete";
}}elseif(isset($_GET['ADMIN_ID'])){
    $sql = "DELETE FROM admins WHERE ADMIN_ID = '$_SESSION[ADMIN_ID]'";
$result = mysqli_query($conn,$sql);
if($result){
    header("Location:admins.php");
    die();
}else{
    echo "Failed to delete";
}
}elseif(isset($_GET['BOOK_ID'])){
    $sql = "DELETE FROM books WHERE BOOK_ID = '$_SESSION[BOOK_ID]'";
$result = mysqli_query($conn,$sql);
if($result){
    header("Location:adminpage.php");
    die();
}else{
    echo "Failed to delete";
}
}elseif(isset($_GET['CATEGORY_ID'])){
    $sql = "UPDATE books SET CATEGORY_ID = 1 WHERE CATEGORY_ID = '$_GET[CATEGORY_ID]'";
    $result = mysqli_query($conn,$sql);
    $sql2 = "DELETE FROM categories WHERE CATEGORY_ID = '$_GET[CATEGORY_ID]'";
    $result2 = mysqli_query($conn,$sql2);
    if($result2){
      header("Location: Categories.php");
      die();
    

}
    }elseif(isset($_GET['SUBCATEGORY_ID'])){
    $sql = "UPDATE books SET SUBCATEGORY_ID = 1 WHERE SUBCATEGORY_ID = '$_GET[SUBCATEGORY_ID]'";
    $result = mysqli_query($conn,$sql);
    $sql2 = "DELETE FROM subcategories WHERE SUBCATEGORY_ID = '$_GET[SUBCATEGORY_ID]'";
    $result2 = mysqli_query($conn,$sql2);
    if($result2){
      header("Location: Categories.php");
      die();
    }}elseif(isset($_GET['ORDER'])){
        $sql2 ="SELECT Email FROM users WHERE Name = '$_SESSION[ORDER]'";
        $result2 = mysqli_query($conn,$sql2);
        $row2 = mysqli_fetch_assoc($result2);
        $to = $row2['Email'];
        $subject = "Your Book Order";
        $headers =  'MIME-Version: 1.0' . "\r\n"; 
        $headers .= 'From: Malik Bookstore <malikanas553@gmail.com>' . "\r\n";
        $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";           
        $message = "
        <html>
        <head>
        <title>Book Order Bill</title>
        </head>
        <body>";

        $sql4= "SELECT $_SESSION[ORDER]_order.BOOK_ID,books.BOOK_NAME,books.PRICE,authors.FIRST_NAME,authors.LAST_NAME FROM $_SESSION[ORDER]_order JOIN books ON $_SESSION[ORDER]_order.BOOK_ID = books.BOOK_ID JOIN authors ON books.AUTHOR_ID = authors.AUTHOR_ID";
        $result4 = mysqli_query($conn,$sql4);
        $sql5 = "SELECT SUM(books.PRICE) AS total_price FROM books INNER JOIN $_SESSION[ORDER]_order ON books.BOOK_ID = $_SESSION[ORDER]_order.BOOK_ID";
      $result5 = mysqli_query($conn,$sql5);
      $row3 = mysqli_fetch_assoc($result5);
      $number = $row3['total_price'];
      $sum = number_format((float)$number, 2, '.', '');

        $body = "<table class='TFtable' border='1' style='width':100%>";
        $body .= "<tr><th>Price</th><th>Book ID</th><th>BooK Name</h><th>Author</th></tr>";
        while($row4 = $result4->fetch_assoc()) { 
        $body .= "<tr><td>".$row4['PRICE']."</td><td>".$row4['BOOK_ID']."</td><td>".$row4['BOOK_NAME']. "</td><td>".$row4['FIRST_NAME']." ".$row4['LAST_NAME']."</td>";
        }
        $body .= "</table>";
        $message .= $body . "
        <p>Total: $".$sum ."</p>

        </body>
        </html>";
        $message = wordwrap($message, 70);    
        if(mail($to,$subject,$message,$headers)){
            $sql = "DROP TABLE $_SESSION[ORDER]_order";
            $result = mysqli_query($conn,$sql);
            if($result){
                header("Location:adminpage.php");
            }
        }
    }