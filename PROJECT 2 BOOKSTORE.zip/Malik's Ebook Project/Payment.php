<?php
session_start();
error_reporting(0);
require 'connect.php';
if(!isset($_SESSION['email'])){
    header("Location: login.php");
    die();
}else{
    $sql = "SELECT Name FROM users WHERE Email = '$_SESSION[email]'";
    $result= mysqli_query($conn,$sql);
    $row = mysqli_fetch_assoc($result);
   
}?>
<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="style3.css">
</head>
<header>
<a href="about.php"><img src="logo.png" width="90" height="90"></a>
<label id="adminname"><?= ucfirst($row['Name'])?></label>
    <nav>
        <ul>
        <li><a href="about.php">About</a></li>
        <li><a href="index.php">Home</a></li>
        <li><a href="payment.php">Cart</a></li>
        <li><a href='logout.php'>Log Out</a></li>
</ul>
</nav>
</header>
<body>
<?php if(isset($_GET['msg'])){
     echo '
     <script type="text/javascript">
 
     alert("Book removed from cart");
 
     </script>';}?>
    
    
    <?php 
$sql = "SELECT Name FROM users WHERE Email = '$_SESSION[email]'";
$result= mysqli_query($conn,$sql);
$row = mysqli_fetch_assoc($result);
$results = mysqli_query($conn,"SHOW TABLES LIKE '"."$row[Name]"."'");
$results2 = mysqli_query($conn,"SHOW TABLES LIKE '"."$row[Name]_Order"."'");
    if($results->num_rows == 1) {?>
        <h1>Your Order List</h1>
        <?php
        $sql2 = "SELECT BOOK_ID from $row[Name]";
        $result2 = mysqli_query($conn,$sql2);
        if(mysqli_num_rows($result2) == 0){
            header("Location: index.php?alert");
}else{
        $sql= "SELECT $row[Name].BOOK_ID,books.BOOK_NAME,books.PRICE,authors.FIRST_NAME,authors.LAST_NAME FROM $row[Name] JOIN books ON $row[Name].BOOK_ID = books.BOOK_ID JOIN authors ON books.AUTHOR_ID = authors.AUTHOR_ID";
        $result = mysqli_query($conn,$sql);
        if(mysqli_num_rows($result) > 0){?>
            <table>
                        <tr>
                         <th>Price</th>
                        <th>Book Name</th>
                        <th>Author</th>
                        <th>Remove</th>
                </tr>
            <?php while($row = mysqli_fetch_assoc($result)){?>
                <tr> 
                    <td>$<?= $row['PRICE']?> </td>
                    <td><?= $row['BOOK_NAME']?> </td>
                    <td><?= $row['FIRST_NAME'] ?> <?= $row['LAST_NAME'] ?> </td>
                    <form action="Cartdel.php" method="GET">
                    <td><a href="Cartdel.php?BOOK_ID=<?= $row['BOOK_ID']?>" onclick="return confirm('Are you sure you want to delete this?');" >Delete from list</a></td>
            </form>
            </tr>
         
   <?php }?>

<tr>
<?php 
$sql3 = "SELECT Name FROM users WHERE Email = '$_SESSION[email]'";
$result3= mysqli_query($conn,$sql3);
$row = mysqli_fetch_assoc($result3);
$sql4 = "SELECT SUM(books.PRICE) AS total_price FROM books INNER JOIN $row[Name] ON books.BOOK_ID = $row[Name].BOOK_ID";
      $result4 = mysqli_query($conn,$sql4);
      $row2 = mysqli_fetch_assoc($result4);
      $number = $row2['total_price'];
      $sum = number_format((float)$number, 2, '.', '');?>
    <td>SUM: $<?=$sum?></td>
 
            </tr>
            </table>
<label for="paymethod" id="labelpay">Payment Method</label><br><br>
<select id="paymethod" name="paymethod">
<option selected="true" disabled="disabled">Select Payment Method</option>
<option required> Payment at delivery</option>
            </select><br><br>
<a href="purchase.php"><button id="order">Place Order</button></a>

<?php }}}elseif($results2->num_rows == 1){?>
    <h1>Your Current Order</h1>
     <?php
         $sql3 = "SELECT BOOK_ID from $row[Name]_Order";
         $result3 = mysqli_query($conn,$sql3);
         $sql4= "SELECT $row[Name]_Order.BOOK_ID,books.BOOK_NAME,books.PRICE,authors.FIRST_NAME,authors.LAST_NAME FROM $row[Name]_Order JOIN books ON $row[Name]_Order.BOOK_ID = books.BOOK_ID JOIN authors ON books.AUTHOR_ID = authors.AUTHOR_ID";
         $result4 = mysqli_query($conn,$sql4);
         if(mysqli_num_rows($result4) > 0){?>
 
             <table id="<?=$row['Name']?>">
                         <tr>
                         <th>Price</th>
                         <th>Book Name</th>
                         <th>Author</th>
                         
                 </tr>
              
     
             <?php while($row4 = mysqli_fetch_assoc($result4)){?>
                 <tr>
                     <td>$<?= $row4['PRICE']?> </td>
                     <td><?= $row4['BOOK_NAME']?> </td>
                     <td><?= $row4['FIRST_NAME'] ?> <?= $row4['LAST_NAME'] ?> </td>
             </tr>
         
 
          
   <?php }    
 $sql5 = "SELECT SUM(books.PRICE) AS total_price FROM books INNER JOIN $row[Name]_Order ON books.BOOK_ID = $row[Name]_Order.BOOK_ID";
       $result5 = mysqli_query($conn,$sql5);
       $row3 = mysqli_fetch_assoc($result5);
       $number = $row3['total_price'];
       $sum = number_format((float)$number, 2, '.', '');?>
       <tr>
     <td>SUM: $<?=$sum?></td>
             </tr>
         <tr>
             <form method="get" action="cartdel.php">
             <td id="cancel"><a href="cartdel.php?CANCELORDER=<?=$row['Name']?>" onclick="return confirm('Are you sure you want to cancel this order?')" class="complete">Cancel</a></td>
             </form>
         </table><?php ;}?>
             </body>
             </html>


<?php } 
    else{
        header("Location: index.php?alert");
    }?>
